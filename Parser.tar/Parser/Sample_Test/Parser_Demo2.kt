/**
 * You can edit, run, and share this code.
 * play.kotlinlang.org
 */
import java.time.LocalDate
import java.time.LocalTime
import java.time.DayOfWeek
import java.time.DateTimeException

//=================================================
//Relative Date Regex Patterns
//=================================================

val Basic_Relative_Regex = """\b(?:day\s+after\s+tomorrow|day\s+before\s+yesterday|today|tomorrow|yesterday|(?:a|one)\s+day\s+ago)\b"""
val Multi_Relative_Regex = """\b(?:(?:in|after)\s+\d+\s+days?(?:\s+(?:from\s+(?:now|today)|later))?|\d+\s+days?\s+(?:ago|before\s+today))\b"""
val Weekday_Regex = """\b(?:(?:(?:this|next|last)\s+week(?:'s)?\s+)|(?:(?:this\s+coming|coming|the\s+following|the\s+next|next|this|last|previous|the\s+preceding|preceding)\s+))(?:Monday|Mon|Tuesday|Tue|Tues|Wednesday|Wed|Thursday|Thu|Thur|Thurs|Friday|Fri|Saturday|Sat|Sunday|Sun)\b"""

val Relative_Date_Pattern = Regex("""(?:$Basic_Relative_Regex|$Multi_Relative_Regex|$Weekday_Regex)""",RegexOption.IGNORE_CASE)


//=================================================
//Explicit Date Regex Pattern
//=================================================

val Month_Regex = """(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)"""
val Day_Regex = """\d{1,2}(?:st|nd|rd|th)?"""
val Year_Regex = """(?:\d{2}|\d{4})"""

val Day_Number = """(?:0?[1-9]|[12]\d|3[01])"""
val Month_Number = """(?:0?[1-9]|1[0-2])"""
val Year_2 = """\d{2}"""
val Year_4 = """\d{4}"""


val Numeric_Regex = """(?<![\d/-])(?:(?<yearFirst>\d{4})[/-](?<monthYearFirst>$Month_Number)[/-](?<dayYearFirst>$Day_Number)|(?<dayFirst>$Day_Number)[/-](?<monthDayFirst>$Month_Number)(?:[/-](?<yearLast>$Year_2|$Year_4))?)(?![\d/-])""".trimIndent()

val Explicit_Date_Pattern = Regex("""(?i)(?:\b(?:(?<month>$Month_Regex)\s+(?<day>$Day_Regex)(?:,?\s+(?<year>$Year_Regex))?|(?<day2>$Day_Regex)\s+(?<month2>$Month_Regex)(?:\s+(?<year2>$Year_Regex))?)\b|$Numeric_Regex)""",RegexOption.IGNORE_CASE)



//=================================================
//General Config
//=================================================
val Whitespace_Pattern = Regex("\\s+")


//=================================================
//Relative Date Map 
//=================================================

enum class DateType {BASIC_RELATIVE, WEEKDAY, MULTI_RELATIVE}

val Word_Map = mapOf(
    "today" to (0L to DateType.BASIC_RELATIVE),
    "tomorrow" to (1L to DateType.BASIC_RELATIVE),
    
    "yesterday" to (-1L to DateType.BASIC_RELATIVE),
    "one day ago" to (-1L to DateType.BASIC_RELATIVE),
    "a day ago" to (-1L to DateType.BASIC_RELATIVE),
    
    "day after tomorrow" to (2L to DateType.BASIC_RELATIVE),
    "day before yesterday" to (-2L to DateType.BASIC_RELATIVE),
    



    "in" to (1L to DateType.MULTI_RELATIVE),
    "after" to (1L to DateType.MULTI_RELATIVE),
    "from" to (1L to DateType.MULTI_RELATIVE),
    "now" to (1L to DateType.MULTI_RELATIVE),
    "later" to (1L to DateType.MULTI_RELATIVE),
    
    "ago" to (-1L to DateType.MULTI_RELATIVE),
    "before" to (-1L to DateType.MULTI_RELATIVE),



    "this" to (0L to DateType.WEEKDAY),
    "next" to (1L to DateType.WEEKDAY),
    "last" to (-1L to DateType.WEEKDAY),

    "following" to (1L to DateType.WEEKDAY),
    "coming" to (1L to DateType.WEEKDAY),
    
    "previous" to (-1L to DateType.WEEKDAY),
    "preceding" to (-1L to DateType.WEEKDAY),
)

val Weekday_Map = mapOf(
        "monday" to 0,
        "mon" to 0,

        "tuesday" to 1,
        "tue" to 1,
        "tues" to 1,

        "wednesday" to 2,
        "wed" to 2,

        "thursday" to 3,
        "thu" to 3,
        "thur" to 3,
        "thurs" to 3,

        "friday" to 4,
        "fri" to 4,

        "saturday" to 5,
        "sat" to 5,

        "sunday" to 6,
        "sun" to 6
)
//=================================================
//Time Regex Pattern
//=================================================

// 1. Hour, minute, and second patterns
val Hour12 = """(?:1[0-2]|[1-9])"""
val Hour24_Unambiguous = """(?:1[3-9]|2[0-3])"""
val Minute = """[0-5]\d"""
val Second = """[0-5]\d"""

// 2. AM / PM
val Am_Pm = """(?i:AM|PM)"""

// 3. Day-period words
val Day_Period = """(?i:morning|afternoon|evening|night|tonight|noon|midday|midnight|dawn|sunrise|dusk|sunset)"""

// 4. 12-hour time with mandatory AM / PM
// Examples: 7 AM, 7:30 PM, 7:30:15 AM

val Time12 = """(?<hour12>$Hour12)(?::(?<minute12>$Minute)(?::(?<second12>$Second))?)?\s*(?<ampm>$Am_Pm)"""

// 5. Unambiguous 24-hour time
// Examples: 13:00, 19:30, 23:15:30
val Time24 = """(?<hour24>$Hour24_Unambiguous):(?<minute24>$Minute)(?::(?<second24>$Second))?"""

// 6. O'clock with mandatory AM / PM
// Examples: 7 o'clock AM, 7 o'clock PM
val O_Clock = """(?<oclockhour>$Hour12)\s+o['’]?clock\s*(?<oclockampm>$Am_Pm)"""

// 7. Clock time with day-period context
// Examples: 7 in the morning, 7:30 at night
val Clock_With_Period = """(?<clockperiodhour>$Hour12)(?::(?<clockperiodminute>$Minute)(?::(?<clockperiodsecond>$Second))?)?\s*(?:(?:in|at)\s+)?(?:the\s+)?(?:(?:early|late|mid)\s+)?(?<clockperiod>$Day_Period)"""

val Period_With_Clock = """(?:(?:early|late|mid)\s+)?(?<periodclock>$Day_Period)\s+(?:at\s+)?(?<periodclockhour>$Hour12)(?::(?<periodclockminute>$Minute)(?::(?<periodclocksecond>$Second))?)?(?:\s+o['’]?clock)?(?:\s*(?<periodclockampm>$Am_Pm))?"""


val Clock_Time_Pattern = Regex("""(?ix)(?<![\w:])(?:$Time12|$Time24|$O_Clock|$Clock_With_Period|$Period_With_Clock)(?![\w:])""".trimIndent())





//=================================================
//Explict Date Map
//=================================================

val Month_Map = mapOf(
    "january" to 1,
    "jan" to 1,

    "february" to 2,
    "feb" to 2,

    "march" to 3,
    "mar" to 3,

    "april" to 4,
    "apr" to 4,

    "may" to 5,

    "june" to 6,
    "jun" to 6,

    "july" to 7,
    "jul" to 7,

    "august" to 8,
    "aug" to 8,

    "september" to 9,
    "sep" to 9,

    "october" to 10,
    "oct" to 10,

    "november" to 11,
    "nov" to 11,

    "december" to 12,
    "dec" to 12
)

//=================================================
//Time Map
//=================================================

val Period_Map = mapOf(
    "morning" to "AM",
    "afternoon" to "PM",
    "evening" to "PM",
    "night" to "PM",
    "tonight" to "PM",
    "dawn" to "AM",
    "sunrise" to "AM",
    "dusk" to "PM",
    "sunset" to "PM",
    "noon" to "PM",
    "midday" to "PM",
    "midnight" to "AM"
)

fun Find_Relative_Date(Text: String): LocalDate? {

val Match = Relative_Date_Pattern.find(Text)?: return null
val Match_Text = Match.value.trim().lowercase()
val Result = Word_Map[Match_Text] ?: Match_Text.split(Whitespace_Pattern).firstNotNullOfOrNull { Word ->Word_Map[Word]} ?: return null

val Number = Result.first
val Type = Result.second

when (Type) {
DateType.BASIC_RELATIVE -> {
    return LocalDate.now().plusDays(Number)
}
DateType.MULTI_RELATIVE -> {
    val Days = Regex("""\d+""").find(Match_Text)?.value?.toLong() ?: return null
    return LocalDate.now().plusDays(Number * Days)
}
DateType.WEEKDAY -> {
    val Weekday_Number = Match_Text.split(Whitespace_Pattern).firstNotNullOfOrNull { Word ->Weekday_Map[Word]} ?: return null
    val Current_Week_Monday = LocalDate.now().with(DayOfWeek.MONDAY)
    return Current_Week_Monday.plusDays((Number * 7L) + Weekday_Number)
}
}
}

fun Find_Explicit_Date(Text: String): LocalDate? {
val Match = Explicit_Date_Pattern.find(Text) ?: return null

val Month_Text = Match.groups["month"]?.value ?: Match.groups["month2"]?.value
val Day_Text = Match.groups["day"]?.value ?: Match.groups["day2"]?.value
val Year_Text = Match.groups["year"]?.value ?: Match.groups["year2"]?.value

val Month = Month_Text?.lowercase()?.let { Month_Map[it] }
val Day = Day_Text ?.lowercase() ?.removeSuffix("st") ?.removeSuffix("nd") ?.removeSuffix("rd") ?.removeSuffix("th") ?.toIntOrNull()
val Year = Year_Text?.toIntOrNull()

val Numeric_Day = Match.groups["dayYearFirst"]?.value?.toIntOrNull() ?: Match.groups["dayFirst"]?.value?.toIntOrNull()
val Numeric_Month = Match.groups["monthYearFirst"]?.value?.toIntOrNull() ?: Match.groups["monthDayFirst"]?.value?.toIntOrNull()
val Numeric_Year_Text = Match.groups["yearFirst"]?.value ?: Match.groups["yearLast"]?.value

val Numeric_Year = Numeric_Year_Text?.let {
    if (it.length == 2) {
        2000 + it.toInt()
    } else {
        it.toInt()
    }
}

val Final_Month = Month ?: Numeric_Month
val Final_Day = Day ?: Numeric_Day
val Final_Year = Year ?: Numeric_Year ?: LocalDate.now().year

val Date = try {
    LocalDate.of(Final_Year, Final_Month ?: return null, Final_Day ?: return null)
} catch (e: DateTimeException) {
    return null
}
return Date
}


fun Find_Time(Text: String): LocalTime? {
val Match = Clock_Time_Pattern.find(Text) ?: return null

when {

    // Time12 → 7 AM, 7:30 PM, 7:30:15 AM
    Match.groups["hour12"] != null &&
    Match.groups["ampm"] != null -> {

        val Hour = Match.groups["hour12"]?.value?.toInt() ?: return null
        val Minute = Match.groups["minute12"]?.value?.toInt() ?: 0
        val Second = Match.groups["second12"]?.value?.toInt() ?: 0
        val Am_Pm = Match.groups["ampm"]?.value?.uppercase() ?: return null

        val Final_Hour = when {
            Am_Pm == "AM" && Hour == 12 -> 0
            Am_Pm == "PM" && Hour != 12 -> Hour + 12
            else -> Hour
        }

        return LocalTime.of(Final_Hour, Minute, Second)
    }


    // Time24 → 13:00, 19:30, 23:15:30
    Match.groups["hour24"] != null -> {

        val Hour = Match.groups["hour24"]?.value?.toInt() ?: return null
        val Minute = Match.groups["minute24"]?.value?.toInt() ?: return null
        val Second = Match.groups["second24"]?.value?.toInt() ?: 0

        return LocalTime.of(Hour, Minute, Second)
    }

    // O_Clock → 7 o'clock AM, 7 o'clock PM
    Match.groups["oclockhour"] != null &&
    Match.groups["oclockampm"] != null -> {

        val Hour = Match.groups["oclockhour"]?.value?.toInt() ?: return null
        val Am_Pm = Match.groups["oclockampm"]?.value?.uppercase() ?: return null

        val Final_Hour = when {
            Am_Pm == "AM" && Hour == 12 -> 0
            Am_Pm == "PM" && Hour != 12 -> Hour + 12
            else -> Hour
        }

        return LocalTime.of(Final_Hour, 0, 0)
    }


    // Clock_With_Period → 7 in the morning, 7:30 at night
    Match.groups["clockperiodhour"] != null &&
    Match.groups["clockperiod"] != null -> {

        val Hour = Match.groups["clockperiodhour"]?.value?.toInt() ?: return null
        val Minute = Match.groups["clockperiodminute"]?.value?.toInt() ?: 0
        val Second = Match.groups["clockperiodsecond"]?.value?.toInt() ?: 0
        val Period = Match.groups["clockperiod"]?.value?.lowercase() ?: return null

        val Am_Pm = Period_Map[Period] ?: return null

        val Final_Hour = when {
            Am_Pm == "AM" && Hour == 12 -> 0
            Am_Pm == "PM" && Hour != 12 -> Hour + 12
            else -> Hour
        }

        return LocalTime.of(Final_Hour, Minute, Second)
    }


    // Period_With_Clock → morning at 7, night at 8:30
    Match.groups["periodclock"] != null &&
    Match.groups["periodclockhour"] != null -> {

        val Period = Match.groups["periodclock"]?.value?.lowercase() ?: return null
        val Hour = Match.groups["periodclockhour"]?.value?.toInt() ?: return null
        val Minute = Match.groups["periodclockminute"]?.value?.toInt() ?: 0
        val Second = Match.groups["periodclocksecond"]?.value?.toInt() ?: 0

        val Am_Pm = Period_Map[Period] ?: return null

        val Final_Hour = when {
            Am_Pm == "AM" && Hour == 12 -> 0
            Am_Pm == "PM" && Hour != 12 -> Hour + 12
            else -> Hour
        }

        return LocalTime.of(Final_Hour, Minute, Second)
    }


    else -> {
        return null
    }
}
return null
}

data class TaskDateTime(
    val date: LocalDate?,
    val time: LocalTime?
)

fun findTaskDateTime(Text: String): TaskDateTime {

    val Date = Find_Relative_Date(Text)
        ?: Find_Explicit_Date(Text)

    val Time = if (Date != null) {
        Find_Time(Text)
    } else {
        null
    }


    return TaskDateTime(
        date = Date,
        time = Time
    )
}
fun main() {

    val TaskText = "Meeting scheduled today 7 in the morning"

    val Result = findTaskDateTime(TaskText)

    println(Result.date)
    println(Result.time)
}


