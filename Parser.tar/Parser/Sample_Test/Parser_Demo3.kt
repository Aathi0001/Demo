/**
 * You can edit, run, and share this code.
 * play.kotlinlang.org
 */
import java.time.LocalDate
import java.time.LocalTime
import java.time.DayOfWeek
import java.time.DateTimeException

//=================================================
//Relative Date Regex Patterns
//=================================================

val Basic_Relative_Regex = """\b(?:day\s+after\s+tomorrow|day\s+before\s+yesterday|today|tomorrow|yesterday|(?:a|one)\s+day\s+ago)\b"""
val Multi_Relative_Regex = """\b(?:(?:in|after)\s+\d+\s+days?(?:\s+(?:from\s+(?:now|today)|later))?|\d+\s+days?\s+(?:ago|before\s+today))\b"""
val Weekday_Regex = """\b(?:(?:(?:this|next|last)\s+week(?:'s)?\s+)|(?:(?:this\s+coming|coming|the\s+following|the\s+next|next|this|last|previous|the\s+preceding|preceding)\s+))(?:Monday|Mon|Tuesday|Tue|Tues|Wednesday|Wed|Thursday|Thu|Thur|Thurs|Friday|Fri|Saturday|Sat|Sunday|Sun)\b"""

val Relative_Date_Pattern = Regex("""(?:$Basic_Relative_Regex|$Multi_Relative_Regex|$Weekday_Regex)""",RegexOption.IGNORE_CASE)


//=================================================
//Explicit Date Regex Pattern
//=================================================

val Month_Regex = """(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)"""
val Day_Regex = """\d{1,2}(?:st|nd|rd|th)?"""
val Year_Regex = """(?:\d{2}|\d{4})"""

val Day_Number = """(?:0?[1-9]|[12]\d|3[01])"""
val Month_Number = """(?:0?[1-9]|1[0-2])"""
val Year_2 = """\d{2}"""
val Year_4 = """\d{4}"""


val Numeric_Regex = """(?<![\d/-])(?:(?<yearFirst>\d{4})[/-](?<monthYearFirst>$Month_Number)[/-](?<dayYearFirst>$Day_Number)|(?<dayFirst>$Day_Number)[/-](?<monthDayFirst>$Month_Number)(?:[/-](?<yearLast>$Year_2|$Year_4))?)(?![\d/-])""".trimIndent()

val Explicit_Date_Pattern = Regex("""(?i)(?:\b(?:(?<month>$Month_Regex)\s+(?<day>$Day_Regex)(?:,?\s+(?<year>$Year_Regex))?|(?<day2>$Day_Regex)\s+(?<month2>$Month_Regex)(?:\s+(?<year2>$Year_Regex))?)\b|$Numeric_Regex)""",RegexOption.IGNORE_CASE)



//=================================================
//General Config
//=================================================
val Whitespace_Pattern = Regex("\\s+")


//=================================================
//Relative Date Map 
//=================================================

enum class DateType {BASIC_RELATIVE, WEEKDAY, MULTI_RELATIVE}

val Word_Map = mapOf(
    "today" to (0L to DateType.BASIC_RELATIVE),
    "tomorrow" to (1L to DateType.BASIC_RELATIVE),
    
    "yesterday" to (-1L to DateType.BASIC_RELATIVE),
    "one day ago" to (-1L to DateType.BASIC_RELATIVE),
    "a day ago" to (-1L to DateType.BASIC_RELATIVE),
    
    "day after tomorrow" to (2L to DateType.BASIC_RELATIVE),
    "day before yesterday" to (-2L to DateType.BASIC_RELATIVE),
    



    "in" to (1L to DateType.MULTI_RELATIVE),
    "after" to (1L to DateType.MULTI_RELATIVE),
    "from" to (1L to DateType.MULTI_RELATIVE),
    "now" to (1L to DateType.MULTI_RELATIVE),
    "later" to (1L to DateType.MULTI_RELATIVE),
    
    "ago" to (-1L to DateType.MULTI_RELATIVE),
    "before" to (-1L to DateType.MULTI_RELATIVE),



    "this" to (0L to DateType.WEEKDAY),
    "next" to (1L to DateType.WEEKDAY),
    "last" to (-1L to DateType.WEEKDAY),

    "following" to (1L to DateType.WEEKDAY),
    "coming" to (1L to DateType.WEEKDAY),
    
    "previous" to (-1L to DateType.WEEKDAY),
    "preceding" to (-1L to DateType.WEEKDAY),
)

val Weekday_Map = mapOf(
        "monday" to 0,
        "mon" to 0,

        "tuesday" to 1,
        "tue" to 1,
        "tues" to 1,

        "wednesday" to 2,
        "wed" to 2,

        "thursday" to 3,
        "thu" to 3,
        "thur" to 3,
        "thurs" to 3,

        "friday" to 4,
        "fri" to 4,

        "saturday" to 5,
        "sat" to 5,

        "sunday" to 6,
        "sun" to 6
)
//=================================================
//Time Regex Pattern
//=================================================

// 1. Hour, minute, and second patterns
val Hour12 = """(?:1[0-2]|[1-9])"""
val Hour24_Unambiguous = """(?:1[3-9]|2[0-3])"""
val Minute = """[0-5]\d"""
val Second = """[0-5]\d"""

// 2. AM / PM
val Am_Pm = """(?i:AM|PM)"""

// 3. Day-period words
val Day_Period = """(?i:morning|afternoon|evening|night|tonight|noon|midday|midnight|dawn|sunrise|dusk|sunset)"""

// 4. 12-hour time with mandatory AM / PM
// Examples: 7 AM, 7:30 PM, 7:30:15 AM

val Time12 = """(?<hour12>$Hour12)(?::(?<minute12>$Minute)(?::(?<second12>$Second))?)?\s*(?<ampm>$Am_Pm)"""

// 5. Unambiguous 24-hour time
// Examples: 13:00, 19:30, 23:15:30
val Time24 = """(?<hour24>$Hour24_Unambiguous):(?<minute24>$Minute)(?::(?<second24>$Second))?"""

// 6. O'clock with mandatory AM / PM
// Examples: 7 o'clock AM, 7 o'clock PM
val O_Clock = """(?<oclockhour>$Hour12)\s+o['’]?clock\s*(?<oclockampm>$Am_Pm)"""

// 7. Clock time with day-period context
// Examples: 7 in the morning, 7:30 at night
val Clock_With_Period = """(?<clockperiodhour>$Hour12)(?::(?<clockperiodminute>$Minute)(?::(?<clockperiodsecond>$Second))?)?\s*(?:(?:in|at)\s+)?(?:the\s+)?(?:(?:early|late|mid)\s+)?(?<clockperiod>$Day_Period)"""

val Period_With_Clock = """(?:(?:early|late|mid)\s+)?(?<periodclock>$Day_Period)\s+(?:at\s+)?(?<periodclockhour>$Hour12)(?::(?<periodclockminute>$Minute)(?::(?<periodclocksecond>$Second))?)?(?:\s+o['’]?clock)?(?:\s*(?<periodclockampm>$Am_Pm))?"""


val Clock_Time_Pattern = Regex("""(?ix)(?<![\w:])(?:$Time12|$Time24|$O_Clock|$Clock_With_Period|$Period_With_Clock)(?![\w:])""".trimIndent())





//=================================================
//Explict Date Map
//=================================================

val Month_Map = mapOf(
    "january" to 1,
    "jan" to 1,

    "february" to 2,
    "feb" to 2,

    "march" to 3,
    "mar" to 3,

    "april" to 4,
    "apr" to 4,

    "may" to 5,

    "june" to 6,
    "jun" to 6,

    "july" to 7,
    "jul" to 7,

    "august" to 8,
    "aug" to 8,

    "september" to 9,
    "sep" to 9,

    "october" to 10,
    "oct" to 10,

    "november" to 11,
    "nov" to 11,

    "december" to 12,
    "dec" to 12
)

//=================================================
//Time Map
//=================================================

val Period_Map = mapOf(
    "morning" to "AM",
    "afternoon" to "PM",
    "evening" to "PM",
    "night" to "PM",
    "tonight" to "PM",
    "dawn" to "AM",
    "sunrise" to "AM",
    "dusk" to "PM",
    "sunset" to "PM",
    "noon" to "PM",
    "midday" to "PM",
    "midnight" to "AM"
)

fun Find_Relative_Date(Text: String): LocalDate? {

val Match = Relative_Date_Pattern.find(Text)?: return null
val Match_Text = Match.value.trim().lowercase()
val Result = Word_Map[Match_Text] ?: Match_Text.split(Whitespace_Pattern).firstNotNullOfOrNull { Word ->Word_Map[Word]} ?: return null

val Number = Result.first
val Type = Result.second

when (Type) {
DateType.BASIC_RELATIVE -> {
    return LocalDate.now().plusDays(Number)
}
DateType.MULTI_RELATIVE -> {
    val Days = Regex("""\d+""").find(Match_Text)?.value?.toLong() ?: return null
    return LocalDate.now().plusDays(Number * Days)
}
DateType.WEEKDAY -> {
    val Weekday_Number = Match_Text.split(Whitespace_Pattern).firstNotNullOfOrNull { Word ->Weekday_Map[Word]} ?: return null
    val Current_Week_Monday = LocalDate.now().with(DayOfWeek.MONDAY)
    return Current_Week_Monday.plusDays((Number * 7L) + Weekday_Number)
}
}
}

fun Find_Explicit_Date(Text: String): LocalDate? {
val Match = Explicit_Date_Pattern.find(Text) ?: return null

val Month_Text = Match.groups["month"]?.value ?: Match.groups["month2"]?.value
val Day_Text = Match.groups["day"]?.value ?: Match.groups["day2"]?.value
val Year_Text = Match.groups["year"]?.value ?: Match.groups["year2"]?.value

val Month = Month_Text?.lowercase()?.let { Month_Map[it] }
val Day = Day_Text ?.lowercase() ?.removeSuffix("st") ?.removeSuffix("nd") ?.removeSuffix("rd") ?.removeSuffix("th") ?.toIntOrNull()
val Year = Year_Text?.toIntOrNull()

val Numeric_Day = Match.groups["dayYearFirst"]?.value?.toIntOrNull() ?: Match.groups["dayFirst"]?.value?.toIntOrNull()
val Numeric_Month = Match.groups["monthYearFirst"]?.value?.toIntOrNull() ?: Match.groups["monthDayFirst"]?.value?.toIntOrNull()
val Numeric_Year_Text = Match.groups["yearFirst"]?.value ?: Match.groups["yearLast"]?.value

val Numeric_Year = Numeric_Year_Text?.let {
    if (it.length == 2) {
        2000 + it.toInt()
    } else {
        it.toInt()
    }
}

val Final_Month = Month ?: Numeric_Month
val Final_Day = Day ?: Numeric_Day
val Final_Year = Year ?: Numeric_Year ?: LocalDate.now().year

val Date = try {
    LocalDate.of(Final_Year, Final_Month ?: return null, Final_Day ?: return null)
} catch (e: DateTimeException) {
    return null
}
return Date
}


fun Find_Time(Text: String): LocalTime? {
val Match = Clock_Time_Pattern.find(Text) ?: return null

when {

    // Time12 → 7 AM, 7:30 PM, 7:30:15 AM
    Match.groups["hour12"] != null &&
    Match.groups["ampm"] != null -> {

        val Hour = Match.groups["hour12"]?.value?.toInt() ?: return null
        val Minute = Match.groups["minute12"]?.value?.toInt() ?: 0
        val Second = Match.groups["second12"]?.value?.toInt() ?: 0
        val Am_Pm = Match.groups["ampm"]?.value?.uppercase() ?: return null

        val Final_Hour = when {
            Am_Pm == "AM" && Hour == 12 -> 0
            Am_Pm == "PM" && Hour != 12 -> Hour + 12
            else -> Hour
        }

        return LocalTime.of(Final_Hour, Minute, Second)
    }


    // Time24 → 13:00, 19:30, 23:15:30
    Match.groups["hour24"] != null -> {

        val Hour = Match.groups["hour24"]?.value?.toInt() ?: return null
        val Minute = Match.groups["minute24"]?.value?.toInt() ?: return null
        val Second = Match.groups["second24"]?.value?.toInt() ?: 0

        return LocalTime.of(Hour, Minute, Second)
    }

    // O_Clock → 7 o'clock AM, 7 o'clock PM
    Match.groups["oclockhour"] != null &&
    Match.groups["oclockampm"] != null -> {

        val Hour = Match.groups["oclockhour"]?.value?.toInt() ?: return null
        val Am_Pm = Match.groups["oclockampm"]?.value?.uppercase() ?: return null

        val Final_Hour = when {
            Am_Pm == "AM" && Hour == 12 -> 0
            Am_Pm == "PM" && Hour != 12 -> Hour + 12
            else -> Hour
        }

        return LocalTime.of(Final_Hour, 0, 0)
    }


    // Clock_With_Period → 7 in the morning, 7:30 at night
    Match.groups["clockperiodhour"] != null &&
    Match.groups["clockperiod"] != null -> {

        val Hour = Match.groups["clockperiodhour"]?.value?.toInt() ?: return null
        val Minute = Match.groups["clockperiodminute"]?.value?.toInt() ?: 0
        val Second = Match.groups["clockperiodsecond"]?.value?.toInt() ?: 0
        val Period = Match.groups["clockperiod"]?.value?.lowercase() ?: return null

        val Am_Pm = Period_Map[Period] ?: return null

        val Final_Hour = when {
            Am_Pm == "AM" && Hour == 12 -> 0
            Am_Pm == "PM" && Hour != 12 -> Hour + 12
            else -> Hour
        }

        return LocalTime.of(Final_Hour, Minute, Second)
    }


    // Period_With_Clock → morning at 7, night at 8:30
    Match.groups["periodclock"] != null &&
    Match.groups["periodclockhour"] != null -> {

        val Period = Match.groups["periodclock"]?.value?.lowercase() ?: return null
        val Hour = Match.groups["periodclockhour"]?.value?.toInt() ?: return null
        val Minute = Match.groups["periodclockminute"]?.value?.toInt() ?: 0
        val Second = Match.groups["periodclocksecond"]?.value?.toInt() ?: 0

        val Am_Pm = Period_Map[Period] ?: return null

        val Final_Hour = when {
            Am_Pm == "AM" && Hour == 12 -> 0
            Am_Pm == "PM" && Hour != 12 -> Hour + 12
            else -> Hour
        }

        return LocalTime.of(Final_Hour, Minute, Second)
    }


    else -> {
        return null
    }
}
return null
}

data class TaskDateTime(
    val date: LocalDate?,
    val time: LocalTime?
)

fun findTaskDateTime(Text: String): TaskDateTime {

    val Date = Find_Relative_Date(Text)
        ?: Find_Explicit_Date(Text)

    val Time = if (Date != null) {
        Find_Time(Text)
    } else {
        null
    }


    return TaskDateTime(
        date = Date,
        time = Time
    )
}
fun main() {

    val Test_Texts = listOf(
        "Meeting today at 7 AM",
        "Meeting tomorrow at 8:30 PM",
        "Call yesterday at 13:00",
        "Task on 15/10",
        "Task on 15/10/2026",
        "Task on 2026-10-15",
        "Meeting on 15 October",
        "Meeting on October 15",
        "Meeting next Monday",
        "Meeting this Friday",
        "Meeting last Sunday",
        "Meeting in 2 days",
        "Meeting after 3 days",
        "Meeting 4 days ago",
        "Meeting at 19:30",
        "Meeting at 23:15:30",
        "Meeting at 12 AM",
        "Meeting at 12 PM",
        "Meeting at 7:30 in the morning",
        "Meeting at 8 at night",
        "Meeting morning at 9",
        "Meeting evening at 6:30",
        "Meeting at dawn",
        "Meeting at midnight",
        "Meeting today",
        "Meeting tomorrow",
        "Meeting yesterday",
        "Meeting day after tomorrow",
        "Meeting day before yesterday",
        "Meeting a day ago",
        "Meeting one day ago",
        "Meeting next Tuesday",
        "Meeting next Wednesday",
        "Meeting next Thursday",
        "Meeting next Friday",
        "Meeting next Saturday",
        "Meeting next Sunday",
        "Meeting last Monday",
        "Meeting last Tuesday",
        "Meeting last Wednesday",
        "Meeting last Thursday",
        "Meeting last Friday",
        "Meeting last Saturday",
        "Meeting last Sunday",
        "Meeting this Monday",
        "Meeting this Tuesday",
        "Meeting this Wednesday",
        "Meeting this Thursday",
        "Meeting this Friday",
        "Meeting this Saturday",
        "Meeting this Sunday",
        "Task on 01/01",
        "Task on 31/12",
        "Task on 29/02/2024",
        "Task on 30/02/2024",
        "Task on 31/04/2026",
        "Task on 15-08-2026",
        "Task on 25/12/26",
        "Task on 2026/12/25",
        "Task on 2026-12-25",
        "Task on January 1",
        "Task on February 28",
        "Task on March 15",
        "Task on April 30",
        "Task on May 10",
        "Task on June 20",
        "Task on July 4",
        "Task on August 15",
        "Task on September 10",
        "Task on October 2",
        "Task on November 25",
        "Task on December 31",
        "Task at 1 PM",
        "Task at 2 PM",
        "Task at 3 PM",
        "Task at 4 PM",
        "Task at 5 PM",
        "Task at 6 PM",
        "Task at 7 PM",
        "Task at 8 PM",
        "Task at 9 PM",
        "Task at 10 PM",
        "Task at 11 PM",
        "Task at 1 AM",
        "Task at 2 AM",
        "Task at 3 AM",
        "Task at 4 AM",
        "Task at 5 AM",
        "Task at 6 AM",
        "Task at 7 AM",
        "Task at 8 AM",
        "Task at 9 AM",
        "Task at 10 AM",
        "Task at 11 AM",
        "Task at 13:00",
        "Task at 14:30",
        "Task at 16:45",
        "Task at 18:20",
        "Task at 20:30",
        "Task at 22:15",
        "Task at 23:59",
        // =========================
    // Basic relative dates
    // =========================
    "Submit the project today",
    "Call the client tomorrow",
    "Review yesterday's meeting notes",
    "Finish the report day after tomorrow",
    "Complete the documentation day before yesterday",
    "Check the email a day ago",
    "Review the changes one day ago",

    // =========================
    // Multi relative dates
    // =========================
    "Submit the report in 2 days",
    "Call the customer in 5 days",
    "Review the task after 3 days",
    "Finish the deployment after 10 days from now",
    "Prepare the presentation in 7 days from today",
    "Check the server 2 days ago",
    "Review the logs 5 days before today",

    // =========================
    // Weekdays
    // =========================
    "Meeting next Monday",
    "Submit the report next Tuesday",
    "Call the client next Wednesday",
    "Deploy the application next Thursday",
    "Review the build next Friday",
    "Testing next Saturday",
    "Backup next Sunday",

    "Meeting this Monday",
    "Review this Tuesday",
    "Call this Wednesday",
    "Testing this Thursday",
    "Deployment this Friday",
    "Backup this Saturday",
    "Maintenance this Sunday",

    "Meeting last Monday",
    "Review last Tuesday",
    "Call last Wednesday",
    "Testing last Thursday",
    "Deployment last Friday",
    "Backup last Saturday",
    "Maintenance last Sunday",

    "Prepare the report coming Monday",
    "Review the code following Tuesday",
    "Deploy the application previous Friday",
    "Check the server preceding Sunday",

    // =========================
    // Explicit numeric dates
    // =========================
    "Submit the report on 15/10",
    "Submit the report on 15/10/26",
    "Submit the report on 15/10/2026",
    "Meeting scheduled for 01/01",
    "Meeting scheduled for 01/01/26",
    "Meeting scheduled for 01/01/2026",

    "Deployment planned for 15-08",
    "Deployment planned for 15-08-26",
    "Deployment planned for 15-08-2026",

    "Release scheduled for 2026/10/15",
    "Release scheduled for 2026-10-15",
    "Database migration on 2027/01/31",

    // =========================
    // Explicit textual dates
    // =========================
    "Meeting on January 15",
    "Meeting on January 15, 2026",
    "Meeting on 15 January",
    "Meeting on 15 January 2026",

    "Review the report on February 28",
    "Review the report on 28 February",
    "Deployment on March 10, 2026",
    "Testing on 10 March 2026",

    "Release on April 20",
    "Release on 20 April",
    "Maintenance on May 5",
    "Maintenance on 5 May",

    "Meeting on June 12, 2026",
    "Meeting on 12 June 2026",
    "Review on July 25",
    "Review on 25 July",

    "Deployment on August 15",
    "Deployment on 15 August 2026",
    "Testing on September 30",
    "Testing on 30 September 2026",

    "Release on October 2",
    "Release on 2 October 2026",
    "Review on November 25",
    "Review on 25 November 2026",

    "Final submission on December 31",
    "Final submission on 31 December 2026",

    // =========================
    // 12-hour clock times
    // =========================
    "Meeting at 7 AM",
    "Call the client at 8 AM",
    "Daily standup at 9:15 AM",
    "Lunch meeting at 12 PM",
    "Review the build at 1 PM",
    "Deployment at 2:30 PM",
    "Testing at 3:45 PM",
    "Discussion at 6 PM",
    "Dinner at 8:30 PM",
    "Night deployment at 11 PM",

    // =========================
    // 12-hour with seconds
    // =========================
    "Start the process at 7:30:15 AM",
    "Run the backup at 11:45:30 PM",
    "Start testing at 12:00:05 PM",
    "Stop the service at 12:30:45 AM",

    // =========================
    // 24-hour clock
    // =========================
    "Meeting at 13:00",
    "Meeting at 14:30",
    "Testing at 16:45",
    "Deployment at 18:20",
    "Backup at 20:30",
    "Maintenance at 22:15",
    "Server restart at 23:59",

    "Deployment starts at 13:00:15",
    "Testing starts at 18:30:45",
    "Backup starts at 23:15:30",

    // =========================
    // O'clock
    // =========================
    "Meeting at 7 o'clock AM",
    "Call at 9 o'clock AM",
    "Lunch at 12 o'clock PM",
    "Review at 3 o'clock PM",
    "Deployment at 7 o'clock PM",
    "Shutdown at 11 o'clock PM",

    // =========================
    // Clock + day period
    // =========================
    "Meeting at 7 in the morning",
    "Call at 8:30 in the morning",
    "Review at 12 in the afternoon",
    "Testing at 3:30 in the afternoon",
    "Deployment at 6 in the evening",
    "Dinner at 8:30 at night",
    "Backup at 11 late at night",
    "Start work at 6 early in the morning",

    // =========================
    // Day period + clock
    // =========================
    "Meeting morning at 7",
    "Meeting morning at 8:30",
    "Call afternoon at 2",
    "Review afternoon at 4:30",
    "Deployment evening at 6",
    "Dinner night at 9",
    "Backup late night at 11",
    "Start early morning at 5:30",

    // =========================
    // Special periods
    // =========================
    "Start the task at noon",
    "Check the system at midnight",
    "Start backup at dawn",
    "Take the reading at sunrise",
    "Check the server at dusk",
    "Finish the work at sunset",

    // =========================
    // Date + time combinations
    // =========================
    "Meeting today at 7 PM",
    "Call tomorrow at 8:30 AM",
    "Deployment today at 19:30",
    "Testing tomorrow at 13:45",
    "Review next Monday at 9 AM",
    "Meeting next Friday at 18:30",
    "Release on 15/10/2026 at 14:30",
    "Deployment on 20 October at 7 PM",
    "Testing on 25/12/26 at 23:15:30",
    "Review on 5 January 2027 at 10:30 AM",

    // =========================
    // Large / natural sentences
    // =========================
    "Please remind me to complete the customer portal deployment today at 7:30 PM after checking all the production logs.",
    "Tomorrow morning I need to review the API changes, update the documentation, and send the final report at 9 AM.",
    "The database migration should be completed on 15 October 2026 at 23:30 after taking a complete backup.",
    "Please schedule a meeting with the development team next Wednesday at 3:30 PM to discuss the new security requirements.",
    "I need to check the server logs two days from today at 11:45 PM and verify whether the scheduled backup completed successfully.",
    "Prepare the release notes on 25 December 2026 and send them to the team at 6 PM after testing the application.",
    "The production deployment is planned for next Friday at 19:30, so complete the final testing before the deployment window.",
    "Please remind me to review yesterday's failed transactions tomorrow at 10 AM and prepare a summary for the team.",
    "On 31 December 2026 at 11:59 PM, verify the final database backup and generate the yearly report.",

    // =========================
    // Negative / invalid dates
    // =========================
    "Meeting on 31/02/2026",
    "Meeting on 30/02/2024",
    "Meeting on 31/04/2026",
    "Meeting on 31/06/2026",
    "Meeting on 31/09/2026",
    "Meeting on 31/11/2026",
    "Meeting on 29/02/2025",
    "Meeting on 32/10/2026",
    "Meeting on 00/10/2026",
    "Meeting on 15/13/2026",

    // =========================
    // Negative / invalid formats
    // =========================
    "Meeting on 15.10.2026",
    "Meeting on 17/10/20/12",
    "Meeting on 15/10/2026/25",
    "Meeting on 2026/13/15",
    "Meeting on 2026/00/15",
    "Meeting on 2026/10/00",
    "Meeting on 2026-15-10",

    // =========================
    // Negative / ambiguous times
    // =========================
    "Meeting at 7",
    "Meeting at 8",
    "Meeting at 12",
    "Meeting at 25:00",
    "Meeting at 24:00",
    "Meeting at 19:60",
    "Meeting at 19:30:60",
    "Meeting at 12:70 PM",
    "Meeting at 13 PM",
    "Meeting at 0 PM",

    // =========================
    // Negative / malformed times
    // =========================
    "Meeting at 15:00:12:12",
    "Meeting at 7:60 PM",
    "Meeting at 7:30:70 PM",
    "Meeting at 13:60",
    "Meeting at 23:59:60",
    "Meeting at 19",
    "Meeting at 7:30",
    "Meeting at 12:30",

    // =========================
    // No date / no time
    // =========================
    "Complete the customer documentation",
    "Review the source code carefully",
    "Fix the login validation issue",
    "Check the production server logs",
    "Prepare the presentation for the team",
    "Update the database configuration",

    // =========================
    // Long mixed positive/negative inputs
    // =========================
    "Please review the failed transactions today at 7:30 PM and prepare the report for next Monday.",
    "The release is planned for 15/10/2026 at 19:30, but if testing fails review it tomorrow at 9 AM.",
    "Complete the backup on 31/02/2026 at 25:00 and report the result to the administrator.",
    "Schedule the deployment next Friday at 18:30 and verify the server again two days later.",
    "Review the application on 30 February 2026 at 7 PM even though that date is invalid.",
    "Prepare the final report on 25 December 2026 at midnight after checking all database transactions."
)

         var Test_Count = 0L

    for ((Index, Text) in Test_Texts.withIndex()) {

        val Start = System.nanoTime()

        val Result = findTaskDateTime(Text)

        val End = System.nanoTime()

        val Time_Nanoseconds = End - Start
        val Time_Microseconds = Time_Nanoseconds / 1_000.0
        val Time_Milliseconds = Time_Nanoseconds / 1_000_000.0

        Test_Count++

        println("==================================================")
        println("Test Count : $Test_Count")
        println("Test       : ${Index + 1}")
        println("Input      : $Text")
        println("Date       : ${Result.date}")
        println("Time       : ${Result.time}")
        println("Execution  : $Time_Nanoseconds ns")
        println("Execution  : $Time_Microseconds µs")
        println("Execution  : $Time_Milliseconds ms")
    }

    println("==================================================")
    println("Total Test Count : $Test_Count")
}


