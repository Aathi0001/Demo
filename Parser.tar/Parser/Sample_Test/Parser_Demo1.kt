package parser
import java.time.LocalDate
import java.time.LocalTime

data class TaskDateTime(
    val date: LocalDate?,
    val time: LocalTime?
)

fun findTaskDateTime(Text: String): TaskDateTime {

    val Date = Find_Relative_Date(Text)
        ?: Find_Explicit_Date(Text)

    val Time = if (Date != null) {
        Find_Time(Text)
    } else {
        null
    }

    return TaskDateTime(
        date = Date,
        time = Time
    )
}
fun main() {

    val TaskText = "Meeting scheduled today"

    val Result = findTaskDateTime(TaskText)

    println(Result.date)
    println(Result.time)
}

