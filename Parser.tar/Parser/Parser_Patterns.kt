package parser

//=================================================
//Relative Date Regex Patterns
//=================================================

val Basic_Relative_Regex = """\b(?:day\s+after\s+tomorrow|day\s+before\s+yesterday|today|tomorrow|yesterday|(?:a|one)\s+day\s+ago)\b"""
val Multi_Relative_Regex = """\b(?:(?:in|after)\s+\d+\s+days?(?:\s+(?:from\s+(?:now|today)|later))?|\d+\s+days?\s+(?:ago|before\s+today))\b"""
val Weekday_Regex = """\b(?:(?:(?:this|next|last)\s+week(?:'s)?\s+)|(?:(?:this\s+coming|coming|the\s+following|the\s+next|next|this|last|previous|the\s+preceding|preceding)\s+))(?:Monday|Mon|Tuesday|Tue|Tues|Wednesday|Wed|Thursday|Thu|Thur|Thurs|Friday|Fri|Saturday|Sat|Sunday|Sun)\b"""

val Relative_Date_Pattern = Regex("""(?:$Basic_Relative_Regex|$Multi_Relative_Regex|$Weekday_Regex)""",RegexOption.IGNORE_CASE)


//=================================================
//Explicit Date Regex Pattern
//=================================================

val Month_Regex = """(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sept(?:ember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)"""
val Day_Regex = """\d{1,2}(?:st|nd|rd|th)?"""
val Year_Regex = """(?:\d{2}|\d{4})"""

val Day_Number = """(?:0?[1-9]|[12]\d|3[01])"""
val Month_Number = """(?:0?[1-9]|1[0-2])"""
val Year_2 = """\d{2}"""
val Year_4 = """\d{4}"""


val Numeric_Regex = """(?<![\d/-])(?:(?<yearFirst>\d{4})[/-](?<monthYearFirst>$Month_Number)[/-](?<dayYearFirst>$Day_Number)|(?<dayFirst>$Day_Number)[/-](?<monthDayFirst>$Month_Number)(?:[/-](?<yearLast>$Year_2|$Year_4))?)(?![\d/-])""".trimIndent()

val Explicit_Date_Pattern = Regex("""(?i)(?:\b(?:(?<month>$Month_Regex)\s+(?<day>$Day_Regex)(?:,?\s+(?<year>$Year_Regex))?|(?<day2>$Day_Regex)\s+(?<month2>$Month_Regex)(?:\s+(?<year2>$Year_Regex))?)\b|$Numeric_Regex)""",RegexOption.IGNORE_CASE)

//=================================================
//Time Regex Pattern
//=================================================

// 1. Hour, minute, and second patterns
val Hour12 = """(?:1[0-2]|[1-9])"""
val Hour24_Unambiguous = """(?:1[3-9]|2[0-3])"""
val Minute = """[0-5]\d"""
val Second = """[0-5]\d"""

// 2. AM / PM
val Am_Pm = """(?i:AM|PM)"""

// 3. Day-period words
val Day_Period = """(?i:morning|afternoon|evening|night|tonight|noon|midday|midnight|dawn|sunrise|dusk|sunset)"""

// 4. 12-hour time with mandatory AM / PM
// Examples: 7 AM, 7:30 PM, 7:30:15 AM

val Time12 = """(?<hour12>$Hour12)(?::(?<minute12>$Minute)(?::(?<second12>$Second))?)?\s*(?<ampm>$Am_Pm)"""

// 5. Unambiguous 24-hour time
// Examples: 13:00, 19:30, 23:15:30
val Time24 = """(?<hour24>$Hour24_Unambiguous):(?<minute24>$Minute)(?::(?<second24>$Second))?"""

// 6. O'clock with mandatory AM / PM
// Examples: 7 o'clock AM, 7 o'clock PM
val O_Clock = """(?<oclockhour>$Hour12)\s+o['’]?clock\s*(?<oclockampm>$Am_Pm)"""

// 7. Clock time with day-period context
// Examples: 7 in the morning, 7:30 at night
val Clock_With_Period = """(?<clockperiodhour>$Hour12)(?::(?<clockperiodminute>$Minute)(?::(?<clockperiodsecond>$Second))?)?\s*(?:(?:in|at)\s+)?(?:the\s+)?(?:(?:early|late|mid)\s+)?(?<clockperiod>$Day_Period)"""

val Period_With_Clock = """(?:(?:early|late|mid)\s+)?(?<periodclock>$Day_Period)\s+(?:at\s+)?(?<periodclockhour>$Hour12)(?::(?<periodclockminute>$Minute)(?::(?<periodclocksecond>$Second))?)?(?:\s+o['’]?clock)?(?:\s*(?<periodclockampm>$Am_Pm))?"""


val Clock_Time_Pattern = Regex("""(?ix)(?<![\w:])(?:$Time12|$Time24|$O_Clock|$Clock_With_Period|$Period_With_Clock)(?![\w:])""".trimIndent())


//=================================================
//General Config
//=================================================
val Whitespace_Pattern = Regex("\\s+")
