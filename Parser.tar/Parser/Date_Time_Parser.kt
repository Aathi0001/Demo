package parser
import java.time.LocalDate
import java.time.LocalTime

fun Find_Relative_Date(Text: String): LocalDate? {

    val Match = Relative_Date_Pattern.find(Text)?: return null
    val Match_Text = Match.value.trim().lowercase()
    val Result = Word_Map[Match_Text] ?: Match_Text.split(Whitespace_Pattern).firstNotNullOfOrNull { Word ->Word_Map[Word]} ?: return null

    val Number = Result.first
    val Type = Result.second

    when (Type) {
        DateType.BASIC_RELATIVE -> {
            return LocalDate.now().plusDays(Number)
        }
        DateType.MULTI_RELATIVE -> {
            val Days = Regex("""\d+""").find(Match_Text)?.value?.toLong() ?: return null
            return LocalDate.now().plusDays(Number * Days)
        }
        DateType.WEEKDAY -> {
            val Weekday_Number = Match_Text.split(Whitespace_Pattern).firstNotNullOfOrNull { Word ->Weekday_Map[Word]} ?: return null
            val Current_Week_Monday = LocalDate.now().with(DayOfWeek.MONDAY)
            return Current_Week_Monday.plusDays((Number * 7L) + Weekday_Number)
        }
    }
}

fun Find_Explicit_Date(Text: String): LocalDate? {

    val Match = Explicit_Date_Pattern.find(Text) ?: return null

    val Month_Text = Match.groups["month"]?.value ?: Match.groups["month2"]?.value
    val Day_Text = Match.groups["day"]?.value ?: Match.groups["day2"]?.value
    val Year_Text = Match.groups["year"]?.value ?: Match.groups["year2"]?.value

    val Month = Month_Text?.lowercase()?.let { Month_Map[it] }
    val Day = Day_Text ?.lowercase() ?.removeSuffix("st") ?.removeSuffix("nd") ?.removeSuffix("rd") ?.removeSuffix("th") ?.toIntOrNull()
    val Year = Year_Text?.toIntOrNull()

    val Numeric_Day = Match.groups["dayYearFirst"]?.value?.toIntOrNull() ?: Match.groups["dayFirst"]?.value?.toIntOrNull()
    val Numeric_Month = Match.groups["monthYearFirst"]?.value?.toIntOrNull() ?: Match.groups["monthDayFirst"]?.value?.toIntOrNull()
    val Numeric_Year_Text = Match.groups["yearFirst"]?.value ?: Match.groups["yearLast"]?.value

    val Numeric_Year = Numeric_Year_Text?.let {
        if (it.length == 2) {
            2000 + it.toInt()
        } else {
            it.toInt()
        }
    }

    val Final_Month = Month ?: Numeric_Month
    val Final_Day = Day ?: Numeric_Day
    val Final_Year = Year ?: Numeric_Year ?: LocalDate.now().year

    val Date = try {
        LocalDate.of(Final_Year, Final_Month ?: return null, Final_Day ?: return null)
    } catch (e: DateTimeException) {
        return null
    }

    return Date
}


fun Find_Time(Text: String): LocalTime? {
    val Match = Clock_Time_Pattern.find(Text) ?: return null

    when {

        // Time12 → 7 AM, 7:30 PM, 7:30:15 AM
        Match.groups["hour12"] != null && Match.groups["ampm"] != null -> {
            val Hour = Match.groups["hour12"]?.value?.toInt() ?: return null
            val Minute = Match.groups["minute12"]?.value?.toInt() ?: 0
            val Second = Match.groups["second12"]?.value?.toInt() ?: 0
            val Am_Pm = Match.groups["ampm"]?.value?.uppercase() ?: return null

            val Final_Hour = when {
                Am_Pm == "AM" && Hour == 12 -> 0
                Am_Pm == "PM" && Hour != 12 -> Hour + 12
                else -> Hour
            }

            return LocalTime.of(Final_Hour, Minute, Second)
        }


        // Time24 → 13:00, 19:30, 23:15:30
        Match.groups["hour24"] != null -> {
            val Hour = Match.groups["hour24"]?.value?.toInt() ?: return null
            val Minute = Match.groups["minute24"]?.value?.toInt() ?: return null
            val Second = Match.groups["second24"]?.value?.toInt() ?: 0

            return LocalTime.of(Hour, Minute, Second)
        }

        // O_Clock → 7 o'clock AM, 7 o'clock PM
        Match.groups["oclockhour"] != null && Match.groups["oclockampm"] != null -> {
            val Hour = Match.groups["oclockhour"]?.value?.toInt() ?: return null
            val Am_Pm = Match.groups["oclockampm"]?.value?.uppercase() ?: return null

            val Final_Hour = when {
                Am_Pm == "AM" && Hour == 12 -> 0
                Am_Pm == "PM" && Hour != 12 -> Hour + 12
                else -> Hour
            }

            return LocalTime.of(Final_Hour, 0, 0)
        }

        // Clock_With_Period → 7 in the morning, 7:30 at night
        Match.groups["clockperiodhour"] != null && Match.groups["clockperiod"] != null -> {
            val Hour = Match.groups["clockperiodhour"]?.value?.toInt() ?: return null
            val Minute = Match.groups["clockperiodminute"]?.value?.toInt() ?: 0
            val Second = Match.groups["clockperiodsecond"]?.value?.toInt() ?: 0
            val Period = Match.groups["clockperiod"]?.value?.lowercase() ?: return null
            val Am_Pm = Period_Map[Period] ?: return null

            val Final_Hour = when {
                Am_Pm == "AM" && Hour == 12 -> 0
                Am_Pm == "PM" && Hour != 12 -> Hour + 12
                else -> Hour
            }

            return LocalTime.of(Final_Hour, Minute, Second)
        }

        // Period_With_Clock → morning at 7, night at 8:30
        Match.groups["periodclock"] != null &&
        Match.groups["periodclockhour"] != null -> {

            val Period = Match.groups["periodclock"]?.value?.lowercase() ?: return null
            val Hour = Match.groups["periodclockhour"]?.value?.toInt() ?: return null
            val Minute = Match.groups["periodclockminute"]?.value?.toInt() ?: 0
            val Second = Match.groups["periodclocksecond"]?.value?.toInt() ?: 0
            val Am_Pm = Period_Map[Period] ?: return null

            val Final_Hour = when {
                Am_Pm == "AM" && Hour == 12 -> 0
                Am_Pm == "PM" && Hour != 12 -> Hour + 12
                else -> Hour
            }

            return LocalTime.of(Final_Hour, Minute, Second)
        }


        else -> {
            return null
        }
    }
    return null
}
