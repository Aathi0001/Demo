package parser
//=================================================
//Relative Date Map 
//=================================================

enum class DateType {BASIC_RELATIVE, WEEKDAY, MULTI_RELATIVE}

val Word_Map = mapOf(
    "today" to (0L to DateType.BASIC_RELATIVE),
    "tomorrow" to (1L to DateType.BASIC_RELATIVE),
    
    "yesterday" to (-1L to DateType.BASIC_RELATIVE),
    "one day ago" to (-1L to DateType.BASIC_RELATIVE),
    "a day ago" to (-1L to DateType.BASIC_RELATIVE),
    
    "day after tomorrow" to (2L to DateType.BASIC_RELATIVE),
    "day before yesterday" to (-2L to DateType.BASIC_RELATIVE),
    



    "in" to (1L to DateType.MULTI_RELATIVE),
    "after" to (1L to DateType.MULTI_RELATIVE),
    "from" to (1L to DateType.MULTI_RELATIVE),
    "now" to (1L to DateType.MULTI_RELATIVE),
    "later" to (1L to DateType.MULTI_RELATIVE),
    
    "ago" to (-1L to DateType.MULTI_RELATIVE),
    "before" to (-1L to DateType.MULTI_RELATIVE),



    "this" to (0L to DateType.WEEKDAY),
    "next" to (1L to DateType.WEEKDAY),
    "last" to (-1L to DateType.WEEKDAY),

    "following" to (1L to DateType.WEEKDAY),
    "coming" to (1L to DateType.WEEKDAY),
    
    "previous" to (-1L to DateType.WEEKDAY),
    "preceding" to (-1L to DateType.WEEKDAY),
)

val Weekday_Map = mapOf(
        "monday" to 0,
        "mon" to 0,

        "tuesday" to 1,
        "tue" to 1,
        "tues" to 1,

        "wednesday" to 2,
        "wed" to 2,

        "thursday" to 3,
        "thu" to 3,
        "thur" to 3,
        "thurs" to 3,

        "friday" to 4,
        "fri" to 4,

        "saturday" to 5,
        "sat" to 5,

        "sunday" to 6,
        "sun" to 6
)



//=================================================
//Explict Date Map
//=================================================

val Month_Map = mapOf(
    "january" to 1,
    "jan" to 1,

    "february" to 2,
    "feb" to 2,

    "march" to 3,
    "mar" to 3,

    "april" to 4,
    "apr" to 4,

    "may" to 5,

    "june" to 6,
    "jun" to 6,

    "july" to 7,
    "jul" to 7,

    "august" to 8,
    "aug" to 8,

    "september" to 9,
    "sep" to 9,

    "october" to 10,
    "oct" to 10,

    "november" to 11,
    "nov" to 11,

    "december" to 12,
    "dec" to 12
)

//=================================================
//Time Map
//=================================================

val Period_Map = mapOf(
    "morning" to "AM",
    "afternoon" to "PM",
    "evening" to "PM",
    "night" to "PM",
    "tonight" to "PM",
    "dawn" to "AM",
    "sunrise" to "AM",
    "dusk" to "PM",
    "sunset" to "PM",
    "noon" to "PM",
    "midday" to "PM",
    "midnight" to "AM"
)

