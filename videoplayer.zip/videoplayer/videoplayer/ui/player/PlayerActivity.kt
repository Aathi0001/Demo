package com.example.videoplayer.ui.player

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.ui.PlayerView
import com.example.videoplayer.R
import com.example.videoplayer.config.GeneralConfig
import com.example.videoplayer.data.local.ResumeStore
import com.example.videoplayer.data.model.TrackType
import com.example.videoplayer.player.AudioNoisyReceiver
import com.example.videoplayer.player.PlayerEngine
import com.example.videoplayer.player.PlayerGestureCallback
import com.example.videoplayer.player.PlayerGestureListener
import com.example.videoplayer.player.ScreenshotPipeline
import com.example.videoplayer.player.TrackManager
import com.example.videoplayer.ui.tracks.TrackSelectionDialog
import com.example.videoplayer.utils.GeneralFunc

/**
 * =========================================================================
 * CLASS: PlayerActivity
 * Description: Core video player screen handling gestures, non-blocking frame
 *              capture, low-RAM state persistence, and vector HUD controls.
 * =========================================================================
 */
class PlayerActivity : AppCompatActivity(), PlayerGestureCallback {

    private lateinit var playerView: PlayerView
    private lateinit var playerEngine: PlayerEngine
    private lateinit var screenshotPipeline: ScreenshotPipeline
    private lateinit var resumeStore: ResumeStore
    private lateinit var audioNoisyReceiver: AudioNoisyReceiver
    private var trackManager: TrackManager? = null

    // UI Controls
    private lateinit var controlsOverlay: RelativeLayout
    private lateinit var touchLockOverlay: FrameLayout
    private lateinit var seekBar: SeekBar
    private lateinit var tvTimeCurrent: TextView
    private lateinit var tvTimeTotal: TextView
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnSpeed: Button

    // Floating Gesture HUD
    private lateinit var layoutGestureHud: View
    private lateinit var ivHudIcon: ImageView
    private lateinit var pbHudProgress: ProgressBar
    private lateinit var tvHudText: TextView

    private var videoUri: Uri? = null
    private var videoTitle: String = "Video"
    private var isLocked: Boolean = false
    private var currentSpeedIndex = 2 // 1.0x

    private val hideHandler = Handler(Looper.getMainLooper())
    private val hideControlsRunnable = Runnable { controlsOverlay.visibility = View.GONE }
    private val hideHudRunnable = Runnable { layoutGestureHud.visibility = View.GONE }

    private val progressHandler = Handler(Looper.getMainLooper())
    private val progressRunnable = object : Runnable {
        override fun run() {
            playerEngine.exoPlayer?.let { player ->
                if (player.isPlaying) {
                    val current = player.currentPosition
                    val total = player.duration.coerceAtLeast(0L)
                    seekBar.max = total.toInt()
                    seekBar.progress = current.toInt()
                    tvTimeCurrent.text = GeneralFunc.formatDurationToTime(current)
                    tvTimeTotal.text = GeneralFunc.formatDurationToTime(total)
                }
            }
            progressHandler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keep screen on during active playback
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)

        videoUri = intent.data
        videoTitle = intent.getStringExtra("VIDEO_TITLE") ?: "Video"

        initViews()
        initPlayerAndPipelines()
        setupListeners()
    }

    private fun initViews() {
        playerView = findViewById(R.id.playerView)
        controlsOverlay = findViewById(R.id.controlsOverlay)
        touchLockOverlay = findViewById(R.id.touchLockOverlay)
        seekBar = findViewById(R.id.seekBarProgress)
        tvTimeCurrent = findViewById(R.id.tvTimeCurrent)
        tvTimeTotal = findViewById(R.id.tvTimeTotal)
        btnPlayPause = findViewById(R.id.btnPlayPause)
        btnSpeed = findViewById(R.id.btnSpeed)
        findViewById<TextView>(R.id.tvVideoTitle).text = videoTitle

        // HUD views
        layoutGestureHud = findViewById(R.id.layoutGestureHud)
        ivHudIcon = findViewById(R.id.ivHudIcon)
        pbHudProgress = findViewById(R.id.pbHudProgress)
        tvHudText = findViewById(R.id.tvHudText)
    }

    private fun initPlayerAndPipelines() {
        resumeStore = ResumeStore(this)

        playerEngine = PlayerEngine(this, playerView) {
            // Video completed: clear resume cache
            videoUri?.let { resumeStore.deletePosition(it.toString()) }
            finish()
        }

        playerEngine.exoPlayer?.let { trackManager = TrackManager(it) }

        screenshotPipeline = ScreenshotPipeline(this) { savedUri, filename ->
            if (savedUri != null) {
                Toast.makeText(this, "Saved: $filename", Toast.LENGTH_SHORT).show()
            }
        }

        audioNoisyReceiver = AudioNoisyReceiver {
            playerEngine.exoPlayer?.pause()
            btnPlayPause.setImageResource(R.drawable.ic_play)
        }
        audioNoisyReceiver.register(this)

        // Load and resume position (<95%)
        val savedPosition = videoUri?.let { resumeStore.getSavedPosition(it.toString()) } ?: 0L
        videoUri?.let { playerEngine.playMedia(it, savedPosition) }

        progressHandler.post(progressRunnable)
    }

    private fun setupListeners() {
        val gestureListener = PlayerGestureListener(this, playerView, playerEngine, this)
        playerView.setOnTouchListener(gestureListener)

        btnPlayPause.setOnClickListener {
            val isPlaying = playerEngine.togglePlayPause()
            btnPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
            resetHideControlsTimer()
        }

        findViewById<ImageButton>(R.id.btnScreenshot).setOnClickListener {
            val currentPos = playerEngine.exoPlayer?.currentPosition ?: 0L
            screenshotPipeline.captureFrame(playerView, videoTitle, currentPos)
            resetHideControlsTimer()
        }

        findViewById<ImageButton>(R.id.btnTracks).setOnClickListener {
            trackManager?.let { tm ->
                TrackSelectionDialog(this, tm, TrackType.AUDIO).show()
            }
            resetHideControlsTimer()
        }

        btnSpeed.setOnClickListener {
            currentSpeedIndex = (currentSpeedIndex + 1) % GeneralConfig.PLAYBACK_SPEED_PRESETS.size
            val speed = GeneralConfig.PLAYBACK_SPEED_PRESETS[currentSpeedIndex]
            playerEngine.setPlaybackSpeed(speed)
            btnSpeed.text = "${speed}x"
            resetHideControlsTimer()
        }

        findViewById<ImageButton>(R.id.btnLock).setOnClickListener {
            setLockState(true)
        }

        findViewById<ImageButton>(R.id.btnUnlock).setOnClickListener {
            setLockState(false)
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    playerEngine.exoPlayer?.seekTo(progress.toLong())
                    tvTimeCurrent.text = GeneralFunc.formatDurationToTime(progress.toLong())
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { resetHideControlsTimer() }
            override fun onStopTrackingTouch(sb: SeekBar?) { resetHideControlsTimer() }
        })
    }

    private fun setLockState(locked: Boolean) {
        isLocked = locked
        touchLockOverlay.visibility = if (locked) View.VISIBLE else View.GONE
        controlsOverlay.visibility = View.GONE
    }

    private fun resetHideControlsTimer() {
        hideHandler.removeCallbacks(hideControlsRunnable)
        hideHandler.postDelayed(hideControlsRunnable, GeneralConfig.CONTROLS_HIDE_TIMEOUT_MS)
    }

    // --- PlayerGestureCallback Implementations ---

    override fun onSingleTap() {
        if (isLocked) return
        controlsOverlay.visibility = if (controlsOverlay.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        if (controlsOverlay.visibility == View.VISIBLE) resetHideControlsTimer()
    }

    override fun onDoubleTapSeek(isForward: Boolean, targetPositionMs: Long) {
        if (isLocked) return
	ivHudIcon.setImageResource(if (isForward) R.drawable.ic_forward_10 else R.drawable.ic_replay_10)
        pbHudProgress.visibility = View.GONE
        tvHudText.text = if (isForward) "+10s" else "-10s"
        
        displayGestureHud()
    }

    override fun onVolumeChanged(currentVolumeRatio: Float) {
        if (isLocked) return
        val percent = (currentVolumeRatio * 100).toInt()
        ivHudIcon.setImageResource(R.drawable.ic_volume)
        pbHudProgress.visibility = View.VISIBLE
        pbHudProgress.progress = percent
        tvHudText.text = "$percent%"
        
        displayGestureHud()
    }

    override fun onBrightnessChanged(currentBrightnessRatio: Float) {
        if (isLocked) return
        val percent = (currentBrightnessRatio * 100).toInt()
        ivHudIcon.setImageResource(R.drawable.ic_brightness)
        pbHudProgress.visibility = View.VISIBLE
        pbHudProgress.progress = percent
        tvHudText.text = "$percent%"
        
        displayGestureHud()
    }

    override fun onScaleChanged(scaleFactor: Float) {
        if (isLocked) return
        playerView.scaleX = scaleFactor
        playerView.scaleY = scaleFactor
    }

    private fun displayGestureHud() {
        layoutGestureHud.visibility = View.VISIBLE
        hideHandler.removeCallbacks(hideHudRunnable)
        hideHandler.postDelayed(hideHudRunnable, 1000)
    }

    override fun onPause() {
        super.onPause()
        playerEngine.exoPlayer?.let { player ->
            videoUri?.let { uri ->
                resumeStore.savePosition(uri.toString(), player.currentPosition, player.duration)
            }
            player.pause()
            btnPlayPause.setImageResource(R.drawable.ic_play)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        progressHandler.removeCallbacks(progressRunnable)
        audioNoisyReceiver.unregister(this)
        screenshotPipeline.release()
        playerEngine.release()
    }
}
