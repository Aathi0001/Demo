package com.example.videoplayer.ui.tracks

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import com.example.videoplayer.R
import com.example.videoplayer.data.model.TrackItem
import com.example.videoplayer.data.model.TrackType
import com.example.videoplayer.player.TrackManager

/**
 * =========================================================================
 * CLASS: TrackSelectionDialog
 * Description: Bottom-sheet style dialog for switching audio and subtitle tracks.
 * =========================================================================
 */
class TrackSelectionDialog(
    context: Context,
    private val trackManager: TrackManager,
    private val trackType: TrackType
) : Dialog(context) {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialog_track_selection)

        val tvTitle = findViewById<TextView>(R.id.tvDialogTitle)
        val rgTracks = findViewById<RadioGroup>(R.id.rgTracks)

        tvTitle.text = if (trackType == TrackType.AUDIO) "Select Audio Track" else "Select Subtitle Track"

        val tracks = trackManager.getAvailableTracks(trackType)

        // Add "Off" option for subtitles
        if (trackType == TrackType.SUBTITLE) {
            val rbOff = RadioButton(context).apply {
                text = "Off"
                setTextColor(0xFFEDEDED.toInt())
                isChecked = tracks.none { it.isSelected }
                setOnClickListener {
                    trackManager.disableTrackType(TrackType.SUBTITLE)
                    dismiss()
                }
            }
            rgTracks.addView(rbOff)
        }

        // Add dynamic stream options
        tracks.forEach { track ->
            val rb = RadioButton(context).apply {
                text = "${track.label} (${track.language ?: "und"})"
                setTextColor(0xFFEDEDED.toInt())
                isChecked = track.isSelected
                setOnClickListener {
                    trackManager.selectTrack(track)
                    dismiss()
                }
            }
            rgTracks.addView(rb)
        }
    }
}
