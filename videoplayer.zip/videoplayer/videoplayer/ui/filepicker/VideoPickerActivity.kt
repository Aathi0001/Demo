package com.example.videoplayer.ui.filepicker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.videoplayer.R
import com.example.videoplayer.config.ThemeManager
import com.example.videoplayer.config.ThemeMode
import com.example.videoplayer.config.backgroundArgb
import com.example.videoplayer.config.textPrimaryArgb
import com.example.videoplayer.config.textSecondaryArgb
import com.example.videoplayer.data.model.FolderItem
import com.example.videoplayer.data.model.VideoItem
import com.example.videoplayer.data.repository.VideoRepository
import com.example.videoplayer.ui.player.PlayerActivity
import com.example.videoplayer.utils.GeneralFunc
import kotlinx.coroutines.launch

/**
 * =========================================================================
 * CLASS: VideoPickerAdapter
 * Description: Renders folders and individual videos, applying the active
 *              color scheme directly from ThemeManager.
 * =========================================================================
 */
class VideoPickerAdapter(
    private val onFolderClick: (FolderItem) -> Unit,
    private val onVideoClick: (VideoItem) -> Unit
) : RecyclerView.Adapter<VideoPickerAdapter.ViewHolder>() {

    private var folderList: List<FolderItem> = emptyList()
    private var videoList: List<VideoItem> = emptyList()
    private var isFolderView = true

    fun setFolders(folders: List<FolderItem>) {
        isFolderView = true
        folderList = folders
        videoList = emptyList()
        notifyDataSetChanged()
    }

    fun setVideos(videos: List<VideoItem>) {
        isFolderView = false
        videoList = videos
        folderList = emptyList()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_2, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val colors = ThemeManager.colors
        if (isFolderView) {
            val folder = folderList[position]
            holder.text1.text = "📁 ${folder.folderName}"
            holder.text2.text = "${folder.videoCount} videos"
            holder.itemView.setOnClickListener { onFolderClick(folder) }
        } else {
            val video = videoList[position]
            holder.text1.text = "🎬 ${video.title}"
            holder.text2.text = GeneralFunc.formatDurationToTime(video.durationMs)
            holder.itemView.setOnClickListener { onVideoClick(video) }
        }

        // Apply theme text colors dynamically
        holder.text1.setTextColor(colors.textPrimaryArgb)
        holder.text2.setTextColor(colors.textSecondaryArgb)
    }

    override fun getItemCount(): Int = if (isFolderView) folderList.size else videoList.size

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val text1: TextView = view.findViewById(android.R.id.text1)
        val text2: TextView = view.findViewById(android.R.id.text2)
    }
}

/**
 * =========================================================================
 * CLASS: VideoPickerActivity
 * Description: Folder & video browser utilizing instant OS MediaStore queries
 *              with on-the-fly theme switching (Dark / Light / OLED).
 * =========================================================================
 */
class VideoPickerActivity : AppCompatActivity() {

    private lateinit var repo: VideoRepository
    private lateinit var adapter: VideoPickerAdapter
    private lateinit var rootLayout: View
    private lateinit var tvHeaderTitle: TextView
    private lateinit var btnToggleTheme: ImageButton
    private lateinit var tvEmptyState: TextView
    private var currentFolder: FolderItem? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video_picker)

        repo = VideoRepository(this)
        rootLayout = findViewById(R.id.rootPickerLayout)
        tvHeaderTitle = findViewById(R.id.tvHeaderTitle)
        btnToggleTheme = findViewById(R.id.btnToggleTheme)
        tvEmptyState = findViewById(R.id.tvEmptyState)

        val rv = findViewById<RecyclerView>(R.id.rvMediaList)
        rv.layoutManager = LinearLayoutManager(this)

        adapter = VideoPickerAdapter(
            onFolderClick = { folder ->
                currentFolder = folder
                tvHeaderTitle.text = folder.folderName
                loadVideosInFolder(folder.folderPath)
            },
            onVideoClick = { video ->
                val intent = Intent(this, PlayerActivity::class.java).apply {
                    data = video.uri
                    putExtra("VIDEO_TITLE", video.title)
                    putExtra("FOLDER_PATH", video.folderPath)
                }
                startActivity(intent)
            }
        )
        rv.adapter = adapter

        // Theme toggle button action: DARK -> LIGHT -> OLED_BLACK -> DARK
        btnToggleTheme.setOnClickListener {
            ThemeManager.currentMode = when (ThemeManager.currentMode) {
                ThemeMode.DARK -> ThemeMode.LIGHT
                ThemeMode.LIGHT -> ThemeMode.OLED_BLACK
                ThemeMode.OLED_BLACK -> ThemeMode.DARK
            }
            applyThemeColors()
            adapter.notifyDataSetChanged()
        }

        applyThemeColors()
        checkPermissionsAndLoad()
    }

    /**
     * Updates screen background, title, and button colors based on ThemeManager.
     */
    private fun applyThemeColors() {
        val colors = ThemeManager.colors
        rootLayout.setBackgroundColor(colors.backgroundArgb)
        tvHeaderTitle.setTextColor(colors.textPrimaryArgb)
        btnToggleTheme.setColorFilter(colors.textPrimaryArgb)
        tvEmptyState.setTextColor(colors.textSecondaryArgb)
    }

    private fun checkPermissionsAndLoad() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_VIDEO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            loadFolders()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(permission), 101)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            loadFolders()
        } else {
            Toast.makeText(this, "Permission required to load videos", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadFolders() {
        lifecycleScope.launch {
            val folders = repo.getAllFoldersWithVideos()
            tvHeaderTitle.text = "Video Folders"
            tvEmptyState.visibility = if (folders.isEmpty()) View.VISIBLE else View.GONE
            adapter.setFolders(folders)
        }
    }

    private fun loadVideosInFolder(folderPath: String) {
        lifecycleScope.launch {
            val videos = repo.getVideosInFolder(folderPath)
            tvEmptyState.visibility = if (videos.isEmpty()) View.VISIBLE else View.GONE
            adapter.setVideos(videos)
        }
    }

    override fun onBackPressed() {
        if (currentFolder != null) {
            currentFolder = null
            loadFolders()
        } else {
            super.onBackPressed()
        }
    }
}
