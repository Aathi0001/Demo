package com.example.videoplayer.ui.filepicker

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.videoplayer.R
import com.example.videoplayer.data.model.FolderItem
import com.example.videoplayer.data.model.VideoItem
import com.example.videoplayer.data.repository.VideoRepository
import com.example.videoplayer.ui.player.PlayerActivity
import com.example.videoplayer.utils.GeneralFunc
import kotlinx.coroutines.launch

/**
 * =========================================================================
 * CLASS: VideoPickerAdapter
 * Description: RecyclerView adapter rendering folders or video items.
 * =========================================================================
 */
class VideoPickerAdapter(
    private val onFolderClick: (FolderItem) -> Unit,
    private val onVideoClick: (VideoItem) -> Unit
) : RecyclerView.Adapter<VideoPickerAdapter.ViewHolder>() {

    private var folderList: List<FolderItem> = emptyList()
    private var videoList: List<VideoItem> = emptyList()
    private var isFolderView = true

    fun setFolders(folders: List<FolderItem>) {
        isFolderView = true
        folderList = folders
        videoList = emptyList()
        notifyDataSetChanged()
    }

    fun setVideos(videos: List<VideoItem>) {
        isFolderView = false
        videoList = videos
        folderList = emptyList()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_2, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        if (isFolderView) {
            val folder = folderList[position]
            holder.text1.text = "📁 ${folder.folderName}"
            holder.text2.text = "${folder.videoCount} videos"
            holder.itemView.setOnClickListener { onFolderClick(folder) }
        } else {
            val video = videoList[position]
            holder.text1.text = "🎬 ${video.title}"
            holder.text2.text = GeneralFunc.formatDurationToTime(video.durationMs)
            holder.itemView.setOnClickListener { onVideoClick(video) }
        }
        holder.text1.setTextColor(0xFFEDEDED.toInt())
        holder.text2.setTextColor(0xFFA0A0A0.toInt())
    }

    override fun getItemCount(): Int = if (isFolderView) folderList.size else videoList.size

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val text1: TextView = view.findViewById(android.R.id.text1)
        val text2: TextView = view.findViewById(android.R.id.text2)
    }
}
