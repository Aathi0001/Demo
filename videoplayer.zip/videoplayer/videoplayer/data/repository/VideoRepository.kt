package com.example.videoplayer.data.repository

import android.content.ContentUris
import android.content.Context
import com.example.videoplayer.config.QueryConfig
import com.example.videoplayer.data.model.FolderItem
import com.example.videoplayer.data.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * =========================================================================
 * CLASS: VideoRepository
 * Description: Reads instant OS-indexed media metadata from MediaStore,
 *              filters by supported video extensions, and groups into folders.
 * =========================================================================
 */
class VideoRepository(private val context: Context) {

    /**
     * -------------------------------------------------------------------------
     * Function: getAllFoldersWithVideos
     * Description: Retrieves all folders containing at least one supported video.
     * Input: None
     * Output: List<FolderItem> - List of unique folders with video counts.
     * -------------------------------------------------------------------------
     */
    suspend fun getAllFoldersWithVideos(): List<FolderItem> = withContext(Dispatchers.IO) {
        val allVideos = getAllSupportedVideos()
        val folderMap = mutableMapOf<String, Int>()

        allVideos.forEach { video ->
            val count = folderMap.getOrDefault(video.folderPath, 0)
            folderMap[video.folderPath] = count + 1
        }

        folderMap.map { (path, count) ->
            FolderItem(
                folderPath = path,
                folderName = path.substringAfterLast('/'),
                videoCount = count
            )
        }.sortedBy { it.folderName.lowercase() }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: getVideosInFolder
     * Description: Gets all supported video files located inside a selected folder.
     * Input: folderPath (String) - Target directory path.
     * Output: List<VideoItem> - Alphabetically sorted video files.
     * -------------------------------------------------------------------------
     */
    suspend fun getVideosInFolder(folderPath: String): List<VideoItem> = withContext(Dispatchers.IO) {
        getAllSupportedVideos().filter { it.folderPath == folderPath }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: getAllSupportedVideos
     * Description: Fetches and filters valid video media files using the OS index.
     * Input: None
     * Output: List<VideoItem> - Filtered list of supported video files.
     * -------------------------------------------------------------------------
     */
    suspend fun getAllSupportedVideos(): List<VideoItem> = withContext(Dispatchers.IO) {
        val videoList = mutableListOf<VideoItem>()

        val cursor = context.contentResolver.query(
            QueryConfig.VIDEO_CONTENT_URI,
            QueryConfig.VIDEO_PROJECTION,
            QueryConfig.VIDEO_SELECTION,
            null,
            QueryConfig.VIDEO_SORT_ORDER
        )

        cursor?.use {
            val idCol = it.getColumnIndexOrThrow(QueryConfig.VIDEO_PROJECTION[0])
            val nameCol = it.getColumnIndexOrThrow(QueryConfig.VIDEO_PROJECTION[1])
            val durationCol = it.getColumnIndexOrThrow(QueryConfig.VIDEO_PROJECTION[2])
            val sizeCol = it.getColumnIndexOrThrow(QueryConfig.VIDEO_PROJECTION[3])
            val dataCol = it.getColumnIndexOrThrow(QueryConfig.VIDEO_PROJECTION[4])
            val dateModCol = it.getColumnIndexOrThrow(QueryConfig.VIDEO_PROJECTION[5])

            while (it.moveToNext()) {
                val fullPath = it.getString(dataCol) ?: ""
                val extension = fullPath.substringAfterLast('.', "").lowercase()

                // Filter only formats explicitly supported
                if (!QueryConfig.SUPPORTED_VIDEO_EXTENSIONS.contains(extension)) {
                    continue
                }

                val id = it.getLong(idCol)
                val name = it.getString(nameCol) ?: "Unknown Video"
                val duration = it.getLong(durationCol)
                val size = it.getLong(sizeCol)
                val dateMod = it.getLong(dateModCol)
                val contentUri = ContentUris.withAppendedId(QueryConfig.VIDEO_CONTENT_URI, id)
                val folder = fullPath.substringBeforeLast('/', "Internal Storage")

                videoList.add(
                    VideoItem(
                        id = id,
                        title = name,
                        uri = contentUri,
                        durationMs = duration,
                        sizeBytes = size,
                        folderPath = folder,
                        dateModified = dateMod
                    )
                )
            }
        }

        videoList
    }

    /**
     * -------------------------------------------------------------------------
     * Function: getAdjacentVideosInFolder
     * Description: Identifies previous and next video items located in the same
     *              folder for Next/Prev episode switching.
     * Input: currentVideo (VideoItem), folderVideos (List<VideoItem>)
     * Output: Pair<VideoItem?, VideoItem?> - (PreviousVideo, NextVideo)
     * -------------------------------------------------------------------------
     */
    fun getAdjacentVideosInFolder(
        currentVideo: VideoItem,
        folderVideos: List<VideoItem>
    ): Pair<VideoItem?, VideoItem?> {
        val currentIndex = folderVideos.indexOfFirst { it.id == currentVideo.id }
        if (currentIndex == -1) return Pair(null, null)

        val previousVideo = if (currentIndex > 0) folderVideos[currentIndex - 1] else null
        val nextVideo = if (currentIndex < folderVideos.size - 1) folderVideos[currentIndex + 1] else null

        return Pair(previousVideo, nextVideo)
    }
}
