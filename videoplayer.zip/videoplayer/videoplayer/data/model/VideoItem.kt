package com.example.videoplayer.data.model

import android.net.Uri

/**
 * =========================================================================
 * Data Class: VideoItem
 * Description: Holds minimal metadata for a local video file scanned via MediaStore.
 * =========================================================================
 */
data class VideoItem(
    val id: Long,
    val title: String,
    val uri: Uri,
    val durationMs: Long,
    val sizeBytes: Long,
    val folderPath: String,
    val dateModified: Long
)
