package com.example.videoplayer.data.model

/**
 * =========================================================================
 * Data Class: FolderItem
 * Description: Represents a local directory containing supported video files.
 * =========================================================================
 */
data class FolderItem(
    val folderPath: String,
    val folderName: String,
    val videoCount: Int
)
