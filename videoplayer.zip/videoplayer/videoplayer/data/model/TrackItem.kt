package com.example.videoplayer.data.model

/**
 * =========================================================================
 * Enum & Data Class: TrackItem
 * Description: Represents individual Video, Audio, or Subtitle streams.
 * =========================================================================
 */
enum class TrackType {
    VIDEO,
    AUDIO,
    SUBTITLE
}

data class TrackItem(
    val groupIndex: Int,
    val trackIndex: Int,
    val type: TrackType,
    val label: String,
    val language: String?,
    val isSelected: Boolean,
    val mimeType: String? = null
)
