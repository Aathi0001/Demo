package com.example.videoplayer.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.videoplayer.config.GeneralConfig
import com.example.videoplayer.utils.CommonFunc
import com.example.videoplayer.utils.GeneralFunc

/**
 * =========================================================================
 * CLASS: ResumeStore
 * Description: Manages a lightweight key-value store in memory/disk capped at
 *              20 entries. Avoids SQL database overhead and automatically
 *              purges entries when videos pass the 95% completion mark.
 * =========================================================================
 */
class ResumeStore(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        GeneralConfig.RESUME_PREFS_NAME,
        Context.MODE_PRIVATE
    )

    /**
     * -------------------------------------------------------------------------
     * Function: savePosition
     * Description: Saves current timestamp for a video if eligible (<95%).
     *              Purges entry automatically if completion >= 95%.
     * Input: videoKey (String) - Video URI or file path identifier.
     *        positionMs (Long) - Current playback position.
     *        durationMs (Long) - Total media duration.
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun savePosition(videoKey: String, positionMs: Long, durationMs: Long) {
        val hashKey = GeneralFunc.generateMd5Hash(videoKey)

        if (!CommonFunc.isResumeEligible(positionMs, durationMs)) {
            // Reached >95% or not started: purge to ensure clean replay next time
            deletePosition(videoKey)
            return
        }

        pruneOldEntriesIfNeeded()

        prefs.edit()
            .putLong(hashKey, positionMs)
            .putLong("${hashKey}_timestamp", System.currentTimeMillis())
            .apply()
    }

    /**
     * -------------------------------------------------------------------------
     * Function: getSavedPosition
     * Description: Retrieves the saved playback timestamp for a video.
     * Input: videoKey (String) - Video URI or file path identifier.
     * Output: Long - Saved position in milliseconds (0L if not found).
     * -------------------------------------------------------------------------
     */
    fun getSavedPosition(videoKey: String): Long {
        val hashKey = GeneralFunc.generateMd5Hash(videoKey)
        return prefs.getLong(hashKey, 0L)
    }

    /**
     * -------------------------------------------------------------------------
     * Function: deletePosition
     * Description: Removes a saved resume state key manually or on completion.
     * Input: videoKey (String) - Video URI or file path identifier.
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun deletePosition(videoKey: String) {
        val hashKey = GeneralFunc.generateMd5Hash(videoKey)
        prefs.edit()
            .remove(hashKey)
            .remove("${hashKey}_timestamp")
            .apply()
    }

    /**
     * -------------------------------------------------------------------------
     * Function: pruneOldEntriesIfNeeded
     * Description: Ensures the store never exceeds 20 entries by removing the
     *              oldest accessed records.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun pruneOldEntriesIfNeeded() {
        val allEntries = prefs.all
        val timestampKeys = allEntries.keys.filter { it.endsWith("_timestamp") }

        if (timestampKeys.size >= GeneralConfig.RESUME_MAX_ENTRIES) {
            // Find oldest key by timestamp
            val oldestKey = timestampKeys.minByOrNull {
                (allEntries[it] as? Long) ?: Long.MAX_VALUE
            }

            oldestKey?.let { timeKey ->
                val baseHash = timeKey.removeSuffix("_timestamp")
                prefs.edit()
                    .remove(baseHash)
                    .remove(timeKey)
                    .apply()
            }
        }
    }
}
