package com.example.videoplayer.utils

import java.io.File
import java.security.MessageDigest

/**
 * =========================================================================
 * GENERAL FUNCTIONS (UNIVERSAL)
 * Contains pure, reusable helper methods that have zero app-specific
 * dependencies and can be used in any Kotlin/Android project.
 * =========================================================================
 */
object GeneralFunc {

    /**
     * -------------------------------------------------------------------------
     * Function: sanitizeFilename
     * Description: Removes illegal filesystem characters (\ / : * ? " < > |)
     *              from a string to ensure safe file creation across all OS storage.
     * Input: rawName (String) - Original filename or title.
     * Output: String - Sanitized string safe for filesystem use.
     * -------------------------------------------------------------------------
     */
    fun sanitizeFilename(rawName: String): String {
        val illegalCharsRegex = Regex("[\\\\/:*?\"<>|]")
        return rawName.replace(illegalCharsRegex, "_").trim()
    }

    /**
     * -------------------------------------------------------------------------
     * Function: stripFileExtension
     * Description: Strips the file extension from a filename or path.
     * Input: filename (String) - File name (e.g., "One_Piece_E1071.mkv").
     * Output: String - Base name without extension (e.g., "One_Piece_E1071").
     * -------------------------------------------------------------------------
     */
    fun stripFileExtension(filename: String): String {
        val dotIndex = filename.lastIndexOf('.')
        return if (dotIndex > 0) filename.substring(0, dotIndex) else filename
    }

    /**
     * -------------------------------------------------------------------------
     * Function: clampValue
     * Description: Restricts a given float value strictly between a defined
     *              minimum and maximum range (used for volume/brightness levels).
     * Input: value (Float) - Current dynamic value.
     *        min (Float) - Lower bound limit.
     *        max (Float) - Upper bound limit.
     * Output: Float - Value restricted within [min, max].
     * -------------------------------------------------------------------------
     */
    fun clampValue(value: Float, min: Float, max: Float): Float {
        return when {
            value < min -> min
            value > max -> max
            else -> value
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: calculateProgressRatio
     * Description: Calculates playback completion ratio without zero-division crashes.
     * Input: currentPositionMs (Long) - Current playback position in milliseconds.
     *        totalDurationMs (Long) - Total duration of media in milliseconds.
     * Output: Float - Ratio from 0.0f to 1.0f.
     * -------------------------------------------------------------------------
     */
    fun calculateProgressRatio(currentPositionMs: Long, totalDurationMs: Long): Float {
        if (totalDurationMs <= 0L) return 0.0f
        val ratio = currentPositionMs.toFloat() / totalDurationMs.toFloat()
        return clampValue(ratio, 0.0f, 1.0f)
    }

    /**
     * -------------------------------------------------------------------------
     * Function: generateMd5Hash
     * Description: Generates an MD5 hash of an input string (used for unique,
     *              fixed-length keys in the resume state store).
     * Input: input (String) - Raw input string (e.g., video URI or path).
     * Output: String - 32-character hexadecimal MD5 hash.
     * -------------------------------------------------------------------------
     */
    fun generateMd5Hash(input: String): String {
        val bytes = MessageDigest.getInstance("MD5").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: formatDurationToTime
     * Description: Converts a raw millisecond value into human-readable HH:MM:SS
     *              or MM:SS format for UI time displays.
     * Input: timeMs (Long) - Duration in milliseconds.
     * Output: String - Formatted time string (e.g., "23:41" or "01:15:30").
     * -------------------------------------------------------------------------
     */
    fun formatDurationToTime(timeMs: Long): String {
        if (timeMs <= 0L) return "00:00"
        val totalSeconds = timeMs / 1000
        val seconds = totalSeconds % 60
        val minutes = (totalSeconds / 60) % 60
        val hours = totalSeconds / 3600

        return if (hours > 0) {
            String.format("%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }
}
