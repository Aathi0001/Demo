package com.example.videoplayer.utils

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.example.videoplayer.config.GeneralConfig
import com.example.videoplayer.config.QueryConfig
import java.io.File
import java.io.FileOutputStream

/**
 * =========================================================================
 * COMMON FUNCTIONS (PROJECT-SPECIFIC)
 * Contains helper functions tailored for this player: screenshot file naming,
 * conflict resolution, non-blocking image writing, and MediaStore Scoped Storage.
 * =========================================================================
 */
object CommonFunc {

    /**
     * -------------------------------------------------------------------------
     * Function: generateScreenshotFilename
     * Description: Builds an ordered screenshot filename using the base title
     *              and the exact playback position in milliseconds.
     *              Pattern: [SanitizedTitle]_[PlaybackPositionMs].jpg
     * Input: videoTitle (String) - Raw video display name or file name.
     *        positionMs (Long) - Current playback timestamp in milliseconds.
     * Output: String - Base filename (e.g., "OnePiece_E1071_1421852.jpg").
     * -------------------------------------------------------------------------
     */
    fun generateScreenshotFilename(videoTitle: String, positionMs: Long): String {
        val baseTitle = GeneralFunc.stripFileExtension(videoTitle)
        val cleanTitle = GeneralFunc.sanitizeFilename(baseTitle)
        return "${cleanTitle}_${positionMs}${GeneralConfig.SCREENSHOT_FILE_EXTENSION}"
    }

    /**
     * -------------------------------------------------------------------------
     * Function: resolveConflictFilename
     * Description: Checks if a file exists on the legacy filesystem (Android 9 and below).
     *              If a conflict exists, it appends (1), (2), (3) before the extension.
     * Input: directory (File) - Target folder.
     *        filename (String) - Desired filename.
     * Output: File - Unique File reference ready for writing.
     * -------------------------------------------------------------------------
     */
    fun resolveConflictFilename(directory: File, filename: String): File {
        var targetFile = File(directory, filename)
        if (!targetFile.exists()) return targetFile

        val baseName = GeneralFunc.stripFileExtension(filename)
        val extension = GeneralConfig.SCREENSHOT_FILE_EXTENSION
        var count = 1

        while (targetFile.exists()) {
            targetFile = File(directory, "$baseName ($count)$extension")
            count++
        }
        return targetFile
    }

    /**
     * -------------------------------------------------------------------------
     * Function: saveBitmapToStorage
     * Description: Writes a Bitmap to the gallery under Pictures/AnimeCaptures/.
     *              - Android 10+: Uses MediaStore (system auto-appends (1), (2)).
     *              - Android 9-: Uses resolveConflictFilename to avoid overwriting.
     *              Immediately recycles the bitmap to preserve RAM on 2GB devices.
     * Input: context (Context) - Application or Activity context.
     *        bitmap (Bitmap) - The extracted frame buffer.
     *        filename (String) - Target filename from generateScreenshotFilename.
     * Output: Uri? - Uri of the saved image if successful, null on failure.
     * -------------------------------------------------------------------------
     */
    fun saveBitmapToStorage(context: Context, bitmap: Bitmap, filename: String): Uri? {
        var outputUri: Uri? = null
        val resolver = context.contentResolver

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Scoped Storage: Android MediaStore handles collisions automatically
                val contentValues = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                    put(MediaStore.Images.Media.MIME_TYPE, GeneralConfig.SCREENSHOT_MIME_TYPE)
                    put(MediaStore.Images.Media.RELATIVE_PATH, QueryConfig.RELATIVE_SCREENSHOT_PATH)
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }

                outputUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                outputUri?.let { uri ->
                    resolver.openOutputStream(uri)?.use { outStream ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, GeneralConfig.SCREENSHOT_JPEG_QUALITY, outStream)
                    }
                    contentValues.clear()
                    contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, contentValues, null, null)
                }
            } else {
                // Legacy storage: explicit conflict resolution
                val targetDir = File(QueryConfig.LEGACY_SCREENSHOT_PATH)
                if (!targetDir.exists()) {
                    targetDir.mkdirs()
                }

                val finalFile = resolveConflictFilename(targetDir, filename)
                FileOutputStream(finalFile).use { outStream ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, GeneralConfig.SCREENSHOT_JPEG_QUALITY, outStream)
                }
                outputUri = Uri.fromFile(finalFile)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            outputUri = null
        } finally {
            // Free native memory buffer immediately
            if (!bitmap.isRecycled) {
                bitmap.recycle()
            }
        }

        return outputUri
    }

    /**
     * -------------------------------------------------------------------------
     * Function: isResumeEligible
     * Description: Evaluates if a video position qualifies for the resume cache.
     *              Returns false if the video was watched past the 95% threshold
     *              or has not started yet (< 3 seconds).
     * Input: currentPositionMs (Long) - Playback position in milliseconds.
     *        durationMs (Long) - Total duration in milliseconds.
     * Output: Boolean - True if position should be saved, false if purged.
     * -------------------------------------------------------------------------
     */
    fun isResumeEligible(currentPositionMs: Long, durationMs: Long): Boolean {
        if (durationMs <= 0L || currentPositionMs < 3000L) return false
        val progress = GeneralFunc.calculateProgressRatio(currentPositionMs, durationMs)
        return progress < GeneralConfig.RESUME_PURGE_THRESHOLD_RATIO
    }
}
