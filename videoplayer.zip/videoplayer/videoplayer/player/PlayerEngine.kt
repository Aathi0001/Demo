package com.example.videoplayer.player

import android.content.Context
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.SeekParameters
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.example.videoplayer.config.GeneralConfig

/**
 * =========================================================================
 * CLASS: PlayerEngine
 * Description: High-performance lifecycle wrapper around AndroidX Media3 ExoPlayer.
 *              Configured with low-RAM load control, keyframe-synced seeking,
 *              hardware decoding with CPU fallback, and pitch-corrected speeds.
 * =========================================================================
 */
class PlayerEngine(
    private val context: Context,
    private val playerView: PlayerView,
    private val onPlaybackEnded: () -> Unit
) {
    var exoPlayer: ExoPlayer? = null
        private set

    init {
        initializePlayer()
    }

    /**
     * -------------------------------------------------------------------------
     * Function: initializePlayer
     * Description: Instantiates ExoPlayer with hardware codec prioritization
     *              and software fallback, attaching the low-RAM load control.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun initializePlayer() {
        val renderersFactory = DefaultRenderersFactory(context)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            .setEnableDecoderFallback(true) // Automatic CPU software fallback if GPU codec fails

        val loadControl = LowRamLoadControl.create()

        exoPlayer = ExoPlayer.Builder(context, renderersFactory)
            .setLoadControl(loadControl)
            .setSeekParameters(SeekParameters.CLOSEST_SYNC) // Instant keyframe seeking
            .build()
            .apply {
                playerView.player = this
                addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_ENDED) {
                            onPlaybackEnded()
                        }
                    }
                })
            }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: playMedia
     * Description: Prepares and starts playback for a specific video URI.
     * Input: uri (Uri) - Video content URI.
     *        startPositionMs (Long) - Resume position timestamp.
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun playMedia(uri: Uri, startPositionMs: Long = 0L) {
        exoPlayer?.let { player ->
            val mediaItem = MediaItem.fromUri(uri)
            player.setMediaItem(mediaItem)
            if (startPositionMs > 0L) {
                player.seekTo(startPositionMs)
            }
            player.prepare()
            player.playWhenReady = true
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: togglePlayPause
     * Description: Toggles current playback state immediately.
     * Input: None
     * Output: Boolean - New playing state (true if playing, false if paused).
     * -------------------------------------------------------------------------
     */
    fun togglePlayPause(): Boolean {
        exoPlayer?.let {
            if (it.isPlaying) {
                it.pause()
                return false
            } else {
                it.play()
                return true
            }
        }
        return false
    }

    /**
     * -------------------------------------------------------------------------
     * Function: seekRelative
     * Description: Skips backward or forward relative to current position.
     * Input: deltaMs (Long) - Time jump in ms (e.g. -10000L or +10000L).
     * Output: Long - Resulting playback position.
     * -------------------------------------------------------------------------
     */
    fun seekRelative(deltaMs: Long): Long {
        exoPlayer?.let { player ->
            val target = (player.currentPosition + deltaMs).coerceIn(0L, player.duration.coerceAtLeast(0L))
            player.seekTo(target)
            return target
        }
        return 0L
    }

    /**
     * -------------------------------------------------------------------------
     * Function: setPlaybackSpeed
     * Description: Changes playback rate with automatic audio pitch preservation.
     * Input: speed (Float) - Target speed factor (e.g., 0.75f, 1.25f, 2.0f).
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun setPlaybackSpeed(speed: Float) {
        val validSpeed = if (speed in GeneralConfig.PLAYBACK_SPEED_PRESETS) speed else GeneralConfig.DEFAULT_PLAYBACK_SPEED
        exoPlayer?.playbackParameters = PlaybackParameters(validSpeed)
    }

    /**
     * -------------------------------------------------------------------------
     * Function: release
     * Description: Immediately releases the ExoPlayer instance and unbinds the surface.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun release() {
        exoPlayer?.let {
            it.stop()
            it.clearMediaItems()
            it.release()
        }
        exoPlayer = null
        playerView.player = null
    }
}
