package com.example.videoplayer.player

import androidx.media3.common.C
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.upstream.DefaultAllocator
import com.example.videoplayer.config.GeneralConfig

/**
 * =========================================================================
 * OBJECT: LowRamLoadControl
 * Description: Factory producing a Media3 DefaultLoadControl tailored strictly
 *              for low-RAM hardware (2GB+ target). Restricts buffer duration
 *              and byte allocations to keep the active heap under 100MB.
 * =========================================================================
 */
object LowRamLoadControl {

    /**
     * -------------------------------------------------------------------------
     * Function: create
     * Description: Builds a tuned DefaultLoadControl instance with customized
     *              buffer durations and a strict 32MB target buffer pool.
     * Input: None
     * Output: DefaultLoadControl - Configured load controller for ExoPlayer.
     * -------------------------------------------------------------------------
     */
    fun create(): DefaultLoadControl {
        // Individual 64KB memory chunk allocator
        val allocator = DefaultAllocator(true, C.DEFAULT_BUFFER_SEGMENT_SIZE)

        return DefaultLoadControl.Builder()
            .setAllocator(allocator)
            .setBufferDurationsMs(
                GeneralConfig.BUFFER_MIN_MS,        // 15,000ms (15s minimum buffer)
                GeneralConfig.BUFFER_MAX_MS,        // 30,000ms (30s maximum buffer)
                GeneralConfig.BUFFER_PLAY_START_MS, // 1,500ms before starting playback
                GeneralConfig.BUFFER_REBUFFER_MS    // 2,000ms after rebuffering
            )
            .setTargetBufferBytes(GeneralConfig.BUFFER_TARGET_SIZE_BYTES) // 32MB cap
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()
    }
}
