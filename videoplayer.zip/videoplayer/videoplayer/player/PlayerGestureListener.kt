package com.example.videoplayer.player

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import com.example.videoplayer.config.GeneralConfig
import com.example.videoplayer.utils.GeneralFunc
import kotlin.math.abs

/**
 * =========================================================================
 * Interface: PlayerGestureCallback
 * Description: Callbacks dispatched to PlayerActivity for updating HUD overlays.
 * =========================================================================
 */
interface PlayerGestureCallback {
    fun onSingleTap()
    fun onDoubleTapSeek(isForward: Boolean, targetPositionMs: Long)
    fun onVolumeChanged(currentVolumeRatio: Float)
    fun onBrightnessChanged(currentBrightnessRatio: Float)
    fun onScaleChanged(scaleFactor: Float)
}

/**
 * =========================================================================
 * CLASS: PlayerGestureListener
 * Description: Touch listener managing single-tap play/pause, double-tap seek,
 *              pinch zoom, and vertical drag for brightness (left side) and
 *              volume (right side) without triggering system volume panels.
 * =========================================================================
 */
class PlayerGestureListener(
    private val context: Context,
    private val targetView: View,
    private val playerEngine: PlayerEngine,
    private val callback: PlayerGestureCallback
) : View.OnTouchListener {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat()

    private var isDragging = false
    private var isLeftSide = false
    private var currentScale = 1.0f

    // -------------------------------------------------------------------------
    // Gesture Detectors
    // -------------------------------------------------------------------------
    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            callback.onSingleTap()
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            val isForward = e.x > (targetView.width / 2)
            val delta = if (isForward) GeneralConfig.DOUBLE_TAP_SEEK_MS else -GeneralConfig.DOUBLE_TAP_SEEK_MS
            val newPosition = playerEngine.seekRelative(delta)
            callback.onDoubleTapSeek(isForward, newPosition)
            return true
        }

        override fun onScroll(
            e1: MotionEvent?,
            e2: MotionEvent,
            distanceX: Float,
            distanceY: Float
        ): Boolean {
            if (e1 == null) return false

            // Ignore horizontal scrubbing or scale touches during pinch
            if (abs(distanceX) > abs(distanceY)) return false

            if (!isDragging) {
                isDragging = true
                isLeftSide = e1.x < (targetView.width / 2)
            }

            val deltaRatio = (distanceY / targetView.height)

            if (isLeftSide) {
                adjustBrightness(deltaRatio)
            } else {
                adjustVolume(deltaRatio)
            }
            return true
        }
    })

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            currentScale *= detector.scaleFactor
            currentScale = GeneralFunc.clampValue(
                currentScale,
                GeneralConfig.MIN_PINCH_SCALE,
                GeneralConfig.MAX_PINCH_SCALE
            )
            callback.onScaleChanged(currentScale)
            return true
        }
    })

    /**
     * -------------------------------------------------------------------------
     * Function: onTouch
     * Description: Intercepts raw motion events and routes them to detectors.
     * Input: v (View), event (MotionEvent)
     * Output: Boolean - True if event consumed.
     * -------------------------------------------------------------------------
     */
    override fun onTouch(v: View, event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)

        if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_CANCEL) {
            isDragging = false
        }
        return true
    }

    /**
     * -------------------------------------------------------------------------
     * Function: adjustBrightness
     * Description: Adjusts window screen brightness attribute smoothly.
     * Input: deltaRatio (Float) - Drag ratio delta.
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun adjustBrightness(deltaRatio: Float) {
        val activity = context as? Activity ?: return
        val layoutParams = activity.window.attributes
        var currentBrightness = layoutParams.screenBrightness

        if (currentBrightness < 0f) currentBrightness = 0.5f // Default system baseline
        val newBrightness = GeneralFunc.clampValue(currentBrightness + deltaRatio, 0.01f, 1.0f)

        layoutParams.screenBrightness = newBrightness
        activity.window.attributes = layoutParams
        callback.onBrightnessChanged(newBrightness)
    }

    /**
     * -------------------------------------------------------------------------
     * Function: adjustVolume
     * Description: Adjusts stream music volume without showing system volume panel.
     * Input: deltaRatio (Float) - Drag ratio delta.
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun adjustVolume(deltaRatio: Float) {
        val currentVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
        val delta = deltaRatio * maxVolume
        val targetVol = GeneralFunc.clampValue(currentVol + delta, 0f, maxVolume)

        // FLAG_REMOVE_SOUND_AND_VIBRATE prevents the native Android system volume popup
        audioManager.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            targetVol.toInt(),
            AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE
        )
        callback.onVolumeChanged(targetVol / maxVolume)
    }
}
