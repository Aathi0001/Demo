package com.example.videoplayer.player

import androidx.media3.common.C
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import com.example.videoplayer.data.model.TrackItem
import com.example.videoplayer.data.model.TrackType

/**
 * =========================================================================
 * CLASS: TrackManager
 * Description: Wrapper interacting with Media3 Tracks API to parse, list,
 *              and switch embedded video, audio, and subtitle streams on the fly.
 * =========================================================================
 */
class TrackManager(private val player: ExoPlayer) {

    /**
     * -------------------------------------------------------------------------
     * Function: getAvailableTracks
     * Description: Scans current active media tracks and returns normalized TrackItems.
     * Input: type (TrackType) - Filter by VIDEO, AUDIO, or SUBTITLE.
     * Output: List<TrackItem> - Available streams for selection.
     * -------------------------------------------------------------------------
     */
    fun getAvailableTracks(type: TrackType): List<TrackItem> {
        val trackList = mutableListOf<TrackItem>()
        val currentTracks = player.currentTracks

        val targetTrackType = when (type) {
            TrackType.VIDEO -> C.TRACK_TYPE_VIDEO
            TrackType.AUDIO -> C.TRACK_TYPE_AUDIO
            TrackType.SUBTITLE -> C.TRACK_TYPE_TEXT
        }

        for (groupIndex in 0 until currentTracks.groups.size) {
            val group = currentTracks.groups[groupIndex]
            if (group.type != targetTrackType) continue

            for (trackIndex in 0 until group.length) {
                val format = group.getTrackFormat(trackIndex)
                val isSelected = group.isTrackSelected(trackIndex)

                val label = format.label ?: format.language ?: "Track ${trackList.size + 1}"

                trackList.add(
                    TrackItem(
                        groupIndex = groupIndex,
                        trackIndex = trackIndex,
                        type = type,
                        label = label,
                        language = format.language,
                        isSelected = isSelected,
                        mimeType = format.sampleMimeType
                    )
                )
            }
        }
        return trackList
    }

    /**
     * -------------------------------------------------------------------------
     * Function: selectTrack
     * Description: Overrides selection to switch active stream without reloading file.
     * Input: trackItem (TrackItem) - Selected stream item.
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun selectTrack(trackItem: TrackItem) {
        val currentTracks = player.currentTracks
        if (trackItem.groupIndex >= currentTracks.groups.size) return

        val group = currentTracks.groups[trackItem.groupIndex]
        val trackGroup = group.mediaTrackGroup

        val override = TrackSelectionOverride(trackGroup, trackItem.trackIndex)

        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setOverrideForType(override)
            .build()
    }

    /**
     * -------------------------------------------------------------------------
     * Function: disableTrackType
     * Description: Disables a specific stream type (e.g., turning subtitles OFF).
     * Input: type (TrackType) - The type to disable.
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun disableTrackType(type: TrackType) {
        val targetCtype = when (type) {
            TrackType.VIDEO -> C.TRACK_TYPE_VIDEO
            TrackType.AUDIO -> C.TRACK_TYPE_AUDIO
            TrackType.SUBTITLE -> C.TRACK_TYPE_TEXT
        }

        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(targetCtype, true)
            .build()
    }
}
