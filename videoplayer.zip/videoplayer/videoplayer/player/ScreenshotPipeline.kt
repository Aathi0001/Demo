package com.example.videoplayer.player

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.view.TextureView
import androidx.media3.ui.PlayerView
import com.example.videoplayer.config.GeneralConfig
import com.example.videoplayer.utils.CommonFunc
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * =========================================================================
 * Data Class: ScreenshotTask
 * Description: Internal payload holding the raw bitmap and metadata for IO saving.
 * =========================================================================
 */
data class ScreenshotTask(
    val bitmap: Bitmap,
    val filename: String
)

/**
 * =========================================================================
 * CLASS: ScreenshotPipeline
 * Description: Asynchronous FIFO screenshot queue that captures source frames
 *              directly from TextureView without pausing playback. Compresses
 *              and writes to storage on background IO with immediate RAM disposal.
 * =========================================================================
 */
class ScreenshotPipeline(
    private val context: Context,
    private val onScreenshotSaved: (Uri?, String) -> Unit
) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val queue = Channel<ScreenshotTask>(capacity = GeneralConfig.SCREENSHOT_QUEUE_CAPACITY)

    init {
        startWorker()
    }

    /**
     * -------------------------------------------------------------------------
     * Function: captureFrame
     * Description: Extracts raw source bitmap from TextureView synchronously (<2ms)
     *              and pushes to the background channel. Video playback never halts.
     * Input: playerView (PlayerView) - The active player view holding the surface.
     *        videoTitle (String) - Active video file/display name.
     *        currentPositionMs (Long) - Current playback position.
     * Output: Boolean - True if queued successfully, false if surface unavailable.
     * -------------------------------------------------------------------------
     */
    fun captureFrame(playerView: PlayerView, videoTitle: String, currentPositionMs: Long): Boolean {
        val surfaceView = playerView.videoSurfaceView as? TextureView ?: return false
        val bitmap = surfaceView.bitmap ?: return false

        val filename = CommonFunc.generateScreenshotFilename(videoTitle, currentPositionMs)
        val task = ScreenshotTask(bitmap = bitmap, filename = filename)

        val offerResult = queue.trySend(task)
        if (!offerResult.isSuccess) {
            // Buffer full: drop frame and recycle immediately to prevent OOM
            if (!bitmap.isRecycled) {
                bitmap.recycle()
            }
            return false
        }

        return true
    }

    /**
     * -------------------------------------------------------------------------
     * Function: startWorker
     * Description: Continuous background consumer that processes tasks from the
     *              Channel sequentially without starving the video decoder.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun startWorker() {
        scope.launch {
            for (task in queue) {
                val savedUri = CommonFunc.saveBitmapToStorage(context, task.bitmap, task.filename)
                withContext(Dispatchers.Main) {
                    onScreenshotSaved(savedUri, task.filename)
                }
            }
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: release
     * Description: Closes the screenshot queue channel and releases resources.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun release() {
        queue.close()
    }
}
