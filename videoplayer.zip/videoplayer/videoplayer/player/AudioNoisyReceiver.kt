package com.example.videoplayer.player

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager

/**
 * =========================================================================
 * CLASS: AudioNoisyReceiver
 * Description: BroadcastReceiver listening for ACTION_AUDIO_BECOMING_NOISY.
 *              Instantly pauses playback when headphones are unplugged or
 *              Bluetooth disconnects to prevent audio blast on loudspeaker.
 * =========================================================================
 */
class AudioNoisyReceiver(
    private val onAudioBecomingNoisy: () -> Unit
) : BroadcastReceiver() {

    private var isRegistered = false

    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY) {
            onAudioBecomingNoisy()
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: register
     * Description: Safely registers receiver for noisy audio broadcast intents.
     * Input: context (Context)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun register(context: Context) {
        if (!isRegistered) {
            val filter = IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY)
            context.registerReceiver(this, filter)
            isRegistered = true
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: unregister
     * Description: Unregisters receiver to prevent memory leaks.
     * Input: context (Context)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun unregister(context: Context) {
        if (isRegistered) {
            try {
                context.unregisterReceiver(this)
            } catch (e: IllegalArgumentException) {
                // Receiver was not registered or already unregistered
            }
            isRegistered = false
        }
    }
}
