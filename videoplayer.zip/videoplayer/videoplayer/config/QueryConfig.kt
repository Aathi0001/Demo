package com.example.videoplayer.config

import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore

/**
 * =========================================================================
 * QUERY & STORAGE CONFIGURATION
 * Holds MediaStore column projections, sort orders, MIME type filters,
 * and Scoped Storage directory paths.
 * =========================================================================
 */
object QueryConfig {

    // =========================================================================
    // 1. MEDIASTORE VIDEO QUERY CONFIGURATION
    // =========================================================================
    val VIDEO_CONTENT_URI: Uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

    /**
     * Columns fetched during local file scanning.
     * Keeps queries fast and lightweight without pulling heavy video metadata.
     */
    val VIDEO_PROJECTION: Array<String> = arrayOf(
        MediaStore.Video.Media._ID,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.Media.DURATION,
        MediaStore.Video.Media.SIZE,
        MediaStore.Video.Media.DATA,          // Absolute file path (for folder grouping)
        MediaStore.Video.Media.DATE_MODIFIED
    )

    /**
     * Sort local files by newest modified first.
     */
    const val VIDEO_SORT_ORDER: String = "${MediaStore.Video.Media.DATE_MODIFIED} DESC"

    /**
     * Filter only valid video media files.
     */
    const val VIDEO_SELECTION: String = "${MediaStore.Video.Media.DURATION} > 0"

    // =========================================================================
    // 2. SCREENSHOT OUTPUT DIRECTORY (SCOPED STORAGE)
    // =========================================================================
    /**
     * Relative path used for Android 10 (Q) and above in MediaStore.
     */
    val RELATIVE_SCREENSHOT_PATH: String = "${Environment.DIRECTORY_PICTURES}/${GeneralConfig.SCREENSHOT_FOLDER_NAME}"

    /**
     * Target directory path for legacy storage access (Android 9 and below).
     */
    val LEGACY_SCREENSHOT_PATH: String = "${Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)}/${GeneralConfig.SCREENSHOT_FOLDER_NAME}"

    // =========================================================================
    // 3. SUPPORTED SUBTITLE EXTENSIONS
    // =========================================================================

    val SUPPORTED_VIDEO_EXTENSIONS: Set<String> = setOf(
        "mp4", "mkv", "webm", "avi", "3gp", "ts", "m4v", "mov", "flv"
    )
    val SUPPORTED_SUBTITLE_EXTENSIONS: Set<String> = setOf(
        "srt",
        "ass",
        "ssa",
        "vtt"
    )
}
