package com.example.videoplayer.config

import androidx.compose.ui.graphics.Color

/**
 * =========================================================================
 * 1. RAW COLOR PALETTE (Hex values)
 * All raw hex colors live here. To update a shade across the entire app,
 * change its hex code here.
 * =========================================================================
 */
object RawColors {
    // Base Basics
    val PureBlack           = Color(0xFF000000)
    val PureWhite           = Color(0xFFFFFFFF)
    val Transparent         = Color(0x00000000)

    // Dark Theme Palette (Default)
    val DarkBackground      = Color(0xFF121212)
    val DarkSurface         = Color(0xFF1E1E1E)
    val DarkSurfaceVariant  = Color(0xFF2C2C2C)
    val DarkBorder          = Color(0xFF383838)
    val DarkTextPrimary     = Color(0xFFEDEDED)
    val DarkTextSecondary   = Color(0xFFA0A0A0)

    // Light Theme Palette
    val LightBackground     = Color(0xFFF8F9FA)
    val LightSurface        = Color(0xFFFFFFFF)
    val LightSurfaceVariant = Color(0xFFE9ECEF)
    val LightBorder         = Color(0xFFDEE2E6)
    val LightTextPrimary    = Color(0xFF212529)
    val LightTextSecondary  = Color(0xFF6C757D)

    // OLED Black Palette (Saves battery and optimizes low-RAM OLED rendering)
    val OledBackground      = Color(0xFF000000)
    val OledSurface         = Color(0xFF0D0D0D)
    val OledSurfaceVariant  = Color(0xFF171717)
    val OledBorder          = Color(0xFF262626)

    // UI Accent & Functional Status Colors
    val AccentRed           = Color(0xFFFF5252) // Default active/focus accent
    val AccentBlue          = Color(0xFF448AFF) // Seek bar, active track indicators
    val SuccessGreen        = Color(0xFF4CAF50) // Screenshot saved confirmation
    val WarningYellow       = Color(0xFFFFC107) // Alerts/notices
    val ErrorRed            = Color(0xFFCF6679) // Critical errors

    // HUD & Controller Overlays
    val OverlayScrim        = Color(0x99000000) // 60% Black for video controls
    val OverlayScrimHeavy   = Color(0xCC000000) // 80% Black for dialogs / touch lock
    val OverlayGestureHud   = Color(0xB3000000) // 70% Black for volume/brightness indicators
}

/**
 * =========================================================================
 * 2. SEMANTIC COLOR CONTRACT
 * Defines every variable name used across Compose UI screens and HUDs.
 * =========================================================================
 */
data class AppColorScheme(
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val border: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val accent: Color,
    val seekIndicator: Color,
    val overlayBackground: Color,
    val overlayDialog: Color,
    val gestureHudBackground: Color,
    val success: Color,
    val error: Color
)

/**
 * =========================================================================
 * 3. THEME DEFINITIONS
 * =========================================================================
 */
val DarkThemeColors = AppColorScheme(
    background = RawColors.DarkBackground,
    surface = RawColors.DarkSurface,
    surfaceVariant = RawColors.DarkSurfaceVariant,
    border = RawColors.DarkBorder,
    textPrimary = RawColors.DarkTextPrimary,
    textSecondary = RawColors.DarkTextSecondary,
    accent = RawColors.AccentRed,
    seekIndicator = RawColors.AccentBlue,
    overlayBackground = RawColors.OverlayScrim,
    overlayDialog = RawColors.OverlayScrimHeavy,
    gestureHudBackground = RawColors.OverlayGestureHud,
    success = RawColors.SuccessGreen,
    error = RawColors.ErrorRed
)

val LightThemeColors = AppColorScheme(
    background = RawColors.LightBackground,
    surface = RawColors.LightSurface,
    surfaceVariant = RawColors.LightSurfaceVariant,
    border = RawColors.LightBorder,
    textPrimary = RawColors.LightTextPrimary,
    textSecondary = RawColors.LightTextSecondary,
    accent = RawColors.AccentRed,
    seekIndicator = RawColors.AccentBlue,
    overlayBackground = RawColors.OverlayScrim,
    overlayDialog = RawColors.OverlayScrimHeavy,
    gestureHudBackground = RawColors.OverlayGestureHud,
    success = RawColors.SuccessGreen,
    error = RawColors.ErrorRed
)

val OledBlackThemeColors = AppColorScheme(
    background = RawColors.OledBackground,
    surface = RawColors.OledSurface,
    surfaceVariant = RawColors.OledSurfaceVariant,
    border = RawColors.OledBorder,
    textPrimary = RawColors.PureWhite,
    textSecondary = RawColors.DarkTextSecondary,
    accent = RawColors.AccentRed,
    seekIndicator = RawColors.AccentBlue,
    overlayBackground = RawColors.OverlayScrimHeavy,
    overlayDialog = RawColors.OverlayScrimHeavy,
    gestureHudBackground = RawColors.OverlayGestureHud,
    success = RawColors.SuccessGreen,
    error = RawColors.ErrorRed
)

/**
 * =========================================================================
 * 4. THEME CONTROLLER & REGISTRY
 * To add a new theme in the future:
 *   1. Add a key to ThemeMode enum.
 *   2. Add its corresponding AppColorScheme to themeRegistry.
 * =========================================================================
 */
enum class ThemeMode {
    DARK,
    LIGHT,
    OLED_BLACK
}

object ThemeManager {
    /**
     * Map of all registered themes.
     */
    val themeRegistry: Map<ThemeMode, AppColorScheme> = mapOf(
        ThemeMode.DARK to DarkThemeColors,
        ThemeMode.LIGHT to LightThemeColors,
        ThemeMode.OLED_BLACK to OledBlackThemeColors
    )

    /**
     * Active theme mode for the app. Defaults to DARK.
     */
    var currentMode: ThemeMode = ThemeMode.DARK

    /**
     * Accessor used in UI composables.
     * Example: ThemeManager.colors.background
     */
    val colors: AppColorScheme
        get() = themeRegistry[currentMode] ?: DarkThemeColors
}


// Add this extension property at the bottom of ColorConfig.kt
import androidx.compose.ui.graphics.toArgb

val AppColorScheme.backgroundArgb: Int get() = background.toArgb()
val AppColorScheme.surfaceArgb: Int get() = surface.toArgb()
val AppColorScheme.textPrimaryArgb: Int get() = textPrimary.toArgb()
val AppColorScheme.textSecondaryArgb: Int get() = textSecondary.toArgb()
val AppColorScheme.accentArgb: Int get() = accent.toArgb()
