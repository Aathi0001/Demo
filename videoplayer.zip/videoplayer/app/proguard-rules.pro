# Keep Media3 / ExoPlayer hardware codec wrappers
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Keep local data models
-keep class com.example.videoplayer.data.model.** { *; }
