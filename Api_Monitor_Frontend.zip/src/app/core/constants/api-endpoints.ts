export const ApiEndpoints = {

    SERVICES: 'http://192.168.12.225:8003/api/services',

    SERVICE_CHECK: (id: number) =>
        `http://192.168.12.225:8003/api/services/${id}/check`


    //SERVICES: 'http://127.0.0.1:8000/api/services',

    //SERVICE_CHECK: (id: number) =>
      //  `http://127.0.0.1:8000/api/services/${id}/check`

};
