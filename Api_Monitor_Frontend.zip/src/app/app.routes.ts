import {
    Routes
} from '@angular/router';

import {
    ServiceListComponent
} from './features/services/pages/service-list/service-list.component';

import {
    ServiceCreateComponent
} from './features/services/pages/service-create/service-create.component';

import {
    ServiceEditComponent
} from './features/services/pages/service-edit/service-edit.component';


export const routes: Routes = [

    {
        path: '',
        redirectTo: 'services',
        pathMatch: 'full'
    },

    {
        path: 'services',
        component: ServiceListComponent
    },

    {
        path: 'services/create',
        component: ServiceCreateComponent
    },

    {
        path: 'services/edit/:id',
        component: ServiceEditComponent
    },

    {
        path: '**',
        redirectTo: 'services'
    }

];
