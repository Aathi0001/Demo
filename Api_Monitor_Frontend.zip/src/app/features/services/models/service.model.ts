export interface ServiceModel {

    id: number;

    name: string;

    url: string;

    method: string;

    is_active: boolean;

    created_at: string;

    updated_at: string;

}


export interface CreateServiceRequest {

    name: string;

    url: string;

    method: string;

    is_active: boolean;

}


export interface UpdateServiceRequest {

    name?: string;

    url?: string;

    method?: string;

    is_active?: boolean;

}


export interface ServiceCheckResponse {

    service_id: number;

    name: string;

    url: string;

    method: string;

    is_reachable: boolean;

    status_code: number | null;

    response_time_ms: number | null;

    headers: Record<string, string>;

    body: string | null;

    error: string | null;

}
