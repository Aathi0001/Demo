import {
    inject,
    Injectable
} from '@angular/core';

import {
    HttpClient
} from '@angular/common/http';

import {
    Observable
} from 'rxjs';

import {
    ApiEndpoints
} from '../../../core/constants/api-endpoints';

import {
    CreateServiceRequest,
    ServiceCheckResponse,
    ServiceModel,
    UpdateServiceRequest
} from '../models/service.model';


@Injectable({
    providedIn: 'root'
})
export class ServiceService {

    private readonly http =
        inject(HttpClient);


    list(): Observable<ServiceModel[]> {

        return this.http.get<ServiceModel[]>(
            ApiEndpoints.SERVICES
        );

    }


    get(id: number): Observable<ServiceModel> {

        return this.http.get<ServiceModel>(
            `${ApiEndpoints.SERVICES}/${id}`
        );

    }


    create(
        request: CreateServiceRequest
    ): Observable<ServiceModel> {

        return this.http.post<ServiceModel>(
            ApiEndpoints.SERVICES,
            request
        );

    }


    update(
        id: number,
        request: UpdateServiceRequest
    ): Observable<ServiceModel> {

        return this.http.put<ServiceModel>(
            `${ApiEndpoints.SERVICES}/${id}`,
            request
        );

    }


    delete(
        id: number
    ): Observable<void> {

        return this.http.delete<void>(
            `${ApiEndpoints.SERVICES}/${id}`
        );

    }


    check(
        id: number
    ): Observable<ServiceCheckResponse> {

        return this.http.post<ServiceCheckResponse>(
            ApiEndpoints.SERVICE_CHECK(id),
            {}
        );

    }

}
