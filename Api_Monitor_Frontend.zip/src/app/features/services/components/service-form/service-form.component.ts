import {
    Component,
    EventEmitter,
    Input,
    OnChanges,
    OnInit,
    Output,
    SimpleChanges,
    inject
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

import {
    FormBuilder,
    ReactiveFormsModule,
    Validators
} from '@angular/forms';

import {
    CreateServiceRequest,
    UpdateServiceRequest,
    ServiceModel
} from '../../models/service.model';

@Component({

    selector: 'app-service-form',

    standalone: true,

    imports: [
        CommonModule,
        ReactiveFormsModule
    ],

    templateUrl: './service-form.component.html',

    styleUrl: './service-form.component.scss'

})
export class ServiceFormComponent
implements OnInit, OnChanges {


    private readonly fb =
        inject(FormBuilder);


    @Input()
    service: ServiceModel | null = null;


    @Input()
    loading = false;

//@Output()
//save =
  //  new EventEmitter<
    //    CreateServiceRequest | UpdateServiceRequest
   // >();

@Output()
save =
    new EventEmitter<CreateServiceRequest>();

    @Output()
    cancel =
        new EventEmitter<void>();


    readonly methods = [

        'GET',
        'POST',
        'PUT',
        'PATCH',
        'DELETE',
        'HEAD',
        'OPTIONS'

    ];


    readonly form =
        this.fb.nonNullable.group({

            name: [
                '',
                [
                    Validators.required,
                    Validators.maxLength(150)
                ]
            ],

            url: [
                '',
                [
                    Validators.required,
                    Validators.maxLength(2048)
                ]
            ],

            method: [
                'GET'
            ],

            is_active: [
                true
            ]

        });


    ngOnInit(): void {

        this.patchForm();

    }


    ngOnChanges(
        changes: SimpleChanges
    ): void {

        if (
            changes['service']
        ) {

            this.patchForm();

        }

    }


    private patchForm(): void {

        if (!this.service) {

            return;

        }


        this.form.patchValue({

            name: this.service.name,

            url: this.service.url,

            method: this.service.method,

            is_active: this.service.is_active

        });

    }


    onSubmit(): void {

        if (
            this.form.invalid
        ) {

            this.form.markAllAsTouched();

            return;

        }


        this.save.emit(
            this.form.getRawValue()
        );

    }


    onCancel(): void {

        this.cancel.emit();

    }

}
