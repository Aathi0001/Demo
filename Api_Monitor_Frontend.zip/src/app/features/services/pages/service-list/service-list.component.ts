import {
    Component,
    OnInit,
    inject
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

import {
    Router,
    RouterLink
} from '@angular/router';

import {
    ServiceService
} from '../../services/service.service';

import {
    ServiceCheckResponse,
    ServiceModel
} from '../../models/service.model';


@Component({

    selector: 'app-service-list',

    standalone: true,

    imports: [
        CommonModule,
    ],

    templateUrl: './service-list.component.html',

    styleUrl: './service-list.component.scss'

})
export class ServiceListComponent
implements OnInit {


    private readonly router =
        inject(Router);


    private readonly serviceService =
        inject(ServiceService);


    services: ServiceModel[] = [];


    checkingId: number | null = null;


    checkResults:
        Record<number, ServiceCheckResponse> = {};


    ngOnInit(): void {

        this.loadServices();

    }


    loadServices(): void {

        this.serviceService
            .list()
            .subscribe({

                next: (response) => {

                    this.services = response;

                },

                error: (error) => {

                    console.error(
                        'Failed to load services',
                        error
                    );

                }

            });

    }


    addService(): void {

        this.router.navigate([
            '/services/create'
        ]);

    }


    editService(
        service: ServiceModel
    ): void {

        this.router.navigate([
            '/services/edit',
            service.id
        ]);

    }


    checkService(
        service: ServiceModel
    ): void {

        this.checkingId = service.id;


        this.serviceService
            .check(service.id)
            .subscribe({

                next: (response) => {

                    this.checkResults[service.id] =
                        response;

                    this.checkingId = null;

                },

                error: (error) => {

                    console.error(
                        error
                    );

                    this.checkingId = null;

                }

            });

    }


    deleteService(
        service: ServiceModel
    ): void {

        if (

            !confirm(
                `Delete "${service.name}" ?`
            )

        ) {

            return;

        }


        this.serviceService
            .delete(service.id)
            .subscribe({

                next: () => {

                    this.services =
                        this.services.filter(

                            item =>
                                item.id !== service.id

                        );

                },

                error: (error) => {

                    console.error(
                        error
                    );

                }

            });

    }

}
