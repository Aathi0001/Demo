import {
    Component,
    inject
} from '@angular/core';

import {
    Router,
    RouterLink
} from '@angular/router';

import {
    ServiceFormComponent
} from '../../components/service-form/service-form.component';

import {
    CreateServiceRequest
} from '../../models/service.model';

import {
    ServiceService
} from '../../services/service.service';


@Component({

    selector: 'app-service-create',

    standalone: true,

    imports: [
        ServiceFormComponent,
        RouterLink
    ],

    templateUrl: './service-create.component.html',

    styleUrl: './service-create.component.scss'

})
export class ServiceCreateComponent {


    private readonly router =
        inject(Router);


    private readonly serviceService =
        inject(ServiceService);


    loading = false;


    save(
        request: CreateServiceRequest
    ): void {

        this.loading = true;


        this.serviceService
            .create(request)
            .subscribe({

                next: () => {

                    this.router.navigate([
                        '/services'
                    ]);

                },

                error: (error) => {

                    console.error(
                        'Failed to create service',
                        error
                    );

                    this.loading = false;

                }

            });

    }


    cancel(): void {

        this.router.navigate([
            '/services'
        ]);

    }

}
