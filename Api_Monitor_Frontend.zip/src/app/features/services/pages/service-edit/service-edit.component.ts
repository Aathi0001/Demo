import {
    Component,
    OnInit,
    inject
} from '@angular/core';

import {
    ActivatedRoute,
    Router,
    RouterLink
} from '@angular/router';

import {
    ServiceFormComponent
} from '../../components/service-form/service-form.component';

import {
    ServiceService
} from '../../services/service.service';

import {
    ServiceModel,
    UpdateServiceRequest
} from '../../models/service.model';


@Component({

    selector: 'app-service-edit',

    standalone: true,

    imports: [
        ServiceFormComponent,
        RouterLink
    ],

    templateUrl: './service-edit.component.html',

    styleUrl: './service-edit.component.scss'

})
export class ServiceEditComponent
implements OnInit {


    private readonly route =
        inject(ActivatedRoute);


    private readonly router =
        inject(Router);


    private readonly serviceService =
        inject(ServiceService);


    service: ServiceModel | null = null;


    loading = false;


    ngOnInit(): void {

        const id = Number(
            this.route.snapshot.paramMap.get('id')
        );

        this.loadService(
            id
        );

    }


    loadService(
        id: number
    ): void {

        this.serviceService
            .get(id)
            .subscribe({

                next: (response) => {

                    this.service = response;

                },

                error: (error) => {

                    console.error(
                        'Failed to load service',
                        error
                    );

                    this.router.navigate([
                        '/services'
                    ]);

                }

            });

    }


    save(
        request: UpdateServiceRequest
    ): void {

        if (!this.service) {

            return;

        }

        this.loading = true;

        this.serviceService
            .update(
                this.service.id,
                request
            )
            .subscribe({

                next: () => {

                    this.router.navigate([
                        '/services'
                    ]);

                },

                error: (error) => {

                    console.error(
                        'Failed to update service',
                        error
                    );

                    this.loading = false;

                }

            });

    }


    cancel(): void {

        this.router.navigate([
            '/services'
        ]);

    }

}
