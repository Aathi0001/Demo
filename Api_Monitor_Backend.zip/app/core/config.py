import sys
import pysqlite3

# This tricks Python into using pysqlite3 whenever a library looks for sqlite3
sys.modules["sqlite3"] = pysqlite3

# NOW you can safely load your environment variables and frameworks
DATABASE_URL = "sqlite:///./api_monitor.db"

