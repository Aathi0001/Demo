import time

import httpx
from sqlalchemy.orm import Session

from app.database.models import Service
from app.schemas.service_schema import (
    ServiceCreate,
    ServiceUpdate,
)


ALLOWED_METHODS = {
    "GET",
    "POST",
    "PUT",
    "PATCH",
    "DELETE",
    "HEAD",
    "OPTIONS",
}


def create_service(
    db: Session,
    data: ServiceCreate
) -> Service:

    method = data.method.upper()

    if method not in ALLOWED_METHODS:
        raise ValueError(
            f"Unsupported HTTP method: {method}"
        )

    service = Service(
        name=data.name,
        url=data.url,
        method=method,
        is_active=data.is_active
    )

    db.add(service)
    db.commit()
    db.refresh(service)

    return service


def get_services(
    db: Session
) -> list[Service]:

    return (
        db.query(Service)
        .order_by(Service.id.desc())
        .all()
    )


def get_service(
    db: Session,
    service_id: int
) -> Service | None:

    return (
        db.query(Service)
        .filter(Service.id == service_id)
        .first()
    )


def update_service(
    db: Session,
    service: Service,
    data: ServiceUpdate
) -> Service:

    update_data = data.model_dump(
        exclude_unset=True
    )

    if "method" in update_data:

        method = update_data["method"].upper()

        if method not in ALLOWED_METHODS:
            raise ValueError(
                f"Unsupported HTTP method: {method}"
            )

        update_data["method"] = method

    for field, value in update_data.items():

        setattr(
            service,
            field,
            value
        )

    db.commit()
    db.refresh(service)

    return service


def delete_service(
    db: Session,
    service: Service
) -> None:

    db.delete(service)

    db.commit()


async def check_service(
    service: Service
):

    start_time = time.perf_counter()

    try:

        async with httpx.AsyncClient(
            follow_redirects=True,
            timeout=10.0
        ) as client:

            response = await client.request(
                method=service.method,
                url=service.url
            )

        end_time = time.perf_counter()

        response_time = (
            end_time - start_time
        ) * 1000

        return {
            "service_id": service.id,
            "name": service.name,
            "url": service.url,
            "method": service.method,
            "is_reachable": True,
            "status_code": response.status_code,
            "response_time_ms": round(
                response_time,
                2
            ),
            "headers": dict(response.headers),
            "body": response.text,
            "error": None
        }

    except httpx.TimeoutException:

        return {
            "service_id": service.id,
            "name": service.name,
            "url": service.url,
            "method": service.method,
            "is_reachable": False,
            "status_code": None,
            "response_time_ms": None,
            "headers": {},
            "body": None,
            "error": "Request timed out"
        }

    except httpx.RequestError as error:

        return {
            "service_id": service.id,
            "name": service.name,
            "url": service.url,
            "method": service.method,
            "is_reachable": False,
            "status_code": None,
            "response_time_ms": None,
            "headers": {},
            "body": None,
            "error": str(error)
        }

    except Exception as error:

        return {
            "service_id": service.id,
            "name": service.name,
            "url": service.url,
            "method": service.method,
            "is_reachable": False,
            "status_code": None,
            "response_time_ms": None,
            "headers": {},
            "body": None,
            "error": str(error)
        }
