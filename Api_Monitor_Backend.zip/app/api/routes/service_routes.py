from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database.database import get_db
from app.schemas.service_schema import (
    ServiceCreate,
    ServiceResponse,
    ServiceUpdate,
    ServiceCheckResponse,
)
from app.services.service_service import (
    create_service,
    get_services,
    get_service,
    update_service,
    delete_service,
    check_service,
)


router = APIRouter(
    prefix="/api/services",
    tags=["Services"]
)


@router.post(
    "",
    response_model=ServiceResponse,
    status_code=status.HTTP_201_CREATED
)
def create(
    data: ServiceCreate,
    db: Session = Depends(get_db)
):

    try:

        return create_service(
            db,
            data
        )

    except ValueError as error:

        raise HTTPException(
            status_code=400,
            detail=str(error)
        )


@router.get(
    "",
    response_model=list[ServiceResponse]
)
def list_services(
    db: Session = Depends(get_db)
):

    return get_services(db)


@router.get(
    "/{service_id}",
    response_model=ServiceResponse
)
def get(
    service_id: int,
    db: Session = Depends(get_db)
):

    service = get_service(
        db,
        service_id
    )

    if not service:

        raise HTTPException(
            status_code=404,
            detail="Service not found"
        )

    return service


@router.put(
    "/{service_id}",
    response_model=ServiceResponse
)
def update(
    service_id: int,
    data: ServiceUpdate,
    db: Session = Depends(get_db)
):

    service = get_service(
        db,
        service_id
    )

    if not service:

        raise HTTPException(
            status_code=404,
            detail="Service not found"
        )

    try:

        return update_service(
            db,
            service,
            data
        )

    except ValueError as error:

        raise HTTPException(
            status_code=400,
            detail=str(error)
        )


@router.delete(
    "/{service_id}",
    status_code=status.HTTP_204_NO_CONTENT
)
def delete(
    service_id: int,
    db: Session = Depends(get_db)
):

    service = get_service(
        db,
        service_id
    )

    if not service:

        raise HTTPException(
            status_code=404,
            detail="Service not found"
        )

    delete_service(
        db,
        service
    )


@router.post(
    "/{service_id}/check",
    response_model=ServiceCheckResponse
)
async def check(
    service_id: int,
    db: Session = Depends(get_db)
):

    service = get_service(
        db,
        service_id
    )

    if not service:

        raise HTTPException(
            status_code=404,
            detail="Service not found"
        )

    return await check_service(
        service
    )
