from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.routes.service_routes import router as service_router
from app.database.database import Base, engine


Base.metadata.create_all(
    bind=engine
)


app = FastAPI(
    title="API Monitor",
    description="Simple API and website monitoring application",
    version="1.0.0"
)


app.add_middleware(

    CORSMiddleware,

    allow_origins=[

        "http://localhost:4200",

        "http://127.0.0.1:4200",

        "http://192.168.12.225:4003",

        "http://192.168.12.202:4200",

    ],

    allow_credentials=True,

    allow_methods=["*"],

    allow_headers=["*"],

)


app.include_router(
    service_router
)


@app.get("/")
def root():

    return {
        "message": "API Monitor is running"
    }


@app.get("/health")
def health():

    return {
        "status": "ok"
    }
