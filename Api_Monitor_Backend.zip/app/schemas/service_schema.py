from datetime import datetime

from pydantic import BaseModel, Field


class ServiceCreate(BaseModel):

    name: str = Field(
        min_length=1,
        max_length=150
    )

    url: str = Field(
        min_length=1,
        max_length=2048
    )

    method: str = Field(
        default="GET",
        min_length=1,
        max_length=10
    )

    is_active: bool = True


class ServiceUpdate(BaseModel):

    name: str | None = Field(
        default=None,
        min_length=1,
        max_length=150
    )

    url: str | None = Field(
        default=None,
        min_length=1,
        max_length=2048
    )

    method: str | None = Field(
        default=None,
        min_length=1,
        max_length=10
    )

    is_active: bool | None = None


class ServiceResponse(BaseModel):

    id: int
    name: str
    url: str
    method: str
    is_active: bool
    created_at: datetime
    updated_at: datetime

    model_config = {
        "from_attributes": True
    }


class ServiceCheckResponse(BaseModel):

    service_id: int
    name: str
    url: str
    method: str

    is_reachable: bool

    status_code: int | None
    response_time_ms: float | None

    headers: dict[str, str]
    body: str | None

    error: str | None
