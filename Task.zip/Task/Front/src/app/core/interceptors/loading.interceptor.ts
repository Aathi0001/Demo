import {
    HttpInterceptorFn
} from '@angular/common/http';

import {
    inject
} from '@angular/core';

import {
    finalize
} from 'rxjs';

import {
    NgxSpinnerService
} from 'ngx-spinner';


let activeRequests = 0;


export const loadingInterceptor: HttpInterceptorFn = (
    req,
    next
) => {

    const spinner = inject(
        NgxSpinnerService
    );

    activeRequests++;

    if (activeRequests === 1) {

        spinner.show();

    }

    return next(req).pipe(

        finalize(() => {

            activeRequests--;

            if (activeRequests === 0) {

                spinner.hide();

            }

        })

    );

};