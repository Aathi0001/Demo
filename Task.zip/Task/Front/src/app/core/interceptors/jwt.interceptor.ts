import {
    HttpInterceptorFn
} from '@angular/common/http';

import {
    inject
} from '@angular/core';

import {
    Router
} from '@angular/router';

import {
    BehaviorSubject,
    catchError,
    filter,
    switchMap,
    take,
    throwError
} from 'rxjs';

import {
    AuthService
} from '../../features/auth/services/auth';

import {
    TokenStorage
} from '../services/token-storage';


let isRefreshing = false;

const refreshTokenSubject =
    new BehaviorSubject<string | null>(null);


export const jwtInterceptor: HttpInterceptorFn = (
    req,
    next
) => {

    const authService =
        inject(AuthService);

    const tokenStorage =
        inject(TokenStorage);

    const router =
        inject(Router);


    // ==========================================
    // Skip Authentication APIs
    // ==========================================

    if (isAuthRequest(req.url)) {

        return next(req);

    }


    // ==========================================
    // Add Access Token
    // ==========================================

    const accessToken =
        tokenStorage.getAccessToken();


    if (accessToken) {

        req =
            addToken(
                req,
                accessToken
            );

    }


    // ==========================================
    // Send Request
    // ==========================================

    return next(req).pipe(

        catchError(error => {

            if (
                error.status !== 401 ||
                !tokenStorage.getRefreshToken()
            ) {

                return throwError(
                    () => error
                );

            }


            // ==================================
            // Another refresh is already running
            // ==================================

            if (isRefreshing) {

                return refreshTokenSubject.pipe(

                    filter(
                        token => token !== null
                    ),

                    take(1),

                    switchMap(
                        newAccessToken => {

                            return next(

                                addToken(
                                    req,
                                    newAccessToken
                                )

                            );

                        }

                    )

                );

            }


            // ==================================
            // Start refresh
            // ==================================

            isRefreshing = true;

            refreshTokenSubject.next(null);


            return authService
                .refreshToken(
                    tokenStorage.getRefreshToken()!
                )
                .pipe(

                    switchMap(
                        (response: any) => {

                            const newAccessToken =
                                response.data.access;


                            tokenStorage.setAccessToken(
                                newAccessToken
                            );


                            isRefreshing =
                                false;


                            refreshTokenSubject.next(
                                newAccessToken
                            );


                            return next(

                                addToken(
                                    req,
                                    newAccessToken
                                )

                            );

                        }

                    ),

                    catchError(
                        refreshError => {

                            isRefreshing =
                                false;


                            refreshTokenSubject.next(
                                null
                            );


                            tokenStorage.clear();


                            router.navigate([
                                '/login'
                            ]);


                            return throwError(
                                () => refreshError
                            );

                        }

                    )

                );

        })

    );

};


// ==========================================
// Helpers
// ==========================================

function addToken(
    request: any,
    token: string
) {

    return request.clone({

        setHeaders: {

            Authorization:
                `Bearer ${token}`

        }

    });

}


function isAuthRequest(
    url: string
): boolean {

    return (

        url.includes('/login/') ||

        url.includes('/register/') ||

        url.includes('/refresh/')

    );

}