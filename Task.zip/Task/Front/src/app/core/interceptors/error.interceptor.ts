import {
    HttpErrorResponse,
    HttpInterceptorFn
} from '@angular/common/http';

import { inject } from '@angular/core';

import { throwError } from 'rxjs';

import { catchError } from 'rxjs/operators';

import { ToastService } from '../services/toast.service';

export const errorInterceptor: HttpInterceptorFn = (

    request,
    next

) => {

    const toastService =
        inject(ToastService);

    return next(request).pipe(

        catchError(

            (
                error: HttpErrorResponse
            ) => {

                let message =
                    'Something went wrong.';

                if (
                    error.status === 0
                ) {

                    message =
                        'Unable to connect to server.';

                }

                else if (

                    error.error?.message

                ) {

                    message =
                        error.error.message;

                }

                else if (

                    error.status === 401

                ) {

                    message =
                        'Please login again.';

                }

                else if (

                    error.status === 403

                ) {

                    message =
                        'Permission denied.';

                }

                else if (

                    error.status === 404

                ) {

                    message =
                        'Resource not found.';

                }

                else if (

                    error.status >= 500

                ) {

                    message =
                        'Internal server error.';

                }

                toastService.showError(
                    message
                );

                return throwError(
                    () => error
                );

            }

        )

    );

};