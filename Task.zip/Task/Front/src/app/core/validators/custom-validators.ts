import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

export class CustomValidators {

  static noWhitespace(): ValidatorFn {

    return (control: AbstractControl): ValidationErrors | null => {

      const value = control.value;

      if (value == null) {
        return null;
      }

      return value.trim().length
        ? null
        : { whitespace: true };

    };

  }

  static passwordMatch(password: string, confirmPassword: string): ValidatorFn {

    return (control: AbstractControl): ValidationErrors | null => {

      const passwordControl = control.get(password);

      const confirmPasswordControl = control.get(confirmPassword);

      if (!passwordControl || !confirmPasswordControl) {
        return null;
      }

      if (passwordControl.value !== confirmPasswordControl.value) {

        confirmPasswordControl.setErrors({
          passwordMismatch: true
        });

        return {
          passwordMismatch: true
        };

      }

      if (confirmPasswordControl.hasError('passwordMismatch')) {

        confirmPasswordControl.setErrors(null);

      }

      return null;

    };

  }

}