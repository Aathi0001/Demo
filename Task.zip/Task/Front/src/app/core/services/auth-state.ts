import { Injectable } from '@angular/core';


@Injectable({
    providedIn:'root'
})
export class AuthState {


    isLoggedIn(): boolean {

        return !!localStorage.getItem(
            "access_token"
        );

    }


    logout(): void {


        localStorage.removeItem(
            "access_token"
        );


        localStorage.removeItem(
            "refresh_token"
        );


        localStorage.removeItem(
            "user"
        );


    }


}