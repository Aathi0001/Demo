import { Injectable } from '@angular/core';


@Injectable({
    providedIn: 'root'
})
export class TokenStorage {


    private ACCESS_TOKEN = 'access_token';

    private REFRESH_TOKEN = 'refresh_token';



    setTokens(
        access: string,
        refresh: string
    ): void {

        localStorage.setItem(
            this.ACCESS_TOKEN,
            access
        );


        localStorage.setItem(
            this.REFRESH_TOKEN,
            refresh
        );

    }

    setAccessToken(
        token:string
    ){

        localStorage.setItem(
            "access_token",
            token
        );

    }

    getAccessToken(): string | null {

        return localStorage.getItem(
            this.ACCESS_TOKEN
        );

    }



    getRefreshToken(): string | null {

        return localStorage.getItem(
            this.REFRESH_TOKEN
        );

    }



    clear(): void {

        localStorage.removeItem(
            this.ACCESS_TOKEN
        );


        localStorage.removeItem(
            this.REFRESH_TOKEN
        );

    }

}