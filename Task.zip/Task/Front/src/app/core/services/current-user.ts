import { Injectable } from '@angular/core';

export interface CurrentUser {

    id: number;

    username: string;

    display_name: string;

}

@Injectable({
    providedIn: 'root'
})
export class CurrentUserService {

    private readonly KEY = 'user';

    getUser(): CurrentUser | null {

        const value = localStorage.getItem(
            this.KEY
        );

        return value
            ? JSON.parse(value)
            : null;

    }

    setUser(user: CurrentUser): void {

        localStorage.setItem(
            this.KEY,
            JSON.stringify(user)
        );

    }

    clear(): void {

        localStorage.removeItem(
            this.KEY
        );

    }

}