import { ApiConstants } from './api.constants';

export class ApiEndpoints {

  static readonly REGISTER = `${ApiConstants.BASE_URL}/accounts/register/`;

  static readonly LOGIN = `${ApiConstants.BASE_URL}/accounts/login/`;

  static readonly REFRESH = `${ApiConstants.BASE_URL}/accounts/refresh/`;

  static readonly LOGOUT = `${ApiConstants.BASE_URL}/accounts/logout/`;

  static readonly PROFILE = `${ApiConstants.BASE_URL}/accounts/profile/`;

  static readonly SECURITY =
     `${ApiConstants.BASE_URL}/accounts/security/`;

  static readonly SET_LOCK_PASSWORD =
      `${ApiConstants.BASE_URL}/accounts/lock-password/set/`;

  static readonly VERIFY_LOCK_PASSWORD =
      `${ApiConstants.BASE_URL}/accounts/lock-password/verify/`;

  static readonly CHANGE_LOCK_PASSWORD =
      `${ApiConstants.BASE_URL}/accounts/lock-password/change/`;

  static readonly FORGOT_LOCK_PASSWORD =
      `${ApiConstants.BASE_URL}/accounts/lock-password/forgot/`;

  static readonly SET_DELETE_PASSWORD =
      `${ApiConstants.BASE_URL}/accounts/delete-password/set/`;

  static readonly VERIFY_DELETE_PASSWORD =
      `${ApiConstants.BASE_URL}/accounts/delete-password/verify/`;

  static readonly CHANGE_DELETE_PASSWORD =
      `${ApiConstants.BASE_URL}/accounts/delete-password/change/`;

  static readonly FORGOT_DELETE_PASSWORD =
      `${ApiConstants.BASE_URL}/accounts/delete-password/forgot/`;

  static readonly CHANGE_PASSWORD =
    `${ApiConstants.BASE_URL}/accounts/change-password/`;

  static readonly NOTIFICATIONS =
    `${ApiConstants.BASE_URL}/accounts/notifications/`;

  static readonly ANIME_STATUS_LIST =
    `${ApiConstants.BASE_URL}/anime/status/list/`;

static readonly ANIME_STATUS_CREATE =
    `${ApiConstants.BASE_URL}/anime/status/create/`;

static readonly ANIME_STATUS_UPDATE =
    `${ApiConstants.BASE_URL}/anime/status/update`;

static readonly ANIME_STATUS_CHANGE_STATE =
    `${ApiConstants.BASE_URL}/anime/status/change-state`;

  // ==============================
// Worklog Category
// ==============================

static readonly WORKLOG_CATEGORY_LIST =
    `${ApiConstants.BASE_URL}/worklog/category/list/`;

static readonly WORKLOG_CATEGORY_CREATE =
    `${ApiConstants.BASE_URL}/worklog/category/create/`;

static readonly WORKLOG_CATEGORY_UPDATE =
    `${ApiConstants.BASE_URL}/worklog/category/update`;

static readonly WORKLOG_CATEGORY_CHANGE_STATE =
    `${ApiConstants.BASE_URL}/worklog/category/change-state`;


// ==============================
// Worklog Project
// ==============================

static readonly WORKLOG_PROJECT_LIST =
    `${ApiConstants.BASE_URL}/worklog/project/list/`;

static readonly WORKLOG_PROJECT_CREATE =
    `${ApiConstants.BASE_URL}/worklog/project/create/`;

static readonly WORKLOG_PROJECT_UPDATE =
    `${ApiConstants.BASE_URL}/worklog/project/update`;

static readonly WORKLOG_PROJECT_CHANGE_STATE =
    `${ApiConstants.BASE_URL}/worklog/project/change-state`;


// ==============================
// Payment Method
// ==============================

static readonly PAYMENT_METHOD_LIST =
    `${ApiConstants.BASE_URL}/expense/payment-method/list/`;

static readonly PAYMENT_METHOD_CREATE =
    `${ApiConstants.BASE_URL}/expense/payment-method/create/`;

static readonly PAYMENT_METHOD_UPDATE =
    `${ApiConstants.BASE_URL}/expense/payment-method/update`;

static readonly PAYMENT_METHOD_CHANGE_STATE =
    `${ApiConstants.BASE_URL}/expense/payment-method/change-state`;


    

static readonly ANIME_LIST =
    `${ApiConstants.BASE_URL}/anime/list/`;

static readonly ANIME_CREATE =
    `${ApiConstants.BASE_URL}/anime/create/`;

static readonly ANIME_UPDATE =
    `${ApiConstants.BASE_URL}/anime/update`;

static readonly ANIME_SCHEDULE_DELETE =
    `${ApiConstants.BASE_URL}/anime/schedule-delete`;

static readonly ANIME_RESTORE =
    `${ApiConstants.BASE_URL}/anime/restore`;

static readonly ANIME_PERMANENT_DELETE =
    `${ApiConstants.BASE_URL}/anime/permanent-delete`;

    static readonly NOTE_LIST =
`${ApiConstants.BASE_URL}/notes/list/`;


static readonly NOTE_CREATE =
`${ApiConstants.BASE_URL}/notes/create/`;


static readonly NOTE_UPDATE =
`${ApiConstants.BASE_URL}/notes/update`;


static readonly NOTE_UNLOCK =
`${ApiConstants.BASE_URL}/notes/unlock`;


static readonly NOTE_SCHEDULE_DELETE =
`${ApiConstants.BASE_URL}/notes/schedule-delete`;


static readonly NOTE_RESTORE =
`${ApiConstants.BASE_URL}/notes/restore`;


static readonly NOTE_PERMANENT_DELETE =
`${ApiConstants.BASE_URL}/notes/permanent-delete`;

static readonly NOTE_DETAIL =
`${ApiConstants.BASE_URL}/notes/detail`;


static readonly WORKLOG_LIST =
`${ApiConstants.BASE_URL}/worklog/list/`;

static readonly WORKLOG_DETAIL =
`${ApiConstants.BASE_URL}/worklog/detail`;

static readonly WORKLOG_CREATE =
`${ApiConstants.BASE_URL}/worklog/create/`;

static readonly WORKLOG_UPDATE =
`${ApiConstants.BASE_URL}/worklog/update`;

static readonly WORKLOG_SCHEDULE_DELETE =
`${ApiConstants.BASE_URL}/worklog/schedule-delete`;

static readonly WORKLOG_RESTORE =
`${ApiConstants.BASE_URL}/worklog/restore`;

static readonly WORKLOG_PERMANENT_DELETE =
`${ApiConstants.BASE_URL}/worklog/permanent-delete`;


static readonly EXPENSE_LIST =
`${ApiConstants.BASE_URL}/expense/list/`;

static readonly EXPENSE_CREATE =
`${ApiConstants.BASE_URL}/expense/create/`;

static readonly EXPENSE_DETAIL =
`${ApiConstants.BASE_URL}/expense/detail`;

static readonly EXPENSE_UPDATE =
`${ApiConstants.BASE_URL}/expense/update`;

static readonly EXPENSE_DELETE =
`${ApiConstants.BASE_URL}/expense/schedule-delete`;

static readonly EXPENSE_RESTORE =
`${ApiConstants.BASE_URL}/expense/restore`;

static readonly EXPENSE_PERMANENT_DELETE =
`${ApiConstants.BASE_URL}/expense/permanent-delete`;

static readonly WORKLOG_TIMELINE =
`${ApiConstants.BASE_URL}/worklog/timeline/`;

static readonly WORKLOG_TIMELINE_YEARS =
`${ApiConstants.BASE_URL}/worklog/timeline/years/`;

static readonly EXPENSE_TIMELINE_MONTH =
`${ApiConstants.BASE_URL}/expense/timeline/month/`;

static readonly EXPENSE_TIMELINE_YEARS =
`${ApiConstants.BASE_URL}/expense/timeline/years/`;

}

