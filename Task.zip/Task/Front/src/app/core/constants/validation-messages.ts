export class ValidationMessages {

    static readonly REQUIRED = 'This field is required.';

    static readonly EMAIL = 'Please enter a valid email address.';

    static readonly MIN_LENGTH = 'Minimum length not met.';

    static readonly MAX_LENGTH = 'Maximum length exceeded.';

    static readonly PASSWORD_PATTERN =
        'Password must contain uppercase, lowercase, number and special character.';

    static readonly PASSWORD_MATCH =
        'Passwords do not match.';
      static readonly WHITESPACE =
    'Only whitespace is not allowed.';

}