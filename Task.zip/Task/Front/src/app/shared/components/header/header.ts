import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { DatePipe, CommonModule } from '@angular/common';

import { AuthService } from '../../../features/auth/services/auth';
import { AuthState } from '../../../core/services/auth-state';
import { CurrentUserService } from '../../../core/services/current-user';

import { NotificationService } from '../../../features/profile/services/notification'
import { Notification } from '../../../features/profile/models/notification';

import { RouterLink } from '@angular/router';

import { ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [ RouterLink, DatePipe, CommonModule ],
  templateUrl: './header.html',
  styleUrl: './header.scss',
})

export class Header  {


    private authService = inject(AuthService);

    private authState = inject(AuthState);

    private router = inject(Router);

    private currentUser = inject(CurrentUserService);

    private notificationService = inject(NotificationService);

    private cdr = inject(ChangeDetectorRef);

notificationCount = 0;
notifications: Notification[] = [];

showNotifications = false;



    displayName =
    this.currentUser.getUser()?.display_name
    ?? 'User';

    ngOnInit()
    {
        this.loadNotifications();
    }

    toggleNotifications(): void {

    this.showNotifications =
        !this.showNotifications;

}

    loadNotifications(): void {

    this.notificationService
        .getNotifications()
        .subscribe({

            next: (response) => {

                this.notificationCount =
                    response.data.count;

                this.notifications =
                    response.data.notifications;

                this.cdr.detectChanges();

            }

        });

}
    logout(){


        const refreshToken =
            localStorage.getItem(
                "refresh_token"
            );


        if(refreshToken){


            this.authService.logout(
                refreshToken
            )
            .subscribe({

                next:()=>{

                    this.clearSession();

                },


                error:()=>{

                    // even if backend fails,
                    // remove local session

                    this.clearSession();

                }

            });


        }
        else{

            this.clearSession();

        }


    }



    private clearSession(){


        this.authState.logout();


        this.router.navigate([
            "/login"
        ]);


    }


}