import {
    Component,
    inject,
    ChangeDetectorRef,
    DestroyRef
} from '@angular/core';

import { CommonModule } from '@angular/common';

import { ToastService } from '../../../core/services/toast.service';

import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

@Component({
    selector: 'app-error-toast',
    standalone: true,
    imports: [
        CommonModule
    ],
    templateUrl: './error-toast.html',
    styleUrl: './error-toast.scss'
})
export class ErrorToast {

    private toastService =
        inject(ToastService);

    private cdr =
        inject(ChangeDetectorRef);

    private destroyRef =
        inject(DestroyRef);

    message = '';

    visible = false;

    private timeoutId: ReturnType<typeof setTimeout> | null = null;

    constructor() {

        this.toastService.error$

            .pipe(
                takeUntilDestroyed(
                    this.destroyRef
                )
            )

            .subscribe(message => {

                this.message = message;

                this.visible = true;

                this.cdr.detectChanges();

                if (this.timeoutId) {

                    clearTimeout(
                        this.timeoutId
                    );

                }

                this.timeoutId = setTimeout(() => {

                    this.visible = false;

                    this.cdr.detectChanges();

                }, 3000);

            });

    }

}