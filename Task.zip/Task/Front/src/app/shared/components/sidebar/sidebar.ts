import { Component, inject } from '@angular/core';

import { Router, RouterLink, RouterLinkActive } from '@angular/router';

import { CommonModule } from '@angular/common';

import { AuthState } from '../../../core/services/auth-state';

@Component({

    selector: 'app-sidebar',

    standalone: true,

    imports: [
        CommonModule,
        RouterLink,
        RouterLinkActive
    ],

    templateUrl: './sidebar.html',

    styleUrl: './sidebar.scss'

})
export class Sidebar {

    private authState =
        inject(AuthState);

    private router =
        inject(Router);


}