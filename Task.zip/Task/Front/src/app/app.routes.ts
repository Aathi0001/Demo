import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';

export const routes: Routes = [

    {
      path: '',
      redirectTo: 'login',
      pathMatch: 'full'
    },

    {
        path: 'login',

        loadComponent: () =>
            import('./features/auth/pages/login/login')
            .then(m => m.Login)
    },


    {
        path: 'register',

        loadComponent: () =>
            import('./features/auth/pages/register/register')
            .then(m => m.Register)
    },


    {
        path: 'home',

        canActivate: [
            authGuard
        ],

        loadComponent: () =>
            import('./features/home/pages/home/home')
            .then(m => m.Home)

    },

    {
    path: 'profile',
    loadComponent: () =>
        import('./features/profile/pages/profile/profile')
            .then(c => c.Profile),
    canActivate: [authGuard]
},

{
    path: 'security',
    loadComponent: () =>
        import('./features/profile/pages/security/security')
            .then(c => c.Security),
    canActivate: [authGuard]
},
{
    path: 'profile/anime-status',
    loadComponent: () =>
        import('./features/profile/pages/anime-status/anime-status')
            .then(c => c.AnimeStatus),
    canActivate: [authGuard]
},

{
    path: 'profile/worklog-category',
    loadComponent: () =>
        import('./features/profile/pages/worklog-category/worklog-category')
            .then(c => c.WorklogCategory),
    canActivate: [authGuard]
},

{
    path: 'profile/worklog-project',
    loadComponent: () =>
        import('./features/profile/pages/worklog-project/worklog-project')
            .then(c => c.WorklogProject),
    canActivate: [authGuard]
},

{
    path: 'profile/payment-method',
    loadComponent: () =>
        import('./features/profile/pages/payment-method/payment-method')
            .then(c => c.PaymentMethod),
    canActivate: [authGuard]
},

{
    path: 'profile/export',
    loadComponent: () =>
        import('./features/profile/pages/export/export')
            .then(c => c.Export),
    canActivate: [authGuard]
},

{
    path: 'anime',

    canActivate: [
        authGuard
    ],

    loadComponent: () =>
        import('./features/anime/pages/anime/anime')
        .then(m => m.Anime)

},

{
    path:'notes',

    canActivate:[
        authGuard
    ],

    loadComponent:() =>
        import('./features/notes/pages/note/note')
        .then(m => m.Notes)

},

{
    path: 'expenses',

    canActivate: [
        authGuard
    ],

    loadComponent: () =>
        import('./features/expenses/pages/expense/expense')
        .then(m => m.Expense)
},

{
    path: 'worklogs',

    canActivate: [
        authGuard
    ],

    loadComponent: () =>
        import('./features/worklogs/pages/worklog/worklog')
        .then(m => m.WorkLog)
},

    {
      path: '**',
      redirectTo: 'login'
    }

];