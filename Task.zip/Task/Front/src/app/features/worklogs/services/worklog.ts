import {
    Injectable,
    inject
} from '@angular/core';

import {
    HttpClient
} from '@angular/common/http';

import {
    Observable
} from 'rxjs';

import {
    ApiEndpoints
} from '../../../core/constants/api-endpoints';

import {
    ApiResponse
} from '../../../core/models/api-response';

import {
    WorkLogModel
} from '../models/worklog';

import {
    WorkLogListRequest
} from '../models/worklog-list-request';

import {
    WorkLogListResponse
} from '../models/worklog-list-response';

import {
    CreateWorkLogRequest
} from '../models/create-worklog-request';

import {
    UpdateWorkLogRequest
} from '../models/update-worklog-request';

import {
    Timeline
} from '../components/timeline/timeline';

import {
    TimelineYearModel
} from '../models/timeline-year';

import {
    TimelineResponse
} from '../models/timeline-response';


import {
    TimelineYearsResponse
} from '../models/timeline-year-response';

@Injectable({

    providedIn: 'root'

})
export class WorkLogService {

    private http =
    inject(HttpClient);

    list(
        request: WorkLogListRequest
    ): Observable<ApiResponse<WorkLogListResponse>> {

        return this.http.post<ApiResponse<WorkLogListResponse>>(

            ApiEndpoints.WORKLOG_LIST,

            request

        );

    }

    detail(
        worklogId: number
    ): Observable<ApiResponse<WorkLogModel>> {

        return this.http.get<ApiResponse<WorkLogModel>>(

            `${ApiEndpoints.WORKLOG_DETAIL}/${worklogId}/`

        );

    }

    create(
        request: CreateWorkLogRequest
    ): Observable<ApiResponse<null>> {

        return this.http.post<ApiResponse<null>>(

            ApiEndpoints.WORKLOG_CREATE,

            request

        );

    }

    update(

        worklogId: number,

        request: UpdateWorkLogRequest

    ): Observable<ApiResponse<null>> {

        return this.http.put<ApiResponse<null>>(

            `${ApiEndpoints.WORKLOG_UPDATE}/${worklogId}/`,

            request

        );

    }

    scheduleDelete(
        worklogId: number
    ): Observable<ApiResponse<null>> {

        return this.http.patch<ApiResponse<null>>(

            `${ApiEndpoints.WORKLOG_SCHEDULE_DELETE}/${worklogId}/`,

            {}

        );

    }

    restore(
        worklogId: number
    ): Observable<ApiResponse<null>> {

        return this.http.patch<ApiResponse<null>>(

            `${ApiEndpoints.WORKLOG_RESTORE}/${worklogId}/`,

            {}

        );

    }

    permanentDelete(

        worklogId: number,

        request: {
            delete_password: string;
        }

    ): Observable<ApiResponse<null>> {

        return this.http.delete<ApiResponse<null>>(

            `${ApiEndpoints.WORKLOG_PERMANENT_DELETE}/${worklogId}/`,

            {
                body: request
            }

        );

    }


getTimelineYears():
Observable<ApiResponse<TimelineYearsResponse>> {

    return this.http.post<
        ApiResponse<TimelineYearsResponse>
    >(
        ApiEndpoints.WORKLOG_TIMELINE_YEARS,
        {}
    );

}


getTimeline(

    year: number

):

Observable<ApiResponse<TimelineResponse>> {

    return this.http.post<

        ApiResponse<

            TimelineResponse

        >

    >(

        ApiEndpoints.WORKLOG_TIMELINE,

        {

            year

        }

    );

}

}