import { TimelineYearModel } from "./timeline-year";

export interface TimelineYearsResponse {

    years: TimelineYearModel[];

}