import {

    WorkLogModel

} from './worklog';

export interface WorkLogGroupModel{

    work_date:string;

    day:string;

    worklogs:WorkLogModel[];

}