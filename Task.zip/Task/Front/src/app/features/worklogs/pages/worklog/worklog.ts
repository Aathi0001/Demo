import {
    Component,
    HostListener,
    OnInit,
    inject
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

import {
    ChangeDetectorRef
} from '@angular/core';

import {
    WorkLogToolbar
} from '../../components/worklog-toolbar/worklog-toolbar';

import {
    WorkLogList
} from '../../components/worklog-list/worklog-list';

import {
    WorkLogForm
} from '../../components/worklog-form/worklog-form';

import {
    DeletePassword
} from '../../../anime/components/delete-password/delete-password';

import {
    WorkLogService
} from '../../services/worklog';

import {
    ProfileService
} from '../../../profile/services/profile';

import {
    WorkLogModel
} from '../../models/worklog';

import {
    WorkLogListRequest
} from '../../models/worklog-list-request';

import {
    CreateWorkLogRequest
} from '../../models/create-worklog-request';

import {
    WorkLogGroupModel
} from '../../models/worklog-group';

import {
    WorklogProjectModel
} from '../../../profile/models/worklog-project';

import {
    WorklogCategoryModel
} from '../../../profile/models/worklog-category';

import {
    WorklogProjectService
} from '../../../profile/services/worklog-project';

import {
    WorklogCategoryService
} from '../../../profile/services/worklog-category';


import {
    Timeline
} from '../../components/timeline/timeline';



@Component({

    selector:'app-worklog',

    standalone:true,

    imports:[

        CommonModule,

        WorkLogToolbar,

        WorkLogList,

        WorkLogForm,

        DeletePassword,

        Timeline

    ],

    templateUrl:'./worklog.html',

    styleUrl:'./worklog.scss'

})
export class WorkLog
implements OnInit{

    private workLogService=
    inject(WorkLogService);

    private worklogProjectService =
inject(WorklogProjectService);

private worklogCategoryService =
inject(WorklogCategoryService);

    private cdr=
    inject(ChangeDetectorRef);

    groups:WorkLogGroupModel[]=[];

    projects:WorklogProjectModel[]=[];

    categories:WorklogCategoryModel[]=[];

    selectedWorkLog:WorkLogModel|null=null;

    openedWorkLog:WorkLogModel|null=null;

    showForm=false;

    showMenu=false;

    showDeleteDialog=false;

    isEditMode=false;

    isTrashMode = false;

        showTimeline=false;

    menuX=0;

    menuY=0;

    weekLabel='';

    request:WorkLogListRequest={

        search:'',

         project_id:null,

    category_id:null,

        delete_status:false,

        week_offset:0

    };

    ngOnInit():void{

        setTimeout(()=>{

            this.loadProjects();

            this.loadCategories();

            this.loadWorkLogs();

        });

    }

    loadProjects():void{

        this.worklogProjectService
    .getList()
        .subscribe({

            next:response=>{

                this.projects=
                response.data;

            }

        });

    }

    loadCategories():void{

        this.worklogCategoryService
    .getList()
        .subscribe({

            next:response=>{

                this.categories=
                response.data;

            }

        });

    }

    loadWorkLogs():void{

        this.workLogService
        .list(this.request)
        .subscribe({

            next:response=>{
                this.groups =
this.groupWorkLogs(
    response.data.results
);
console.log(this.groups);

                this.weekLabel =
`${response.data.week_start} - ${response.data.week_end}`;

                this.cdr.detectChanges();

            }

        });

    }

    create():void{

        this.selectedWorkLog=null;

        this.isEditMode=false;

        this.showForm=true;

    }

    closeForm():void{

        this.showForm=false;

        this.selectedWorkLog=null;

    }

    save(
        value:CreateWorkLogRequest
    ):void{

        if(this.isEditMode){

            this.updateWorkLog(value);

        }
        else{

            this.createWorkLog(value);

        }

    }

    createWorkLog(
        value:CreateWorkLogRequest
    ):void{

        this.workLogService
        .create(value)
        .subscribe({

            next:()=>{

                this.closeForm();

                this.loadWorkLogs();

            }

        });

    }

    updateWorkLog(
        value:CreateWorkLogRequest
    ):void{

        if(!this.selectedWorkLog){

            return;

        }

        this.workLogService
        .update(

            this.selectedWorkLog.worklog_id,

            value

        )
        .subscribe({

            next:()=>{

                this.closeForm();

                this.loadWorkLogs();

            }

        });

    }

    search(
        value:string
    ):void{

        this.request.search=value;

        this.loadWorkLogs();

    }

    projectChanged(
        projectId:number|null
    ):void{

        this.request.project_id=projectId;

        this.loadWorkLogs();

    }

    categoryChanged(
        categoryId:number|null
    ):void{

        this.request.category_id=categoryId;

        this.loadWorkLogs();

    }



openTimeline(): void {

    this.showTimeline = true;

}

closeTimeline(): void {

    this.showTimeline = false;

}

weekSelected(
    weekOffset: number
): void {

    this.request.week_offset =
        weekOffset;

    this.showTimeline = false;

    this.loadWorkLogs();

}

    private groupWorkLogs(
    worklogs:WorkLogModel[]
):WorkLogGroupModel[]{

    const grouped=new Map<string,WorkLogGroupModel>();

    worklogs.forEach(worklog=>{

        if(!grouped.has(worklog.work_date)){

            grouped.set(

                worklog.work_date,

                {

                    work_date:worklog.work_date,

                    day:new Date(worklog.work_date)
                        .toLocaleDateString(

                            'en-US',

                            {

                                weekday:'long'

                            }

                        ),

                    worklogs:[]

                }

            );

        }

        grouped.get(worklog.work_date)!
            .worklogs
            .push(worklog);

    });

    return Array.from(grouped.values());

}

    previousWeek():void{

        this.request.week_offset--;

        this.loadWorkLogs();

    }

    nextWeek():void{

        this.request.week_offset++;

        this.loadWorkLogs();

    }


        openWorkLog(
        workLog: WorkLogModel
    ): void {

        this.openedWorkLog = {

            ...workLog

        };

    }

    closeWorkLog(): void {

        this.openedWorkLog = null;

    }

    editWorkLog(): void {

    if (!this.selectedWorkLog) {

        return;

    }

    this.isEditMode = true;

    this.showForm = true;

    this.closeMenu();

}

    openMenu(
        data: any
    ): void {

        data.event.preventDefault();

        this.selectedWorkLog =
            data.workLog;

        this.menuX =
            data.event.clientX;

        this.menuY =
            data.event.clientY;

        this.showMenu = true;

    }

    closeMenu(): void {

        this.showMenu = false;

    }

    deleteWorkLog(): void {

        if (!this.selectedWorkLog) {

            return;

        }

        this.workLogService
            .scheduleDelete(
                this.selectedWorkLog.worklog_id
            )
            .subscribe({

                next: () => {

                    this.closeMenu();

                    this.openedWorkLog = null;

                    this.loadWorkLogs();

                }

            });

    }

    restoreWorkLog(): void {

        if (!this.selectedWorkLog) {

            return;

        }

        this.workLogService
            .restore(
                this.selectedWorkLog.worklog_id
            )
            .subscribe({

                next: () => {

                    this.closeMenu();

                    this.loadWorkLogs();

                }

            });

    }

    
toggleTrash(): void {

    this.isTrashMode =
        !this.isTrashMode;

    this.request.delete_status =
        this.isTrashMode;

    this.loadWorkLogs();

}

    openDeleteDialog(): void {

        console.log('openDeleteDialog')

        this.showDeleteDialog = true;

        this.closeMenu();

    }

    closeDeleteDialog(): void {

        this.showDeleteDialog = false;

    }

    permanentDelete(
        password: string
    ): void {

        if (!this.selectedWorkLog) {

            return;

        }

        this.workLogService
            .permanentDelete(

                this.selectedWorkLog.worklog_id,

                {

                    delete_password: password

                }

            )
            .subscribe({

                next: () => {

                    this.closeDeleteDialog();

                    this.closeMenu();

                    this.openedWorkLog = null;

                    this.loadWorkLogs();

                }

            });

    }

    @HostListener(
        'document:click',
        ['$event']
    )
    closeContextMenu(
        event: MouseEvent
    ): void {

        const target =
            event.target as HTMLElement;

        if (

            target.closest('.worklog-menu') ||

            target.closest('.menu-btn')

        ) {

            return;

        }

        this.showMenu = false;

    }

}
