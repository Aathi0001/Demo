import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Sidebar } from '../../../../shared/components/sidebar/sidebar';
import {
    CurrentUserService
} from '../../../../core/services/current-user';

import { Header } from '../../../../shared/components/header/header';

import {
    RouterLink
} from '@angular/router';

@Component({
    selector: 'app-home',
    standalone: true,
    imports: [
        CommonModule,
        Sidebar,
        Header,
        RouterLink
    ],
    templateUrl: './home.html',
    styleUrl: './home.scss'
})
export class Home {

    private currentUser =
    inject(CurrentUserService);

    displayName =
        this.currentUser.getUser()?.display_name
        ?? 'User';
}