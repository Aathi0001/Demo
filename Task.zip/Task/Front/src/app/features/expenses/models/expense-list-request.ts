export interface ExpenseListRequest {

    search: string;

    payment_method_id: number | null;

    month_offset: number;

    delete_status: boolean;

}
