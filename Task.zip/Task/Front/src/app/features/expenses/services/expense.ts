import {
    Injectable,
    inject
} from '@angular/core';

import {
    HttpClient
} from '@angular/common/http';

import {
    Observable
} from 'rxjs';

import {
    ApiEndpoints
} from '../../../core/constants/api-endpoints';

import {
    ApiResponse
} from '../../../core/models/api-response';

import {
    ExpenseModel
} from '../models/expense';

import {
    ExpenseListRequest
} from '../models/expense-list-request';

import {
    ExpenseListResponse
} from '../models/expense-list-response';

import {
    CreateExpenseRequest
} from '../models/create-expense-request';

import {
    UpdateExpenseRequest
} from '../models/update-expense-request';


import {
    ExpenseTimelineYearModel
} from '../models/expense-timeline-year';

import {
    ExpenseTimelineMonthModel
} from '../models/expense-timeline-month';


@Injectable({

    providedIn: 'root'

})
export class ExpenseService {

    private http =
    inject(HttpClient);

    list(
        request: ExpenseListRequest
    ): Observable<ApiResponse<ExpenseListResponse>> {

        return this.http.post<ApiResponse<ExpenseListResponse>>(

            ApiEndpoints.EXPENSE_LIST,

            request

        );

    }

    detail(
        expenseId: number
    ): Observable<ApiResponse<ExpenseModel>> {

        return this.http.get<ApiResponse<ExpenseModel>>(

            `${ApiEndpoints.EXPENSE_DETAIL}/${expenseId}/`

        );

    }

    create(
        request: CreateExpenseRequest
    ): Observable<ApiResponse<null>> {

        return this.http.post<ApiResponse<null>>(

            ApiEndpoints.EXPENSE_CREATE,

            request

        );

    }

    update(

        expenseId: number,

        request: UpdateExpenseRequest

    ): Observable<ApiResponse<null>> {

        return this.http.put<ApiResponse<null>>(

            `${ApiEndpoints.EXPENSE_UPDATE}/${expenseId}/`,

            request

        );

    }

    scheduleDelete(
        expenseId: number
    ): Observable<ApiResponse<null>> {

        return this.http.patch<ApiResponse<null>>(

            `${ApiEndpoints.EXPENSE_DELETE}/${expenseId}/`,

            {}

        );

    }

    restore(
        expenseId: number
    ): Observable<ApiResponse<null>> {

        return this.http.patch<ApiResponse<null>>(

            `${ApiEndpoints.EXPENSE_RESTORE}/${expenseId}/`,

            {}

        );

    }

    permanentDelete(

        expenseId: number,

        request: {
            delete_password: string;
        }

    ): Observable<ApiResponse<null>> {

        return this.http.delete<ApiResponse<null>>(

            `${ApiEndpoints.EXPENSE_PERMANENT_DELETE}/${expenseId}/`,

            {
                body: request
            }

        );

    }

    
timelineYears():
Observable<ApiResponse<ExpenseTimelineYearModel[]>>{

    return this.http.post<
        ApiResponse<
            ExpenseTimelineYearModel[]
        >
    >(
        ApiEndpoints.EXPENSE_TIMELINE_YEARS,
        {}
    );

}

timelineMonths(
    year:number
):
Observable<ApiResponse<ExpenseTimelineMonthModel[]>>{

    return this.http.post<
        ApiResponse<
            ExpenseTimelineMonthModel[]
        >
    >(
        ApiEndpoints.EXPENSE_TIMELINE_MONTH,
        {

            year

        }
    );

}

}