import {
    Component,
    EventEmitter,
    Input,
    OnChanges,
    Output,
    SimpleChanges,
    inject
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

import {
    FormBuilder,
    ReactiveFormsModule,
    Validators
} from '@angular/forms';

import {
    ExpenseModel
} from '../../models/expense';

import {
    CreateExpenseRequest
} from '../../models/create-expense-request';

import {
    PaymentMethodModel
} from '../../../profile/models/payment-method';

@Component({

    selector:'app-expense-form',

    standalone:true,

    imports:[
        CommonModule,
        ReactiveFormsModule
    ],

    templateUrl:'./expense-form.html',

    styleUrl:'./expense-form.scss'

})
export class ExpenseForm
implements OnChanges{

    @Input()

    expense:
    ExpenseModel | null = null;

    @Input()

    paymentMethods:
    PaymentMethodModel[]=[];

    @Output()

    save=
    new EventEmitter<CreateExpenseRequest>();

    @Output()

    close=
    new EventEmitter<void>();

    private fb=
    inject(FormBuilder);

    form = this.fb.group({

    payment_method_id:
    this.fb.control<number | null>(null),

    amount:
    this.fb.nonNullable.control(
        0,
        Validators.min(0.01)
    ),

    amount_type:
    this.fb.nonNullable.control<'credit' | 'debit'>(
        'debit'
    ),

    expense_date:
    this.fb.nonNullable.control(
        new Date().toISOString().substring(0, 10),
        Validators.required
    ),

    notes:
    this.fb.nonNullable.control(
        '',
        Validators.required
    )

});

    ngOnChanges(
        changes:SimpleChanges
    ):void{

        if(!this.expense){

            this.form.reset({

    payment_method_id:null,

    amount:0,

    amount_type:'debit',

    expense_date:new Date().toISOString().substring(0,10),

    notes:''

});

            return;

        }

        this.form.patchValue({

            payment_method_id:
            this.expense.payment_method_id,

            amount:
            this.expense.amount,

            amount_type:
this.expense.amount_type as 'credit' | 'debit',

            expense_date:
            this.expense.expense_date,

            notes:
            this.expense.notes

        });

    }

   submit():void{

    if(this.form.invalid){

        this.form.markAllAsTouched();

        return;

    }

    const value =
    this.form.getRawValue();

    const request:CreateExpenseRequest={

        payment_method_id:
        value.payment_method_id,

        amount:
        value.amount,

        amount_type:
        value.amount_type,

        expense_date:
        value.expense_date,

        notes:
        value.notes.trim()

    };

    this.save.emit(
        request
    );

}

    cancel():void{

        this.close.emit();

    }

}
