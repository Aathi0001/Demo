import { Injectable, inject } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { ApiEndpoints } from '../../../core/constants/api-endpoints';

import { ApiResponse } from '../../../core/models/api-response';

import { Profile } from '../models/profile';

import { UpdateProfileRequest } from '../models/update-profile-request';

@Injectable({
    providedIn: 'root'
})
export class ProfileService {

    private http = inject(HttpClient);


    getProfile(): Observable<ApiResponse<Profile>> {

        return this.http.get<ApiResponse<Profile>>(
            ApiEndpoints.PROFILE
        );

    }


    updateProfile(
        request: UpdateProfileRequest
    ): Observable<ApiResponse<Profile>> {

        return this.http.put<ApiResponse<Profile>>(
            ApiEndpoints.PROFILE,
            request
        );

    }

}