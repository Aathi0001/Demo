import { Injectable, inject } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { ApiEndpoints } from '../../../core/constants/api-endpoints';

import { ApiResponse } from '../../../core/models/api-response';

import { WorklogCategoryModel } from '../models/worklog-category';

import { CreateWorklogCategoryRequest } from '../models/create-worklog-category-request';

import { UpdateWorklogCategoryRequest } from '../models/update-worklog-category-request';



@Injectable({
    providedIn: 'root'
})
export class WorklogCategoryService {


    private http = inject(HttpClient);



    getList(): Observable<ApiResponse<WorklogCategoryModel[]>> {


        return this.http.get<ApiResponse<WorklogCategoryModel[]>>(
            ApiEndpoints.WORKLOG_CATEGORY_LIST
        );


    }



    create(
        request: CreateWorklogCategoryRequest
    ): Observable<ApiResponse<WorklogCategoryModel>> {


        return this.http.post<ApiResponse<WorklogCategoryModel>>(
            ApiEndpoints.WORKLOG_CATEGORY_CREATE,
            request
        );


    }




    update(
        categoryId: number,
        request: UpdateWorklogCategoryRequest
    ): Observable<ApiResponse<WorklogCategoryModel>> {


        return this.http.put<ApiResponse<WorklogCategoryModel>>(
            `${ApiEndpoints.WORKLOG_CATEGORY_UPDATE}/${categoryId}/`,
            request
        );


    }





    changeState(
        categoryId: number
    ): Observable<ApiResponse<any>> {


        return this.http.patch<ApiResponse<any>>(
            `${ApiEndpoints.WORKLOG_CATEGORY_CHANGE_STATE}/${categoryId}/`,
            {}
        );


    }


}