import { TestBed } from '@angular/core/testing';

import { AnimeStatus } from './anime-status';

describe('AnimeStatus', () => {
  let service: AnimeStatus;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AnimeStatus);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
