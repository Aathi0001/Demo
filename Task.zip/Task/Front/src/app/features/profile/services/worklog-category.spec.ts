import { TestBed } from '@angular/core/testing';

import { WorklogCategory } from './worklog-category';

describe('WorklogCategory', () => {
  let service: WorklogCategory;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WorklogCategory);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
