import { Injectable, inject } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { ApiEndpoints } from '../../../core/constants/api-endpoints';

import { ApiResponse } from '../../../core/models/api-response';

import { WorklogProjectModel } from '../models/worklog-project';

import { CreateWorklogProjectRequest } from '../models/create-worklog-project-request';

import { UpdateWorklogProjectRequest } from '../models/update-worklog-project-request';



@Injectable({
    providedIn: 'root'
})
export class WorklogProjectService {


    private http = inject(HttpClient);



    getList(): Observable<ApiResponse<WorklogProjectModel[]>> {


        return this.http.get<ApiResponse<WorklogProjectModel[]>>(
            ApiEndpoints.WORKLOG_PROJECT_LIST
        );


    }




    create(
        request: CreateWorklogProjectRequest
    ): Observable<ApiResponse<WorklogProjectModel>> {


        return this.http.post<ApiResponse<WorklogProjectModel>>(
            ApiEndpoints.WORKLOG_PROJECT_CREATE,
            request
        );


    }





    update(
        projectId: number,
        request: UpdateWorklogProjectRequest
    ): Observable<ApiResponse<WorklogProjectModel>> {


        return this.http.put<ApiResponse<WorklogProjectModel>>(
            `${ApiEndpoints.WORKLOG_PROJECT_UPDATE}/${projectId}/`,
            request
        );


    }





    changeState(
        projectId: number
    ): Observable<ApiResponse<any>> {


        return this.http.patch<ApiResponse<any>>(
            `${ApiEndpoints.WORKLOG_PROJECT_CHANGE_STATE}/${projectId}/`,
            {}
        );


    }


}