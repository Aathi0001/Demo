import { TestBed } from '@angular/core/testing';

import { WorklogProject } from './worklog-project';

describe('WorklogProject', () => {
  let service: WorklogProject;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WorklogProject);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
