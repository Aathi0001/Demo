import { Injectable, inject } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { ApiEndpoints } from '../../../core/constants/api-endpoints';

import { ApiResponse } from '../../../core/models/api-response';

import { AnimeStatusModel } from '../models/anime-status';

import { CreateAnimeStatusRequest } from '../models/create-anime-status-request';

import { UpdateAnimeStatusRequest } from '../models/update-anime-status-request';

@Injectable({
    providedIn: 'root'
})
export class AnimeStatusService {

    private http = inject(HttpClient);

    getList(): Observable<ApiResponse<AnimeStatusModel[]>> {

        return this.http.get<ApiResponse<AnimeStatusModel[]>>(
            ApiEndpoints.ANIME_STATUS_LIST
        );

    }

    create(
        request: CreateAnimeStatusRequest
    ): Observable<ApiResponse<AnimeStatusModel>> {

        return this.http.post<ApiResponse<AnimeStatusModel>>(
            ApiEndpoints.ANIME_STATUS_CREATE,
            request
        );

    }

    update(
        statusId: number,
        request: UpdateAnimeStatusRequest
    ): Observable<ApiResponse<AnimeStatusModel>> {

        return this.http.put<ApiResponse<AnimeStatusModel>>(
            `${ApiEndpoints.ANIME_STATUS_UPDATE}/${statusId}/`,
            request
        );

    }

    changeState(
        statusId: number
    ): Observable<ApiResponse<any>> {

        return this.http.patch<ApiResponse<any>>(
            `${ApiEndpoints.ANIME_STATUS_CHANGE_STATE}/${statusId}/`,
            {}
        );

    }

}