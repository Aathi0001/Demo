import { Injectable, inject } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { ApiEndpoints } from '../../../core/constants/api-endpoints';

import { ApiResponse } from '../../../core/models/api-response';

import { PaymentMethodModel } from '../models/payment-method';

import { CreatePaymentMethodRequest } from '../models/create-payment-method-request';

import { UpdatePaymentMethodRequest } from '../models/update-payment-method-request';



@Injectable({
    providedIn: 'root'
})
export class PaymentMethodService {


    private http = inject(HttpClient);



    getList(): Observable<ApiResponse<PaymentMethodModel[]>> {


        return this.http.get<ApiResponse<PaymentMethodModel[]>>(
            ApiEndpoints.PAYMENT_METHOD_LIST
        );


    }




    create(
        request: CreatePaymentMethodRequest
    ): Observable<ApiResponse<PaymentMethodModel>> {


        return this.http.post<ApiResponse<PaymentMethodModel>>(
            ApiEndpoints.PAYMENT_METHOD_CREATE,
            request
        );


    }





    update(
        paymentMethodId: number,
        request: UpdatePaymentMethodRequest
    ): Observable<ApiResponse<PaymentMethodModel>> {


        return this.http.put<ApiResponse<PaymentMethodModel>>(
            `${ApiEndpoints.PAYMENT_METHOD_UPDATE}/${paymentMethodId}/`,
            request
        );


    }





    changeState(
        paymentMethodId: number
    ): Observable<ApiResponse<any>> {


        return this.http.patch<ApiResponse<any>>(
            `${ApiEndpoints.PAYMENT_METHOD_CHANGE_STATE}/${paymentMethodId}/`,
            {}
        );


    }


}