import { Injectable, inject } from "@angular/core";

import { HttpClient } from "@angular/common/http";

import { Observable } from "rxjs";

import { ApiEndpoints } from "../../../core/constants/api-endpoints";

import { ApiResponse } from "../../../core/models/api-response";

import { NotificationResponse } from "../models/notification-response";

@Injectable({
    providedIn: "root"
})
export class NotificationService {

    private http = inject(HttpClient);

    getNotifications():
    Observable<ApiResponse<NotificationResponse>> {

        return this.http.get<ApiResponse<NotificationResponse>>(
            ApiEndpoints.NOTIFICATIONS
        );

    }

}