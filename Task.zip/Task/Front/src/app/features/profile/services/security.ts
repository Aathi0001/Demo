import { Injectable, inject } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { ApiEndpoints } from '../../../core/constants/api-endpoints';

import { ApiResponse } from '../../../core/models/api-response';

import { Security } from '../models/security';

import { UpdateSecurityRequest } from '../models/update-security-request';

import { SecurityPasswordRequest } from '../models/security-password-request';

import { SecurityChangePasswordRequest } from '../models/security-change-password-request';


@Injectable({
    providedIn: 'root'
})
export class SecurityService {

    private http = inject(HttpClient);

    getSecurity(): Observable<ApiResponse<Security>> {

        return this.http.get<ApiResponse<Security>>(
            ApiEndpoints.SECURITY
        );

    }

    updateSecurity(
        request: UpdateSecurityRequest
    ): Observable<ApiResponse<Security>> {

        return this.http.put<ApiResponse<Security>>(
            ApiEndpoints.SECURITY,
            request
        );

}
setLockPassword(
    request: SecurityPasswordRequest
): Observable<ApiResponse<null>> {

    return this.http.post<ApiResponse<null>>(

        ApiEndpoints.SET_LOCK_PASSWORD,

        request

    );

}


verifyLockPassword(
    request: SecurityPasswordRequest
): Observable<ApiResponse<null>> {

    return this.http.post<ApiResponse<null>>(

        ApiEndpoints.VERIFY_LOCK_PASSWORD,

        request

    );

}


changeLockPassword(
    request: SecurityChangePasswordRequest
): Observable<ApiResponse<null>> {

    return this.http.post<ApiResponse<null>>(

        ApiEndpoints.CHANGE_LOCK_PASSWORD,

        request

    );

}


setDeletePassword(
    request: SecurityPasswordRequest
): Observable<ApiResponse<null>> {

    return this.http.post<ApiResponse<null>>(

        ApiEndpoints.SET_DELETE_PASSWORD,

        request

    );

}


verifyDeletePassword(
    request: SecurityPasswordRequest
): Observable<ApiResponse<null>> {

    return this.http.post<ApiResponse<null>>(

        ApiEndpoints.VERIFY_DELETE_PASSWORD,

        request

    );

}


changeDeletePassword(
    request: SecurityChangePasswordRequest
): Observable<ApiResponse<null>> {

    return this.http.post<ApiResponse<null>>(

        ApiEndpoints.CHANGE_DELETE_PASSWORD,

        request

    );

}


changeLoginPassword(
    request: SecurityChangePasswordRequest
): Observable<ApiResponse<null>> {

    return this.http.post<ApiResponse<null>>(

        ApiEndpoints.CHANGE_PASSWORD,

        request

    );

}

forgotLockPassword(): Observable<ApiResponse<any>> {

    return this.http.post<ApiResponse<any>>(

        ApiEndpoints.FORGOT_LOCK_PASSWORD,

        {}

    );

}

forgotDeletePassword(): Observable<ApiResponse<any>> {

    return this.http.post<ApiResponse<any>>(

        ApiEndpoints.FORGOT_DELETE_PASSWORD,

        {}

    );

}

}

