export interface CreateWorklogProjectRequest {

    name: string;

}