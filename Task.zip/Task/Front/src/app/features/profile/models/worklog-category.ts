export interface WorklogCategoryModel {

    id: number;

    name: string;

    is_active: boolean;

}