export interface UpdateProfileRequest {

    display_name: string;

    theme: string;

    timezone: string;

}