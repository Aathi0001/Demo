export interface UpdateAnimeStatusRequest {

    name: string;

}