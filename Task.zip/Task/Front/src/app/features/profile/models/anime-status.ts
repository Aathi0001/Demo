export interface AnimeStatusModel {

    id: number;

    name: string;

    is_active: boolean;

}