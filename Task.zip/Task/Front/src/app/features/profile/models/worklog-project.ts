export interface WorklogProjectModel {

    id: number;

    name: string;

    is_active: boolean;

}