export interface CreateWorklogCategoryRequest {

    name: string;

}