export interface UpdateWorklogProjectRequest {

    name: string;

}