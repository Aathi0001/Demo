export interface Security {

    has_lock_password: boolean;

    has_delete_password: boolean;

    lock_password_reset_scheduled: boolean;

    delete_password_reset_scheduled: boolean;

    anime_delete_after_hours: number;

    worklog_delete_after_hours: number;

    notes_delete_after_hours: number;

    expense_delete_after_hours: number;

}