export interface UpdateWorklogCategoryRequest {

    name: string;

}