export interface SecurityPasswordRequest {

    password: string;

}

