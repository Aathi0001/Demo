export interface CreatePaymentMethodRequest {

    name: string;

}