export interface CreateAnimeStatusRequest {

    name: string;

}