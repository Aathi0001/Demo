export interface Profile {

    username: string;

    email: string;

    display_name: string;

    theme: string;

    timezone: string;

}