export interface Notification {

    type: string;

    title: string;

    reset_at: string;

}