export interface UpdatePaymentMethodRequest {

    name: string;

}