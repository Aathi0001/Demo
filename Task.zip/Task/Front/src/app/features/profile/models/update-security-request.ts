export interface UpdateSecurityRequest {

    anime_delete_after_hours: number;

    worklog_delete_after_hours: number;

    notes_delete_after_hours: number;

    expense_delete_after_hours: number;

}