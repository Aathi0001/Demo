import { Notification } from "./notification";

export interface NotificationResponse {

    count: number;

    notifications: Notification[];

}