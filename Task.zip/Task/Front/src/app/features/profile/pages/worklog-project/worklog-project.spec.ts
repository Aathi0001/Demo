import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorklogProject } from './worklog-project';

describe('WorklogProject', () => {
  let component: WorklogProject;
  let fixture: ComponentFixture<WorklogProject>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WorklogProject],
    }).compileComponents();

    fixture = TestBed.createComponent(WorklogProject);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
