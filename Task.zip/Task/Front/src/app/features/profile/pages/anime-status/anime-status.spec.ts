import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnimeStatus } from './anime-status';

describe('AnimeStatus', () => {
  let component: AnimeStatus;
  let fixture: ComponentFixture<AnimeStatus>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AnimeStatus],
    }).compileComponents();

    fixture = TestBed.createComponent(AnimeStatus);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
