import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorklogCategory } from './worklog-category';

describe('WorklogCategory', () => {
  let component: WorklogCategory;
  let fixture: ComponentFixture<WorklogCategory>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WorklogCategory],
    }).compileComponents();

    fixture = TestBed.createComponent(WorklogCategory);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
