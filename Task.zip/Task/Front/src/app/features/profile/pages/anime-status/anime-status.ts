import { Component, inject } from '@angular/core';

import { CommonModule } from '@angular/common';

import { ChangeDetectorRef } from '@angular/core';

import {
    FormBuilder,
    ReactiveFormsModule,
    Validators
} from '@angular/forms';

import { AnimeStatusService } from '../../services/anime-status';

import { AnimeStatusModel } from '../../models/anime-status';

import { CreateAnimeStatusRequest } from '../../models/create-anime-status-request';

import { UpdateAnimeStatusRequest } from '../../models/update-anime-status-request';

@Component({
    selector: 'app-anime-status',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule
    ],
    templateUrl: './anime-status.html',
    styleUrl: './anime-status.scss'
})
export class AnimeStatus {

    private fb = inject(FormBuilder);

    private animeStatusService =
        inject(AnimeStatusService);

private cdr = inject(ChangeDetectorRef);


    animeStatuses: AnimeStatusModel[] = [];

    selectedStatusId: number | null = null;

    isEditMode = false;

    showModal = false;

    statusForm = this.fb.group({

        name: [
            '',
            [
                Validators.required,
                Validators.maxLength(100)
            ]
        ]

    });

    ngOnInit(): void {

        this.loadAnimeStatuses();

    }

    loadAnimeStatuses(): void {

        this.animeStatusService
            .getList()
            .subscribe({

                next: (response) => {

                    this.animeStatuses =
                        response.data;

                    this.cdr.detectChanges();

                }

            });

    }

    openCreateModal(): void {

        this.isEditMode = false;

        this.selectedStatusId = null;

        this.statusForm.reset();

        this.showModal = true;

    }

    openEditModal(
        status: AnimeStatusModel
    ): void {

        this.isEditMode = true;

        this.selectedStatusId = status.id;

        this.statusForm.patchValue({

            name: status.name

        });

        this.showModal = true;

    }

    closeModal(): void {

        this.showModal = false;

        this.statusForm.reset();

        this.selectedStatusId = null;

    }

    save(): void {

        this.statusForm.markAllAsTouched();

        if (this.statusForm.invalid) {

            return;

        }

        if (this.isEditMode) {

            this.update();

        }

        else {

            this.create();

        }

    }

    create(): void {

        const request: CreateAnimeStatusRequest = {

            name: this.statusForm.value.name!

        };

        this.animeStatusService
            .create(request)
            .subscribe({

                next: () => {

                    this.closeModal();

                    this.loadAnimeStatuses();

                    alert(
                        "Anime Status created successfully."
                    );

                }

            });

    }

    update(): void {

        const request: UpdateAnimeStatusRequest = {

            name: this.statusForm.value.name!

        };

        this.animeStatusService
            .update(
                this.selectedStatusId!,
                request
            )
            .subscribe({

                next: () => {

                    this.closeModal();

                    this.loadAnimeStatuses();

                    alert(
                        "Anime Status updated successfully."
                    );

                }

            });

    }

    changeState(
        status: AnimeStatusModel
    ): void {

        this.animeStatusService
            .changeState(status.id)
            .subscribe({

                next: () => {

                    this.loadAnimeStatuses();

                }

            });

    }

}