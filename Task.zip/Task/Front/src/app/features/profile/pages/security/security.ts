import { Component, inject } from '@angular/core';

import { CommonModule } from '@angular/common';

import { ChangeDetectorRef} from '@angular/core';

import {
    FormBuilder,
    ReactiveFormsModule,
    Validators
} from '@angular/forms';

import { SecurityService } from '../../services/security';

import { UpdateSecurityRequest } from '../../models/update-security-request';

import { SecurityChangePasswordRequest } from '../../models/security-change-password-request';


@Component({
    selector: 'app-security',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule
    ],
    templateUrl: './security.html',
    styleUrl: './security.scss'
})
export class Security {

    private fb = inject(FormBuilder);

    private cdr = inject(ChangeDetectorRef);

    private securityService = inject(SecurityService);

    hasLockPassword = false;

    hasDeletePassword = false;

    lockPasswordResetScheduled = false;

    deletePasswordResetScheduled = false;

    showChangePassword = false;

    securityForm = this.fb.group({

        anime_delete_after_hours: [
            48,
            [
                Validators.required,
                Validators.min(1)
            ]
        ],

        worklog_delete_after_hours: [
            48,
            [
                Validators.required,
                Validators.min(1)
            ]
        ],

        notes_delete_after_hours: [
            48,
            [
                Validators.required,
                Validators.min(1)
            ]
        ],

        expense_delete_after_hours: [
            48,
            [
                Validators.required,
                Validators.min(1)
            ]
        ]

    });


    lockPasswordForm = this.fb.group({

    old_password: [''],

    new_password: [
        '',
        [
            Validators.required
        ]
    ],

    confirm_password: [
        '',
        [
            Validators.required
        ]
    ]

});


deletePasswordForm = this.fb.group({

    old_password: [''],

    new_password: [
        '',
        [
            Validators.required
        ]
    ],

    confirm_password: [
        '',
        [
            Validators.required
        ]
    ]

});

changePasswordForm = this.fb.group({

    old_password: [
        '',
        Validators.required
    ],

    new_password: [
        '',
        [
            Validators.required,
            Validators.minLength(4)
        ]
    ],

    confirm_password: [
        '',
        Validators.required
    ]

});


    ngOnInit(): void {

        this.loadSecurity();

    }

    loadSecurity(): void {

        this.securityService.getSecurity().subscribe({

            next: (response) => {

                this.hasLockPassword =
                    response.data.has_lock_password;

                this.hasDeletePassword =
                    response.data.has_delete_password;

                this.lockPasswordResetScheduled =
                    response.data.lock_password_reset_scheduled;

                this.deletePasswordResetScheduled =
                    response.data.delete_password_reset_scheduled;

                this.cdr.detectChanges();

                this.securityForm.patchValue({

                    anime_delete_after_hours:
                        response.data.anime_delete_after_hours,

                    worklog_delete_after_hours:
                        response.data.worklog_delete_after_hours,

                    notes_delete_after_hours:
                        response.data.notes_delete_after_hours,

                    expense_delete_after_hours:
                        response.data.expense_delete_after_hours

                });

            }

        });

    }

    save(): void {

        this.securityForm.markAllAsTouched();

        if (this.securityForm.invalid) {
            return;
        }

        const request: UpdateSecurityRequest = {

            anime_delete_after_hours:
                this.securityForm.value.anime_delete_after_hours!,

            worklog_delete_after_hours:
                this.securityForm.value.worklog_delete_after_hours!,

            notes_delete_after_hours:
                this.securityForm.value.notes_delete_after_hours!,

            expense_delete_after_hours:
                this.securityForm.value.expense_delete_after_hours!

        };

        this.securityService.updateSecurity(request).subscribe({

            next: () => {
                this.loadSecurity();

                alert(
                    "Security settings updated successfully."
                );

            }

        });

    }

changeLoginPassword(): void {

    this.changePasswordForm.markAllAsTouched();

    if (this.changePasswordForm.invalid) {
        return;
    }

    const request: SecurityChangePasswordRequest = {

        old_password: this.changePasswordForm.value.old_password!,

        new_password: this.changePasswordForm.value.new_password!,

        confirm_password: this.changePasswordForm.value.confirm_password!

    };

    this.securityService
        .changeLoginPassword(request)
        .subscribe({

            next: () => {
                this.loadSecurity();

                alert("Password changed successfully.");

                this.changePasswordForm.reset();

            }

        });

}


openChangePassword(): void {

    this.showChangePassword = true;

}

cancelChangePassword(): void {

    this.showChangePassword = false;

    this.changePasswordForm.reset();

}

    setLockPassword(): void {

    const password = prompt(
        "Enter Lock Password"
    );

    if(!password){

        return;

    }

    this.securityService
        .setLockPassword({
            password
        })
        .subscribe({

            next:()=>{

                this.hasLockPassword = true;
                this.loadSecurity();

                alert(
                    "Lock password set successfully."
                );

            }

        });

}

changeLockPassword(): void {

    const oldPassword = prompt(
        "Current Lock Password"
    );

    if(!oldPassword){
        return;
    }

    const newPassword = prompt(
        "New Lock Password"
    );

    if(!newPassword){
        return;
    }

    const confirmPassword = prompt(
        "Confirm Lock Password"
    );

    if(confirmPassword !== newPassword){

        alert(
            "Passwords do not match."
        );

        return;

    }

    this.securityService
        .changeLockPassword({

            old_password: oldPassword,

            new_password: newPassword,

            confirm_password: confirmPassword

        })
        .subscribe({

            next:()=>{
                this.loadSecurity();

                alert(
                    "Lock password changed successfully."
                );

            }

        });

}

setDeletePassword(): void {

    const password = prompt(
        "Enter Delete Password"
    );

    if(!password){

        return;

    }

    this.securityService
        .setDeletePassword({
            password
        })
        .subscribe({

            next:()=>{

                this.hasDeletePassword = true;
                this.loadSecurity();

                alert(
                    "Delete password set successfully."
                );

            }

        });

}

changeDeletePassword(): void {

    const oldPassword = prompt(
        "Current Delete Password"
    );

    if(!oldPassword){
        return;
    }

    const newPassword = prompt(
        "New Delete Password"
    );

    if(!newPassword){
        return;
    }

    const confirmPassword = prompt(
        "Confirm Delete Password"
    );

    if(confirmPassword !== newPassword){

        alert(
            "Passwords do not match."
        );

        return;

    }

    this.securityService
        .changeDeletePassword({

            old_password: oldPassword,

            new_password: newPassword,

            confirm_password: confirmPassword

        })
        .subscribe({

            next:()=>{
                this.loadSecurity();

                alert(
                    "Delete password changed successfully."
                );

            }

        });

}

forgotLockPassword(): void {

    if (
        !confirm(
            "Your lock password will be removed after the waiting period. Continue?"
        )
    ) {
        return;
    }

    this.securityService
        .forgotLockPassword()
        .subscribe({

            next: (response) => {

                alert(response.message);

                this.loadSecurity();

            }

        });

}

forgotDeletePassword(): void {

    if (
        !confirm(
            "Your delete password will be removed after the waiting period. Continue?"
        )
    ) {
        return;
    }

    this.securityService
        .forgotDeletePassword()
        .subscribe({

            next: (response) => {

                alert(response.message);

                this.loadSecurity();

            }

        });

}

}