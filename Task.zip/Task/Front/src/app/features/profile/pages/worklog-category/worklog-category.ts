import { Component, inject } from '@angular/core';

import { CommonModule } from '@angular/common';

import { ChangeDetectorRef } from '@angular/core';

import {
    FormBuilder,
    ReactiveFormsModule,
    Validators
} from '@angular/forms';

import { WorklogCategoryService } from '../../services/worklog-category';

import { WorklogCategoryModel } from '../../models/worklog-category';

import { CreateWorklogCategoryRequest } from '../../models/create-worklog-category-request';

import { UpdateWorklogCategoryRequest } from '../../models/update-worklog-category-request';


@Component({
    selector: 'app-worklog-category',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule
    ],
    templateUrl: './worklog-category.html',
    styleUrl: './worklog-category.scss'
})
export class WorklogCategory {


    private fb = inject(FormBuilder);


    private worklogCategoryService =
        inject(WorklogCategoryService);


    private cdr = inject(ChangeDetectorRef);



    worklogCategories: WorklogCategoryModel[] = [];


    selectedCategoryId: number | null = null;


    isEditMode = false;


    showModal = false;



    categoryForm = this.fb.group({

        name: [
            '',
            [
                Validators.required,
                Validators.maxLength(100)
            ]
        ]

    });



    ngOnInit(): void {

        this.loadWorklogCategories();

    }



    loadWorklogCategories(): void {


        this.worklogCategoryService
            .getList()
            .subscribe({


                next: (response) => {


                    this.worklogCategories =
                        response.data;


                    this.cdr.detectChanges();


                }


            });


    }



    openCreateModal(): void {


        this.isEditMode = false;


        this.selectedCategoryId = null;


        this.categoryForm.reset();


        this.showModal = true;


    }



    openEditModal(
        category: WorklogCategoryModel
    ): void {


        this.isEditMode = true;


        this.selectedCategoryId = category.id;


        this.categoryForm.patchValue({

            name: category.name

        });


        this.showModal = true;


    }



    closeModal(): void {


        this.showModal = false;


        this.categoryForm.reset();


        this.selectedCategoryId = null;


    }



    save(): void {


        this.categoryForm.markAllAsTouched();


        if (this.categoryForm.invalid) {

            return;

        }



        if (this.isEditMode) {


            this.update();


        }

        else {


            this.create();


        }


    }



    create(): void {


        const request: CreateWorklogCategoryRequest = {


            name: this.categoryForm.value.name!


        };



        this.worklogCategoryService
            .create(request)
            .subscribe({


                next: () => {


                    this.closeModal();


                    this.loadWorklogCategories();


                    alert(
                        "Worklog Category created successfully."
                    );


                }


            });


    }




    update(): void {


        const request: UpdateWorklogCategoryRequest = {


            name: this.categoryForm.value.name!


        };



        this.worklogCategoryService
            .update(
                this.selectedCategoryId!,
                request
            )
            .subscribe({


                next: () => {


                    this.closeModal();


                    this.loadWorklogCategories();


                    alert(
                        "Worklog Category updated successfully."
                    );


                }


            });


    }





    changeState(
        category: WorklogCategoryModel
    ): void {


        this.worklogCategoryService
            .changeState(category.id)
            .subscribe({


                next: () => {


                    this.loadWorklogCategories();


                }


            });


    }


}