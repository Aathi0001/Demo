import { Component, inject } from '@angular/core';

import { CommonModule } from '@angular/common';

import { Router, RouterLink } from '@angular/router';

import {
    FormBuilder,
    ReactiveFormsModule,
    Validators
} from '@angular/forms';

import { ProfileService } from '../../services/profile';

import { UpdateProfileRequest } from '../../models/update-profile-request';

@Component({
    selector: 'app-profile',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule,
        RouterLink
    ],
    templateUrl: './profile.html',
    styleUrl: './profile.scss'
})
export class Profile {

    private fb = inject(FormBuilder);

    private profileService = inject(ProfileService);

    private router = inject(Router);

    currentSection = "account";

sections = [

    {
        name: "Account",
        value: "account",
        route: "/profile"
    },

    {
        name: "Security",
        value: "security",
        route: "/security"
    },

    {
        name: "Categories",
        value: "categories",
        route: "/profile/categories"
    },

    {
        name: "Status",
        value: "status",
        route: "/profile/status"
    },

    {
        name: "Projects",
        value: "projects",
        route: "/profile/projects"
    },

    {
        name: "Preferences",
        value: "preferences",
        route: "/profile/preferences"
    },

    {
        name: "About",
        value: "about",
        route: "/profile/about"
    }

];

    profileForm = this.fb.group({

        display_name: [
            '',
            [
                Validators.required,
                Validators.maxLength(150)
            ]
        ],

        theme: [
            'system',
            Validators.required
        ],

        timezone: [
            'Asia/Kolkata',
            Validators.required
        ]

    });


    ngOnInit(): void {

        this.loadProfile();

    }


    changeSection(event: Event): void {

        const value = (event.target as HTMLSelectElement).value;

        const section = this.sections.find(

            x => x.value === value

        );

        if(section){

            this.currentSection = value;

            this.router.navigate([

                section.route

            ]);

        }

    }

    loadProfile(): void {

        this.profileService.getProfile().subscribe({

            next: (response) => {

                this.profileForm.patchValue({

                    display_name: response.data.display_name,

                    theme: response.data.theme,

                    timezone: response.data.timezone

                });

            }

        });

    }


    updateProfile(): void {

        this.profileForm.markAllAsTouched();

        if (this.profileForm.invalid) {
            return;
        }

        const request: UpdateProfileRequest = {

            display_name: this.profileForm.value.display_name!,

            theme: this.profileForm.value.theme!,

            timezone: this.profileForm.value.timezone!

        };

        this.profileService.updateProfile(request).subscribe({


            next: (response) => {

                // Update local storage
                const user = JSON.parse(
                    localStorage.getItem('user') ?? '{}'
                );

                user.display_name = response.data.display_name;

                localStorage.setItem(
                    'user',
                    JSON.stringify(user)
                );

                alert('Profile updated successfully.');

            }
        });

    }

}