import { Component, inject } from '@angular/core';

import { CommonModule } from '@angular/common';

import { ChangeDetectorRef } from '@angular/core';

import {
    FormBuilder,
    ReactiveFormsModule,
    Validators
} from '@angular/forms';

import { WorklogProjectService } from '../../services/worklog-project';

import { WorklogProjectModel } from '../../models/worklog-project';

import { CreateWorklogProjectRequest } from '../../models/create-worklog-project-request';

import { UpdateWorklogProjectRequest } from '../../models/update-worklog-project-request';


@Component({
    selector: 'app-worklog-project',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule
    ],
    templateUrl: './worklog-project.html',
    styleUrl: './worklog-project.scss'
})
export class WorklogProject {


    private fb = inject(FormBuilder);


    private worklogProjectService =
        inject(WorklogProjectService);


    private cdr = inject(ChangeDetectorRef);



    worklogProjects: WorklogProjectModel[] = [];


    selectedProjectId: number | null = null;


    isEditMode = false;


    showModal = false;



    projectForm = this.fb.group({

        name: [
            '',
            [
                Validators.required,
                Validators.maxLength(100)
            ]
        ]

    });



    ngOnInit(): void {

        this.loadWorklogProjects();

    }



    loadWorklogProjects(): void {


        this.worklogProjectService
            .getList()
            .subscribe({


                next: (response) => {


                    this.worklogProjects =
                        response.data;


                    this.cdr.detectChanges();


                }


            });


    }



    openCreateModal(): void {


        this.isEditMode = false;


        this.selectedProjectId = null;


        this.projectForm.reset();


        this.showModal = true;


    }



    openEditModal(
        project: WorklogProjectModel
    ): void {


        this.isEditMode = true;


        this.selectedProjectId = project.id;


        this.projectForm.patchValue({

            name: project.name

        });


        this.showModal = true;


    }



    closeModal(): void {


        this.showModal = false;


        this.projectForm.reset();


        this.selectedProjectId = null;


    }



    save(): void {


        this.projectForm.markAllAsTouched();


        if (this.projectForm.invalid) {

            return;

        }



        if (this.isEditMode) {


            this.update();


        }

        else {


            this.create();


        }


    }




    create(): void {


        const request: CreateWorklogProjectRequest = {


            name: this.projectForm.value.name!


        };



        this.worklogProjectService
            .create(request)
            .subscribe({


                next: () => {


                    this.closeModal();


                    this.loadWorklogProjects();


                    alert(
                        "Worklog Project created successfully."
                    );


                }


            });


    }





    update(): void {


        const request: UpdateWorklogProjectRequest = {


            name: this.projectForm.value.name!


        };



        this.worklogProjectService
            .update(
                this.selectedProjectId!,
                request
            )
            .subscribe({


                next: () => {


                    this.closeModal();


                    this.loadWorklogProjects();


                    alert(
                        "Worklog Project updated successfully."
                    );


                }


            });


    }





    changeState(
        project: WorklogProjectModel
    ): void {


        this.worklogProjectService
            .changeState(project.id)
            .subscribe({


                next: () => {


                    this.loadWorklogProjects();


                }


            });


    }


}