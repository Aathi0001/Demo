import { Component, inject } from '@angular/core';

import { CommonModule } from '@angular/common';

import { ChangeDetectorRef } from '@angular/core';

import {
    FormBuilder,
    ReactiveFormsModule,
    Validators
} from '@angular/forms';

import { PaymentMethodService } from '../../services/payment-method';

import { PaymentMethodModel } from '../../models/payment-method';

import { CreatePaymentMethodRequest } from '../../models/create-payment-method-request';

import { UpdatePaymentMethodRequest } from '../../models/update-payment-method-request';



@Component({
    selector: 'app-payment-method',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule
    ],
    templateUrl: './payment-method.html',
    styleUrl: './payment-method.scss'
})
export class PaymentMethod {


    private fb = inject(FormBuilder);


    private paymentMethodService =
        inject(PaymentMethodService);


    private cdr = inject(ChangeDetectorRef);



    paymentMethods: PaymentMethodModel[] = [];


    selectedPaymentMethodId: number | null = null;


    isEditMode = false;


    showModal = false;



    paymentForm = this.fb.group({

        name: [
            '',
            [
                Validators.required,
                Validators.maxLength(100)
            ]
        ]

    });



    ngOnInit(): void {

        this.loadPaymentMethods();

    }



    loadPaymentMethods(): void {


        this.paymentMethodService
            .getList()
            .subscribe({


                next: (response) => {


                    this.paymentMethods =
                        response.data;


                    this.cdr.detectChanges();


                }


            });


    }



    openCreateModal(): void {


        this.isEditMode = false;


        this.selectedPaymentMethodId = null;


        this.paymentForm.reset();


        this.showModal = true;


    }



    openEditModal(
        paymentMethod: PaymentMethodModel
    ): void {


        this.isEditMode = true;


        this.selectedPaymentMethodId = paymentMethod.id;


        this.paymentForm.patchValue({

            name: paymentMethod.name

        });


        this.showModal = true;


    }



    closeModal(): void {


        this.showModal = false;


        this.paymentForm.reset();


        this.selectedPaymentMethodId = null;


    }



    save(): void {


        this.paymentForm.markAllAsTouched();


        if (this.paymentForm.invalid) {

            return;

        }



        if (this.isEditMode) {


            this.update();


        }

        else {


            this.create();


        }


    }





    create(): void {


        const request: CreatePaymentMethodRequest = {


            name: this.paymentForm.value.name!


        };



        this.paymentMethodService
            .create(request)
            .subscribe({


                next: () => {


                    this.closeModal();


                    this.loadPaymentMethods();


                    alert(
                        "Payment Method created successfully."
                    );


                }


            });


    }





    update(): void {


        const request: UpdatePaymentMethodRequest = {


            name: this.paymentForm.value.name!


        };



        this.paymentMethodService
            .update(
                this.selectedPaymentMethodId!,
                request
            )
            .subscribe({


                next: () => {


                    this.closeModal();


                    this.loadPaymentMethods();


                    alert(
                        "Payment Method updated successfully."
                    );


                }


            });


    }





    changeState(
        paymentMethod: PaymentMethodModel
    ): void {


        this.paymentMethodService
            .changeState(paymentMethod.id)
            .subscribe({


                next: () => {


                    this.loadPaymentMethods();


                }


            });


    }


}