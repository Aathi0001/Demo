export interface RegisterRequest {

    username: string;

    email: string;

    password: string;

    confirm_password: string;

}