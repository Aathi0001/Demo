import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { ApiEndpoints } from '../../../core/constants/api-endpoints';

import { RegisterRequest } from '../models/register-request';
import { LoginRequest } from '../models/login-request';

import { ApiResponse } from '../../../core/models/api-response';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private http = inject(HttpClient);

  register(request: RegisterRequest): Observable<ApiResponse<null>> {

      return this.http.post<ApiResponse<null>>(
          ApiEndpoints.REGISTER,
          request
      );

  }

  login(request: LoginRequest): Observable<ApiResponse<any>> {

      return this.http.post<ApiResponse<any>>(
          ApiEndpoints.LOGIN,
          request
      );

  }

  refreshToken(refresh: string) {

      return this.http.post(
          ApiEndpoints.REFRESH,
          {
              refresh
          }
      );

  }

  logout(refreshToken: string) {

      return this.http.post(
          ApiEndpoints.LOGOUT,
          {
              refresh: refreshToken
          }
      );

  }

}