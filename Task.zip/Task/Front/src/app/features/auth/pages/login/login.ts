import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
    FormBuilder,
    ReactiveFormsModule,
    Validators
} from '@angular/forms';
import {
    Router,
    RouterLink
} from '@angular/router';

import { AuthService } from '../../services/auth';
import { TokenStorage } from '../../../../core/services/token-storage';
import { LoginRequest } from '../../models/login-request';

@Component({
    selector: 'app-login',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule,
        RouterLink
    ],
    templateUrl: './login.html',
    styleUrl: './login.scss'
})
export class Login {
    private fb = inject(FormBuilder);
    private authService = inject(AuthService);
    private tokenStorage = inject(TokenStorage);
    private router = inject(Router);

    loginForm = this.fb.group({
        username: [
            '',
            [
                Validators.required
            ]
        ],
        password: [
            '',
            [
                Validators.required
            ]
        ]
    });

    get f(){
        return this.loginForm.controls;
    }

    login(){
        this.loginForm.markAllAsTouched();

        if(this.loginForm.invalid){
            return;
        }

        const request: LoginRequest = {
            username: this.f.username.value!,
            password: this.f.password.value!
        };

        this.authService.login(request)
        .subscribe({
            next:(response)=>{
                const data = response.data;

                this.tokenStorage.setTokens(
                    data.access,
                    data.refresh
                );
                this.router.navigate([
                    '/home'
                ]);
            },
            error:(error)=>{
                console.log(error);
            }
        });
    }
}