import { Injectable, inject } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { ApiEndpoints } from '../../../core/constants/api-endpoints';

import { ApiResponse } from '../../../core/models/api-response';

import { AnimeModel } from '../models/anime';

import { AnimeListResponse } from '../models/anime-list-response';

import { CreateAnimeRequest } from '../models/create-anime-request';

import { UpdateAnimeRequest } from '../models/update-anime-request';

import { AnimeListRequest } from '../models/anime-list-request';

import { DeletePasswordRequest } from '../models/delete-password-request';

@Injectable({
    providedIn: 'root'
})
export class AnimeService {

    private http =
        inject(HttpClient);

    list(
        request: AnimeListRequest
    ): Observable<ApiResponse<AnimeListResponse>> {

        return this.http.post<ApiResponse<AnimeListResponse>>(
            ApiEndpoints.ANIME_LIST,
            request
        );

    }

    create(
        request: CreateAnimeRequest
    ): Observable<ApiResponse<AnimeModel>> {

        return this.http.post<ApiResponse<AnimeModel>>(
            ApiEndpoints.ANIME_CREATE,
            request
        );

    }

    update(
        animeId: number,
        request: UpdateAnimeRequest
    ): Observable<ApiResponse<AnimeModel>> {

        return this.http.put<ApiResponse<AnimeModel>>(
            `${ApiEndpoints.ANIME_UPDATE}/${animeId}/`,
            request
        );

    }

    scheduleDelete(
        animeId: number
    ): Observable<ApiResponse<any>> {

        return this.http.patch<ApiResponse<any>>(
            `${ApiEndpoints.ANIME_SCHEDULE_DELETE}/${animeId}/`,
            {}
        );

    }

    restore(
        animeId: number
    ): Observable<ApiResponse<any>> {

        return this.http.patch<ApiResponse<any>>(
            `${ApiEndpoints.ANIME_RESTORE}/${animeId}/`,
            {}
        );

    }

    permanentDelete(
        animeId: number,
        request: DeletePasswordRequest
    ): Observable<ApiResponse<any>> {

        return this.http.delete<ApiResponse<any>>(
            `${ApiEndpoints.ANIME_PERMANENT_DELETE}/${animeId}/`,
            {
                body: request
            }
        );

    }

}