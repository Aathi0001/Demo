import {
    Component,
    inject,
    OnInit
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

import {
    ChangeDetectorRef
} from '@angular/core';

import {
    AnimeCard
} from '../../components/anime-card/anime-card';

import {
    AnimeFilter
} from '../../components/anime-filter/anime-filter';

import {
    AnimeForm
} from '../../components/anime-form/anime-form';

import {
    AnimeMenu
} from '../../components/anime-menu/anime-menu';

import {
    DeletePassword
} from '../../components/delete-password/delete-password';

import {
    AnimeService
} from '../../services/anime';

import {
    AnimeStatusService
} from '../../../profile/services/anime-status';

import {
    AnimeModel
} from '../../models/anime';

import {
    AnimeStatusModel
} from '../../../profile/models/anime-status';

import {
    AnimeListRequest
} from '../../models/anime-list-request';

import {
    CreateAnimeRequest
} from '../../models/create-anime-request';

import {
    UpdateAnimeRequest
} from '../../models/update-anime-request';

import {
    DeletePasswordRequest
} from '../../models/delete-password-request';

import {
    HostListener
} from '@angular/core';

@Component({
    selector: 'app-anime',
    standalone: true,
    imports: [
        CommonModule,
        AnimeCard,
        AnimeFilter,
        AnimeForm,
        AnimeMenu,
        DeletePassword
    ],
    templateUrl: './anime.html',
    styleUrl: './anime.scss'
})
export class Anime
implements OnInit {

    private animeService =
        inject(AnimeService);

    private animeStatusService =
        inject(AnimeStatusService);

    private cdr =
        inject(ChangeDetectorRef);

    animes: AnimeModel[] = [];

    statuses: AnimeStatusModel[] = [];

    selectedAnime:
        AnimeModel | null = null;

    showForm = false;

    showMenu = false;

    showDeleteDialog = false;

    isEditMode = false;

    menuX = 0;

    menuY = 0;

    request: AnimeListRequest = {

        search: '',

        status_id: null,

        delete_status: false,

        order_by: 'created_at',

        order_type: 'desc',

        page: 1

    };

    totalPages = 1;

    currentPage = 1;

    totalRecords = 0;

    ngOnInit(): void {

        this.loadStatuses();

        this.loadAnime();

    }

    loadStatuses(): void {

    this.animeStatusService
        .getList()
        .subscribe({

            next: response => {

                this.statuses =
                    response.data;

                this.cdr.detectChanges();

            }

        });

}

loadAnime(): void {

    this.animeService
        .list(this.request)
        .subscribe({

            next: response => {

                this.animes =
                    response.data.results;

                this.currentPage =
                    response.data.current_page;

                this.totalPages =
                    response.data.total_pages;

                this.totalRecords =
                    response.data.count;

                this.cdr.detectChanges();

            }

        });

}

openCreate(): void {

    this.selectedAnime = null;

    this.isEditMode = false;

    this.showForm = true;

}

openEdit(
    anime: AnimeModel
): void {

    this.selectedAnime = anime;

    this.isEditMode = true;

    this.showForm = true;

}

closeForm(): void {

    this.showForm = false;

    this.selectedAnime = null;

}

openMenu(
    event: MouseEvent,
    anime: AnimeModel
): void {

    event.preventDefault();

    this.selectedAnime = anime;

    const width = 220;

const height = 140;

this.menuX = Math.min(

    event.clientX,

    window.innerWidth - width

);

this.menuY = Math.min(

    event.clientY,

    window.innerHeight - height

);

    this.showMenu = true;

}

closeMenu(): void {

    this.showMenu = false;

}


openDeleteDialog(): void {

    this.showDeleteDialog = true;

    this.closeMenu();

}

closeDeleteDialog(): void {

    this.showDeleteDialog = false;

}


nextPage(): void {

    if (
        this.currentPage >=
        this.totalPages
    ) {

        return;

    }

    this.request.page++;

    this.loadAnime();

}

previousPage(): void {

    if (
        this.currentPage <= 1
    ) {

        return;

    }

    this.request.page--;

    this.loadAnime();

}

save(
    value: any
): void {

    if (
        this.isEditMode
    ) {

        this.updateAnime(
            value
        );

    }

    else {

        this.createAnime(
            value
        );

    }

}

createAnime(
    value: any
): void {

    const request:
    CreateAnimeRequest = {

        anime_name:
            value.animeName,

        status:
            value.statusId,

        updated_till:
            value.updatedTill,

        watched_episode:
            value.watchedEpisode,

        notes:
            value.notes ?? ''

    };

    this.animeService
        .create(request)
        .subscribe({

            next: () => {

                this.closeForm();

                this.loadAnime();

            }

        });

}

updateAnime(
    value: any
): void {

    if (
        !this.selectedAnime
    ) {

        return;

    }

    const request:
    UpdateAnimeRequest = {

        anime_name:
            value.animeName,

        status:
            value.statusId,

        updated_till:
            value.updatedTill,

        watched_episode:
            value.watchedEpisode,

        notes:
            value.notes ?? ''

    };

    this.animeService
        .update(

            this.selectedAnime.anime_id,

            request

        )
        .subscribe({

            next: () => {

                this.closeForm();

                this.loadAnime();

            }

        });

}

scheduleDelete(): void {

    if (
        !this.selectedAnime
    ) {

        return;

    }

    this.animeService
        .scheduleDelete(
            this.selectedAnime.anime_id
        )
        .subscribe({

            next: () => {

                this.closeMenu();

                this.loadAnime();

            }

        });

}

restoreAnime(): void {

    if (
        !this.selectedAnime
    ) {

        return;

    }

    this.animeService
        .restore(
            this.selectedAnime.anime_id
        )
        .subscribe({

            next: () => {

                this.closeMenu();

                this.loadAnime();

            }

        });

}

permanentDelete(
    password: string
): void {

    if (
        !this.selectedAnime
    ) {

        return;

    }

    const request:
    DeletePasswordRequest = {

        delete_password:
            password

    };

    this.animeService
        .permanentDelete(

            this.selectedAnime.anime_id,

            request

        )
        .subscribe({

            next: () => {

                this.closeDeleteDialog();

                this.loadAnime();

            }

        });

}

search(
    search: string
): void {

    this.request.search =
        search;

    this.request.page = 1;

    this.loadAnime();

}

filterStatus(
    statusId: number | null
): void {

    this.request.status_id =
        statusId;

    this.request.page = 1;

    this.loadAnime();

}

sort(
    orderBy: string,
    orderType: string
): void {

    this.request.order_by =
        orderBy;

    this.request.order_type =
        orderType;

    this.loadAnime();

}

changeView(
    trash: boolean
): void {

    this.request.delete_status =
        trash;

    this.request.page = 1;

    this.loadAnime();

}

// @HostListener(
//     'document:click'
// )
// closeContextMenu(): void {

//     this.showMenu = false;

// }

@HostListener(
    'document:click',
    ['$event']
)
closeContextMenu(
    event: MouseEvent
): void {

    const target =
        event.target as HTMLElement;

    if (
        target.closest('.anime-menu') ||

        target.closest('.menu-btn')
    ) {

        return;

    }

    this.showMenu = false;

}
}