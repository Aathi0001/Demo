import {
    Component,
    inject,
    Output,
    Input,
    EventEmitter
} from '@angular/core';
import {
    CommonModule
} from '@angular/common';

import {
    ReactiveFormsModule,
    FormBuilder
} from '@angular/forms';

import {
    debounceTime,
    distinctUntilChanged
} from 'rxjs';

import { AnimeStatusModel } from '../../../profile/models/anime-status';


@Component({
    selector: 'app-anime-filter',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule
    ],
    templateUrl: './anime-filter.html',
    styleUrl: './anime-filter.scss'
})
export class AnimeFilter {

    @Input()

statuses: AnimeStatusModel[] = [];

    @Output()

search =
new EventEmitter<string>();

@Output()

filter =
new EventEmitter<number | null>();

@Output()

sort =
new EventEmitter<{

    orderBy:string;

    orderType:string;

}>();

@Output()

view =
new EventEmitter<boolean>();


    showFilters = false;

    private fb = new FormBuilder();

    filterForm = this.fb.group({

        search: [''],

        statusId: this.fb.control<number | null>(null),

        orderBy: ['created_at'],

        orderType: ['desc'],

        deleteStatus: [false]

    });


ngOnInit(): void {

    this.filterForm.controls.search.valueChanges
        .pipe(
            debounceTime(300),
            distinctUntilChanged()
        )
        .subscribe(value => {

            this.search.emit(value ?? '');

        });

    this.filterForm.controls.statusId.valueChanges
        .subscribe(value => {

            this.filter.emit(value);

        });

    this.filterForm.controls.deleteStatus.valueChanges
        .subscribe(value => {

            this.view.emit(value ?? false);

        });

        this.filterForm.controls.orderBy.valueChanges
    .subscribe(() => {

        this.emitSort();

    });

this.filterForm.controls.orderType.valueChanges
    .subscribe(() => {

        this.emitSort();

    });

}

private emitSort(): void {

    this.sort.emit({

        orderBy:
            this.filterForm.controls.orderBy.value ?? 'created_at',

        orderType:
            this.filterForm.controls.orderType.value ?? 'desc'

    });

}

    toggleFilters(): void {

        this.showFilters =
            !this.showFilters;

    }

}