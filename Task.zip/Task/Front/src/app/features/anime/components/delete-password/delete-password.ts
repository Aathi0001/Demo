import {
    Component,
    EventEmitter,
    Input,
    Output,
    inject
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

import {
    FormBuilder,
    ReactiveFormsModule,
    Validators
} from '@angular/forms';

@Component({
    selector: 'app-delete-password',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule
    ],
    templateUrl: './delete-password.html',
    styleUrl: './delete-password.scss'
})
export class DeletePassword {

    private fb =
        inject(FormBuilder);

    @Input()
    visible = false;

    @Output()
    cancel =
        new EventEmitter<void>();

    @Output()
    confirm =
        new EventEmitter<string>();

    form = this.fb.group({

        deletePassword: [
            '',
            Validators.required
        ]

    });

    submit(): void {

        this.form.markAllAsTouched();

        if (
            this.form.invalid
        ) {

            return;

        }

        this.confirm.emit(

            this.form.value.deletePassword!

        );

        this.form.reset();

    }

    close(): void {

        this.form.reset();

        this.cancel.emit();

    }

}