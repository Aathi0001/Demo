import {
    Component,
    EventEmitter,
    Input,
    Output
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

import {
    AnimeModel
} from '../../models/anime';

@Component({
    selector: 'app-anime-card',
    standalone: true,
    imports: [
        CommonModule
    ],
    templateUrl: './anime-card.html',
    styleUrl: './anime-card.scss'
})
export class AnimeCard {


private timer: any;
    @Input({
        required: true
    })
    anime!: AnimeModel;

    @Output()
    edit =
        new EventEmitter<AnimeModel>();

    @Output()
    menu =
        new EventEmitter<{
            event: MouseEvent;
            anime: AnimeModel;
        }>();

        touchStart(): void {

    this.timer = setTimeout(() => {

        this.menu.emit({

            event: new MouseEvent(
                'contextmenu',
                {
                    clientX:150,
                    clientY:150
                }
            ),

            anime:this.anime

        });

    },600);

}

touchEnd(): void {

    clearTimeout(
        this.timer
    );

}

    openMenu(
        event: MouseEvent
    ): void {

        event.preventDefault();

        this.menu.emit({

            event,

            anime: this.anime

        });

    }

    openEdit(): void {

        this.edit.emit(
            this.anime
        );

    }

}