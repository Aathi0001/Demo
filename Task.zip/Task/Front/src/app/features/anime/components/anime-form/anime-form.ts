import {
    Component,
    EventEmitter,
    Input,
    Output,
    inject
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

import {
    FormBuilder,
    ReactiveFormsModule,
    Validators
} from '@angular/forms';

import { AnimeStatusModel } from '../../../profile/models/anime-status';

import { AnimeModel } from '../../models/anime';

@Component({
    selector: 'app-anime-form',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule
    ],
    templateUrl: './anime-form.html',
    styleUrl: './anime-form.scss'
})
export class AnimeForm {

    private fb =
        inject(FormBuilder);

    @Input()
    visible = false;

    @Input()
    isEditMode = false;

    @Input()

statuses: AnimeStatusModel[] = [];

@Input()

selectedAnime:
AnimeModel | null = null;

    @Output()
    save =
        new EventEmitter<any>();

    @Output()
    close =
        new EventEmitter<void>();

    form = this.fb.group({

        animeName: [
            '',
            [
                Validators.required,
                Validators.maxLength(255)
            ]
        ],

        statusId: [
    null as number | null,
    Validators.required
],

        watchedEpisode: [
            0,
            Validators.min(0)
        ],

        updatedTill: [
            0,
            Validators.min(0)
        ],

        notes: [
            ''
        ]

    });

ngOnChanges(): void {

    if (this.selectedAnime) {

        this.form.patchValue({

            animeName:
                this.selectedAnime.anime_name,

            statusId:
                this.selectedAnime.status,

            watchedEpisode:
                this.selectedAnime.watched_episode,

            updatedTill:
                this.selectedAnime.updated_till,

            notes:
                this.selectedAnime.notes

        });

    }

    else {

        this.form.reset({

            animeName: '',

            statusId: null,

            watchedEpisode: 0,

            updatedTill: 0,

            notes: ''

        });

    }

}

    submit(): void {

        this.form.markAllAsTouched();

        if (
            this.form.invalid
        ) {

            return;

        }

        this.save.emit(
            this.form.value
        );

    }

    cancel(): void {

        this.form.reset();

        this.close.emit();

    }

}