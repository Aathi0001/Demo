import {
    Component,
    EventEmitter,
    Input,
    Output
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

@Component({
    selector: 'app-anime-menu',
    standalone: true,
    imports: [
        CommonModule
    ],
    templateUrl: './anime-menu.html',
    styleUrl: './anime-menu.scss'
})
export class AnimeMenu {

    @Input()
    visible = false;

    @Input()
    x = 0;

    @Input()
    y = 0;

    @Input()
    isTrash = false;

    @Output()
    edit =
        new EventEmitter<void>();

    @Output()
    moveToTrash =
        new EventEmitter<void>();

    @Output()
    restore =
        new EventEmitter<void>();

    @Output()
    permanentDelete =
        new EventEmitter<void>();

}