export interface AnimeListRequest {

    search: string;

    status_id: number | null;

    delete_status: boolean;

    order_by: string;

    order_type: string;

    page: number;

}