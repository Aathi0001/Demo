export interface UpdateAnimeRequest {

    anime_name: string;

    status: number;

    updated_till: number;

    watched_episode: number;

    notes: string;

}