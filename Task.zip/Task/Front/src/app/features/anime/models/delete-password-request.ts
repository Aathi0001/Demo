export interface DeletePasswordRequest {

    delete_password: string;

}