import {
    AnimeModel
} from './anime';
export interface AnimeListResponse {

    count: number;

    total_pages: number;

    current_page: number;

    results: AnimeModel[];

}