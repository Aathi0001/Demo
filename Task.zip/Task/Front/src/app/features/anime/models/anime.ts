export interface AnimeModel {

    anime_id: number;

    anime_name: string;

    status: number;

    status_name: string;

    updated_till: number;

    watched_episode: number;

    notes: string;

    delete_status: boolean;

    created_at: string;

    updated_at: string;

}