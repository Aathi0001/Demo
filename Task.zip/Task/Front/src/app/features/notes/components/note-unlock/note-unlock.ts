import {
    Component,
    Input,
    Output,
    EventEmitter,
    inject
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

import {
    ReactiveFormsModule,
    FormBuilder,
    Validators
} from '@angular/forms';


import {
    UnlockNoteRequest
} from '../../models/unlock-note-request';


@Component({
    selector: 'app-note-unlock',
    standalone: true,
    imports:[
        CommonModule,
        ReactiveFormsModule
    ],
    templateUrl:'./note-unlock.html',
    styleUrl:'./note-unlock.scss'
})
export class NoteUnlock {


    @Input()

    noteId!: number;



    @Output()

    unlock =
    new EventEmitter<UnlockNoteRequest>();



    @Output()

    close =
    new EventEmitter<void>();



    private fb =
    inject(FormBuilder);



    unlockForm =
    this.fb.group({

        lock_password:[

            '',

            Validators.required

        ]

    });



    submit():void{


        if(
            this.unlockForm.invalid
        ){

            return;

        }


        const request: UnlockNoteRequest = {

    lock_password:
        this.unlockForm.controls.lock_password.value ?? ''

};

this.unlock.emit(request);


    }



    cancel():void{

        this.close.emit();

    }

}