import {
    AfterViewInit,
    Component,
    ElementRef,
    EventEmitter,
    HostListener,
    Input,
    Output,
    ViewChild
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

import {
    FormsModule
} from '@angular/forms';

import {
    NoteModel
} from '../../models/note';

// import {
//     ViewEncapsulation
// } from '@angular/core';

import {
    ChangeDetectorRef,
    inject
} from '@angular/core';

@Component({

    selector:'app-note-viewer',

    standalone:true,

    imports:[
        CommonModule,
        FormsModule
    ],

    templateUrl:'./note-viewer.html',

    styleUrl:'./note-viewer.scss',

    // encapsulation: ViewEncapsulation.None


})
export class NoteViewer
implements AfterViewInit{

  private cdr =
    inject(ChangeDetectorRef);

    @Input()

    note!:NoteModel;

    @Output()

    close=
    new EventEmitter<void>();


    @ViewChild(
        'viewer'
    )

    viewer!:ElementRef<HTMLDivElement>;

    @ViewChild(
        'searchInput'
    )

    searchInput!:ElementRef<HTMLInputElement>;



    search='';

    matches:HTMLElement[]=[];

    currentMatch=0;

    matchCount=0;



    ngAfterViewInit():void{

        this.collectMatches();

    }



    get highlightedContent():string{

        if(!this.note){

            return '';

        }

        return this.highlight(
            this.note.content
        );

    }



    highlight(
        content:string
    ):string{

        let escaped=
        content
        .replace(/&/g,'&amp;')
        .replace(/</g,'&lt;')
        .replace(/>/g,'&gt;');

        if(!this.search.trim()){

            return escaped.replace(
                /\n/g,
                '<br>'
            );

        }

        const escapedSearch=
        this.search.replace(
            /[.*+?^${}()|[\]\\]/g,
            '\\$&'
        );

        const regex=
        new RegExp(
            escapedSearch,
            'gi'
        );

        return escaped
        .replace(
            regex,
            match=>`<mark>${match}</mark>`
        )
        .replace(
            /\n/g,
            '<br>'
        );

    }



    onSearch():void{
this.cdr.detectChanges();

            this.collectMatches();

    }



    collectMatches():void{

        if(!this.viewer){

            return;

        }

        this.matches=
        Array.from(

            this.viewer
            .nativeElement
            .querySelectorAll('mark')

        ) as HTMLElement[];

        this.matchCount=
        this.matches.length;

        this.currentMatch=0;

        if(this.matchCount){

            this.scrollToCurrent();

        }

    }



    next():void{

        if(!this.matchCount){

            return;

        }

        this.currentMatch++;

        if(

            this.currentMatch>=
            this.matchCount

        ){

            this.currentMatch=0;

        }

        this.scrollToCurrent();

    }



    previous():void{

        if(!this.matchCount){

            return;

        }

        this.currentMatch--;

        if(

            this.currentMatch<0

        ){

            this.currentMatch=
            this.matchCount-1;

        }

        this.scrollToCurrent();

    }



    scrollToCurrent():void{

        this.matches.forEach(mark => {

    mark.style.background = 'yellow';
    mark.style.color = 'black';

});



        const current=
        this.matches[
            this.currentMatch
        ];

        if(!current){

            return;

        }

        current.style.background = 'red';
current.style.color = 'white';

        current.scrollIntoView({

            behavior:'smooth',

            block:'center'

        });

    }



    @HostListener(
        'document:keydown.control.f',
        ['$event']
    )

    openSearch(
        event:Event
    ):void{

        event.preventDefault();

        this.searchInput
        ?.nativeElement
        .focus();

    }



    @HostListener(
        'document:keydown.f3',
        ['$event']
    )

    nextShortcut(
        event:Event
    ):void{

        event.preventDefault();

        this.next();

    }



    @HostListener(
        'document:keydown.shift.f3',
        ['$event']
    )

    previousShortcut(
        event:Event
    ):void{

        event.preventDefault();

        this.previous();

    }

}