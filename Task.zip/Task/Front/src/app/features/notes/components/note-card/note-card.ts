import {
    Component,
    Input,
    Output,
    EventEmitter
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

import {
    NoteModel
} from '../../models/note';

@Component({
    selector: 'app-note-card',
    standalone: true,
    imports: [
        CommonModule
    ],
    templateUrl: './note-card.html',
    styleUrl: './note-card.scss'
})
export class NoteCard {

    @Input()

    note!: NoteModel;

    pressTimer:any;

    @Output()

    open =
    new EventEmitter<void>();

    @Output()

    menu =
    new EventEmitter<MouseEvent>();

startPress(event: MouseEvent | TouchEvent): void {

    this.pressTimer = setTimeout(() => {

        if (event instanceof MouseEvent) {

            this.menu.emit(event);

        } else {

            const touch = event.touches[0];

            const mouseEvent = new MouseEvent('contextmenu', {

                clientX: touch.clientX,

                clientY: touch.clientY

            });

            this.menu.emit(mouseEvent);

        }

    }, 500);

}

cancelPress(){

    clearTimeout(this.pressTimer);

}



}