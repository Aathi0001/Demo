import {
    Component,
    Input,
    Output,
    EventEmitter
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

import {
    NoteModel
} from '../../models/note';

import {
    NoteCard
} from '../note-card/note-card';


@Component({

    selector:'app-note-list',

    standalone:true,

    imports:[
        CommonModule,
        NoteCard
    ],

    templateUrl:'./note-list.html',

    styleUrl:'./note-list.scss'

})
export class NoteList {


    @Input()

    notes: NoteModel[] = [];



    @Output()

    open =
    new EventEmitter<NoteModel>();



    @Output()

    menu =
    new EventEmitter<{

        event:MouseEvent,

        note:NoteModel

    }>();



    openNote(
        note:NoteModel
    ){

        this.open.emit(note);

    }



    openMenu(
        event:MouseEvent,
        note:NoteModel
    ){

        this.menu.emit({

            event,

            note

        });

    }

}