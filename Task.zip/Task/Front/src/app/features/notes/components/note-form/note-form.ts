import {
    Component,
    Input,
    Output,
    EventEmitter,
    OnChanges,
    SimpleChanges,
    inject
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

import {
    ReactiveFormsModule,
    FormBuilder,
    Validators
} from '@angular/forms';

import {
    CreateNoteRequest
} from '../../models/create-note-request';

import {
    NoteModel
} from '../../models/note';


@Component({
    selector: 'app-note-form',
    standalone: true,
    imports: [
        CommonModule,
        ReactiveFormsModule
    ],
    templateUrl: './note-form.html',
    styleUrl: './note-form.scss'
})
export class NoteForm
implements OnChanges {


    @Input()

    note:
    NoteModel | null = null;


    @Output()

    save =
    new EventEmitter<CreateNoteRequest>();


    @Output()

    close =
    new EventEmitter<void>();


    private fb =
    inject(FormBuilder);



    noteForm =
    this.fb.group({

        title: [
            ''
        ],

        content: [
            '',
            Validators.required
        ],

        is_pinned: [
            false
        ],

        is_locked: [
            false
        ],

        is_encrypted: [
            false
        ]

    });



    ngOnChanges(
        changes: SimpleChanges
    ): void {


        if (
            changes['note']
        ) {


            if(this.note) {


                this.noteForm.patchValue({

                    title:
                    this.note.title ?? '',

                    content:
                    this.note.content,

                    is_pinned:
                    this.note.is_pinned,

                    is_locked:
                    this.note.is_locked,

                    is_encrypted:
                    this.note.is_encrypted

                });


            }
            else {


                this.noteForm.reset({

                    title:'',

                    content:'',

                    is_pinned:false,

                    is_locked:false,

                    is_encrypted:false

                });


            }

        }

    }



    submit(): void {


        if(
            this.noteForm.invalid
        ){

            return;

        }


        const request: CreateNoteRequest = {

    title:
        this.noteForm.controls.title.value ?? '',

    content:
        this.noteForm.controls.content.value ?? '',

    is_pinned:
        this.noteForm.controls.is_pinned.value ?? false,

    is_locked:
        this.noteForm.controls.is_locked.value ?? false,

    is_encrypted:
        this.noteForm.controls.is_encrypted.value ?? false

};

this.save.emit(request);

    }



    cancel(): void {

        this.close.emit();

    }

}