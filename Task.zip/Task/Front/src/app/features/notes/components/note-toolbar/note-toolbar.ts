import {
    Component,
    Output,
    EventEmitter,
    OnInit,
    inject
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

import {
    ReactiveFormsModule,
    FormBuilder
} from '@angular/forms';

import {
    debounceTime,
    distinctUntilChanged
} from 'rxjs';

@Component({

    selector: 'app-note-toolbar',

    standalone: true,

    imports: [
        CommonModule,
        ReactiveFormsModule
    ],

    templateUrl: './note-toolbar.html',

    styleUrl: './note-toolbar.scss'

})
export class NoteToolbar
implements OnInit {

    @Output()

    search =
    new EventEmitter<string>();


    @Output()

    create =
    new EventEmitter<void>();


    @Output()

    view =
    new EventEmitter<boolean>();


    private fb =
    inject(FormBuilder);


    toolbarForm = this.fb.group({

    search: this.fb.control(''),

    deleteStatus: this.fb.control(false)

});


    ngOnInit(): void {


    this.toolbarForm.controls.search.valueChanges
    .pipe(

        debounceTime(300),

        distinctUntilChanged()

    )
    .subscribe(value => {


        this.search.emit(
            value ?? ''
        );


    });


    this.toolbarForm.controls.deleteStatus
.valueChanges
.subscribe(value => {

    this.view.emit(
        value ?? false
    );

});


}

}