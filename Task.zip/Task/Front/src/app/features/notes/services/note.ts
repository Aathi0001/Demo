import { inject, Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

import { ApiResponse } from '../../../core/models/api-response';

import { NoteModel } from '../models/note';

import { NoteListRequest } from '../models/note-list-request';

import { CreateNoteRequest } from '../models/create-note-request';

import { UpdateNoteRequest } from '../models/update-note-request';

import { UnlockNoteRequest } from '../models/unlock-note-request';

import { DeletePasswordRequest } from '../models/delete-password-request';

import { ApiEndpoints } from '../../../core/constants/api-endpoints';

@Injectable({

    providedIn: 'root'

})
export class NoteService {

    private http = inject(HttpClient);

    list(
        request: NoteListRequest
    ): Observable<ApiResponse<any>> {

        return this.http.post<ApiResponse<any>>(
            ApiEndpoints.NOTE_LIST,
            request
        );

    }

    detail(
        noteId: number
    ): Observable<ApiResponse<NoteModel>> {

        return this.http.get<ApiResponse<NoteModel>>(
           `${ApiEndpoints.NOTE_DETAIL}/${noteId}/`
        );

    }

    create(
        request: CreateNoteRequest
    ): Observable<ApiResponse<NoteModel>> {

        return this.http.post<ApiResponse<NoteModel>>(
            ApiEndpoints.NOTE_CREATE,
            request
        );

    }

    update(
        noteId: number,
        request: UpdateNoteRequest
    ): Observable<ApiResponse<NoteModel>> {

        return this.http.put<ApiResponse<NoteModel>>(
            `${ApiEndpoints.NOTE_UPDATE}/${noteId}/`,
            request
        );

    }

    unlock(
        noteId: number,
        request: UnlockNoteRequest
    ): Observable<ApiResponse<NoteModel>> {

        return this.http.post<ApiResponse<NoteModel>>(
            `${ApiEndpoints.NOTE_UNLOCK}/${noteId}/`,
            request
        );

    }

    scheduleDelete(
        noteId: number
    ): Observable<ApiResponse<any>> {

        return this.http.patch<ApiResponse<any>>(
            `${ApiEndpoints.NOTE_SCHEDULE_DELETE}/${noteId}/`,
            {}
        );

    }

    restore(
        noteId: number
    ): Observable<ApiResponse<any>> {

        return this.http.patch<ApiResponse<any>>(
            `${ApiEndpoints.NOTE_RESTORE}/${noteId}/`,
            {}
        );

    }

    permanentDelete(
        noteId: number,
        request: DeletePasswordRequest
    ): Observable<ApiResponse<any>> {

        return this.http.request<ApiResponse<any>>(

            'delete',

            `${ApiEndpoints.NOTE_PERMANENT_DELETE}/${noteId}/`,

            {

                body: request

            }

        );

    }

}