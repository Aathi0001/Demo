import {
    Component,
    inject,
    OnInit
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

import { FormsModule } from '@angular/forms';

import {
    ChangeDetectorRef
} from '@angular/core';

import {
    NoteToolbar
} from '../../components/note-toolbar/note-toolbar';

import {
    NoteList
} from '../../components/note-list/note-list';

import {
    NoteForm
} from '../../components/note-form/note-form';

import {
    NoteViewer
} from '../../components/note-viewer/note-viewer';

import {
    NoteUnlock
} from '../../components/note-unlock/note-unlock';


import {
    NoteService
} from '../../services/note';


import {
    NoteModel
} from '../../models/note';


import {
    NoteListRequest
} from '../../models/note-list-request';


import {
    CreateNoteRequest
} from '../../models/create-note-request';


import {
    UnlockNoteRequest
} from '../../models/unlock-note-request';

import {
    HostListener
} from '@angular/core';

import {
    DeletePassword
} from '../../../anime/components/delete-password/delete-password';


@Component({

    selector:'app-notes',

    standalone:true,

    imports:[

        CommonModule,

        NoteToolbar,

        NoteList,

        NoteForm,

        NoteUnlock,

        DeletePassword,

        FormsModule,

        NoteViewer

    ],

    templateUrl:'./note.html',

    styleUrl:'./note.scss'

})
export class Notes
implements OnInit {

showMenu = false;


showDeleteDialog = false;


menuX = 0;


menuY = 0;


    private noteService =
    inject(NoteService);

    private cdr =
    inject(ChangeDetectorRef);



    notes: NoteModel[] = [];



    selectedNote:
    NoteModel | null = null;



    openedNote:
    NoteModel | null = null;



    showForm = false;


    showUnlock = false;



    isEditMode = false;

//     searchText = '';

// highlightedContent = '';



    request: NoteListRequest = {


        search:'',


        delete_status:false,


        order_by:'created_at',


        order_type:'desc',


        page:1

    };



    currentPage = 1;


    totalPages = 1;

    totalRecords = 0;



    ngOnInit(): void {

    setTimeout(() => {

        this.loadNotes();

    });

}





    loadNotes():void {


        this.noteService
        .list(this.request)
        .subscribe({


            next:response=>{

                this.notes =
                response.data.results;

                this.currentPage =
                response.data.current_page;

                this.totalPages =
                response.data.total_pages;

                this.totalRecords =
                response.data.count;

                this.cdr.detectChanges()


            }


        });


    }





    create():void {


        this.selectedNote = null;


        this.isEditMode = false;


        this.showForm = true;


    }



closeForm(): void {

    this.showForm = false;

    this.selectedNote = null;

}


    openNote(
        note:NoteModel
    ):void {


        if(note.is_locked){


            this.selectedNote = note;


            this.showUnlock = true;


            return;

        }


        this.getDetail(note.note_id);


    }





    getDetail(
        noteId:number
    ):void {


        this.noteService
        .detail(noteId)
        .subscribe({


            next:response=>{


                this.openedNote =
                response.data;

//                 this.searchText = '';

// this.highlightedContent = this.openedNote.content;

this.cdr.detectChanges()

            }


        });


    }





    unlock(
        value:UnlockNoteRequest
    ):void {


        if(!this.selectedNote){

            return;

        }



        this.noteService
        .unlock(

            this.selectedNote.note_id,

            value

        )
        .subscribe({


            next:response=>{


                this.showUnlock = false;


                this.openedNote =
                response.data;

                // this.searchText = '';

// this.highlightedContent = this.openedNote.content;

                this.cdr.detectChanges()


            }


        });


    }





    closeUnlock():void {


        this.showUnlock=false;


    }




    save(
    value:CreateNoteRequest
):void {


    if(this.isEditMode){

        this.updateNote(value);

    }
    else{

        this.createNote(value);

    }

}

createNote(
    value:CreateNoteRequest
):void {


    this.noteService
    .create(value)
    .subscribe({

        next:()=>{


            this.closeForm();


            this.loadNotes();


        }

    });


}
updateNote(
    value: CreateNoteRequest
): void {

    console.log("Selected Note:", this.selectedNote);
    console.log("Note ID:", this.selectedNote?.note_id);

    if (!this.selectedNote) {

        return;

    }

    this.noteService
        .update(
            this.selectedNote.note_id,
            value
        )
        .subscribe({
            next: () => {

                this.closeForm();

                this.loadNotes();

                this.getDetail(this.selectedNote!.note_id);

            }
        });

}


    search(
        value:string
    ):void {


        this.request.search=value;


        this.request.page=1;


        this.loadNotes();


    }


// updateSearch(): void {

//     if (!this.openedNote) {

//         return;

//     }

//     const text = this.searchText.trim();

//     if (!text) {

//         this.highlightedContent =
//             this.openedNote.content;

//         return;

//     }

//     const escaped =
//         text.replace(
//             /[.*+?^${}()|[\]\\]/g,
//             '\\$&'
//         );

//     const regex =
//         new RegExp(
//             escaped,
//             'gi'
//         );

//     this.highlightedContent =
//         this.openedNote.content.replace(

//             regex,

//             match => `<mark>${match}</mark>`

//         );

// }


    changeView(
        trash:boolean
    ):void {


        this.request.delete_status =
        trash;


        this.request.page=1;


        this.loadNotes();


    }





    nextPage():void {


        if(
            this.currentPage <
            this.totalPages
        ){


            this.request.page++;


            this.loadNotes();

        }

    }





    previousPage():void {


        if(
            this.currentPage > 1
        ){


            this.request.page--;


            this.loadNotes();

        }

    }


editNote(): void {

    if (!this.selectedNote) {

        return;

    }

    this.noteService
        .detail(this.selectedNote.note_id)
        .subscribe({

            next: (response) => {

                this.selectedNote = response.data;

                this.isEditMode = true;

                this.showForm = true;

                this.closeMenu();

                this.cdr.detectChanges()

            }

        });

}

closeMenu(): void {

    this.showMenu = false;

}

openDeleteDialog(): void {

    console.log("Selected Note:", this.selectedNote);

    this.showDeleteDialog = true;

    this.closeMenu();

    this.cdr.detectChanges()


}

closeDeleteDialog(): void {

    this.showDeleteDialog = false;

}

closeNote(): void {

    this.openedNote = null;

}



openMenu(
    data:any
):void {


    data.event.preventDefault();



    this.selectedNote =
    data.note;



    this.menuX =
    data.event.clientX;



    this.menuY =
    data.event.clientY;



    this.showMenu=true;


}

scheduleDelete():void {


    if(!this.selectedNote){

        return;

    }


    this.noteService
    .scheduleDelete(

        this.selectedNote.note_id

    )
    .subscribe({

        next:()=>{


            this.closeMenu();

this.openedNote = null;

this.loadNotes();


        }

    });


}

restoreNote():void {


    if(!this.selectedNote){

        return;

    }


    this.noteService
    .restore(

        this.selectedNote.note_id

    )
    .subscribe({

        next:()=>{


            this.closeMenu();

this.loadNotes();


        }

    });


}
permanentDelete(
    password: string
): void {

    console.log("Selected Note:", this.selectedNote);
    console.log("Password:", password);

    if (!this.selectedNote) {
        return;
    }

    console.log("Note ID:", this.selectedNote.note_id);

    this.noteService
        .permanentDelete(
            this.selectedNote.note_id,
            {
                delete_password: password
            }
        )
        .subscribe({
            next: response => {

                console.log(response);

                this.closeDeleteDialog();
                this.closeMenu();
                this.openedNote = null;
                this.loadNotes();

            },
            error: err => {

                console.log(err);

            }
        });

}

@HostListener(
    'document:click',
    ['$event']
)
closeContextMenu(
    event: MouseEvent
): void {

    const target =
        event.target as HTMLElement;

    if (

        target.closest('.note-menu') ||

        target.closest('.menu-btn')

    ) {

        return;

    }

    this.showMenu = false;

}


}