export interface UnlockNoteRequest {

    lock_password: string;

}