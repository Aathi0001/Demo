export interface NoteListRequest {

    search: string;

    delete_status: boolean;

    order_by: string;

    order_type: string;

    page: number;

}