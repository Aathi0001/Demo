export interface CreateNoteRequest {

    title: string | null;

    content: string;

    is_pinned: boolean;

    is_locked: boolean;

    is_encrypted: boolean;

}