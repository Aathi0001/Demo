export interface NoteModel {

    note_id: number;

    title: string | null;

    content: string;

    is_pinned: boolean;

    is_locked: boolean;

    is_encrypted: boolean;

    delete_status: boolean;

    created_at: string;

    updated_at: string;

}