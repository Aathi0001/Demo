from rest_framework.views import APIView

from accounts.services.auth_service import AuthService

from accounts.serializers.notification_serializer import (
    NotificationListSerializer
)

from common.responses import ApiResponse


class NotificationView(APIView):

    auth_service = AuthService()

    def get(self, request):

        data = self.auth_service.get_notifications(
            request.user
        )

        serializer = NotificationListSerializer(data)

        return ApiResponse.success(
            data=serializer.data
        )