from rest_framework.views import APIView

from accounts.serializers.security_change_password_serializer import SecurityChangePasswordSerializer
from accounts.services.auth_service import AuthService

from common.responses import ApiResponse
from common.messages import Messages


class ChangeDeletePasswordView(APIView):

    auth_service = AuthService()

    def post(self, request):

        serializer = SecurityChangePasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        success = self.auth_service.change_delete_password(
            request.user,
            serializer.validated_data["old_password"],
            serializer.validated_data["new_password"]
        )

        if not success:
            return ApiResponse.error(
                message=Messages.INVALID_DELETE_PASSWORD
            )

        return ApiResponse.success(
            message=Messages.DELETE_PASSWORD_CHANGED
        )
