from rest_framework.views import APIView

from accounts.serializers.security_serializer import SecuritySerializer

from common.responses import ApiResponse
from common.messages import Messages

from accounts.services.auth_service import AuthService

class SecurityView(APIView):

    auth_service = AuthService()

    def get(self, request):

        security = self.auth_service.get_security(
            request.user
        )

        serializer = SecuritySerializer(
            security
        )

        return ApiResponse.success(
            data=serializer.data
        )


    def put(self, request):

        security = self.auth_service.get_security(
            request.user
        )

        serializer = SecuritySerializer(

            security,

            data=request.data,

            partial=True

        )

        serializer.is_valid(
            raise_exception=True
        )

        serializer.save()

        return ApiResponse.success(

            message=Messages.SECURITY_UPDATED,

            data=serializer.data

        )
