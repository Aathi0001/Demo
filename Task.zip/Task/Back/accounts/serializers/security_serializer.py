from rest_framework import serializers

from accounts.models import Security


class SecuritySerializer(serializers.ModelSerializer):

    has_lock_password = serializers.SerializerMethodField()

    has_delete_password = serializers.SerializerMethodField()

    lock_password_reset_scheduled = serializers.SerializerMethodField()

    delete_password_reset_scheduled = serializers.SerializerMethodField()

    class Meta:

        model = Security

        fields = (

            "has_lock_password",

            "has_delete_password",

            "lock_password_reset_scheduled",

            "delete_password_reset_scheduled",

            "anime_delete_after_hours",

            "worklog_delete_after_hours",

            "notes_delete_after_hours",

            "expense_delete_after_hours",

        )

    def get_has_lock_password(self, obj):

        return bool(obj.lock_password)

    def get_has_delete_password(self, obj):

        return bool(obj.delete_password)

    def get_lock_password_reset_scheduled(self, obj):

        return obj.lock_password_reset_at is not None

    def get_delete_password_reset_scheduled(self, obj):

        return obj.delete_password_reset_at is not None