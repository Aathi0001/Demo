from rest_framework import serializers


class NotificationSerializer(serializers.Serializer):

    type = serializers.CharField()

    title = serializers.CharField()

    reset_at = serializers.DateTimeField()


class NotificationListSerializer(serializers.Serializer):

    count = serializers.IntegerField()

    notifications = NotificationSerializer(many=True)