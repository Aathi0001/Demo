from django.db.models import Q
from django.core.paginator import Paginator
from django.utils import timezone
from datetime import timedelta

from apps.expenses.models.expense import Expense
from apps.expenses.models.payment_method import PaymentMethod

from common.constants import PaginationConstants

from accounts.services.auth_service import AuthService

from collections import OrderedDict

from decimal import Decimal

from datetime import timedelta

from datetime import date

from django.db.models import Count
from django.db.models import Sum
from django.db.models import Case
from django.db.models import When
from decimal import Decimal
from django.db.models import Value
from django.db.models import DecimalField
from django.db.models.functions import ExtractYear
from django.db.models.functions import Coalesce

from django.db.models.functions import ExtractMonth

import calendar


class ExpenseService:

    ALLOWED_ORDER_FIELDS = {

        "amount": "amount",

        "expense_date": "expense_date",

        "created_at": "created_at",

        "updated_at": "updated_at",

        "payment_method": "payment_method__payment_method_name",

    }
    # ==========================
    # Payment Method
    # ==========================


    def create_payment_method(
        self,
        user,
        validated_data
    ):

        if PaymentMethod.objects.filter(
            user=user,
            method_name__iexact=validated_data["method_name"]
        ).exists():

            return None

        return PaymentMethod.objects.create(
            user=user,
            **validated_data
        )



    def update_payment_method(
        self,
        user,
        payment_method_id,
        validated_data
    ):

        method = PaymentMethod.objects.filter(
            user=user,
            payment_method_id=payment_method_id
        ).first()

        if not method:
            return False

        if PaymentMethod.objects.filter(
            user=user,
            method_name__iexact=validated_data["method_name"]
        ).exclude(
            payment_method_id=payment_method_id
        ).exists():

            return None

        for field, value in validated_data.items():

            setattr(method, field, value)

        method.save()

        return method



    def list_payment_method(
        self,
        user
    ):

        return PaymentMethod.objects.filter(
            user=user
        ).order_by(
            "-created_at"
        )



    def change_payment_method_state(
        self,
        user,
        payment_method_id
    ):

        method = PaymentMethod.objects.filter(
            user=user,
            payment_method_id=payment_method_id
        ).first()


        if not method:

            return None


        method.is_active = not method.is_active


        method.save(
            update_fields=[
                "is_active",
                "updated_at"
            ]
        )


        return method


    # ==========================
    # Expense
    # ==========================

    def create(self, user, validated_data):

        if self._expense_exists(

            user,

            validated_data

        ):

            return None

        return Expense.objects.create(

            user=user,

            **validated_data

        )

    def update(

        self,

        user,

        expense_id,

        validated_data

    ):

        expense = self._get(

            user,

            expense_id

        )

        if not expense:

            return False

        if self._expense_exists(

            user,

            validated_data,

            expense_id

        ):

            return None

        for field, value in validated_data.items():

            setattr(

                expense,

                field,

                value

            )

        expense.save()

        return expense

    def list(self, user, validated_data):

        queryset = self._get_queryset(

            user

        )

        queryset = self._filter_month(
            queryset,
            validated_data
        )

        queryset = self._search(

            queryset,

            validated_data

        )

        queryset = self._filter(

            queryset,

            validated_data

        )

        queryset = self._order(

            queryset,

            validated_data

        )

        return self._build_response(
            queryset
        )

    def schedule_delete(self, user, expense_id):

        expense = self._get(

            user,

            expense_id

        )

        if not expense:

            return None

        expense.delete_status = True

        expense.deleted_at = (

            timezone.now()

            +

            timedelta(

                hours=user.security.expense_delete_after_hours

            )

        )

        expense.save(

            update_fields=[

                "delete_status",

                "deleted_at",

                "updated_at"

            ]

        )

        return expense

    def restore(self, user, expense_id):

        expense = self._get(

            user,

            expense_id

        )

        if not expense:

            return None

        expense.delete_status = False

        expense.deleted_at = None

        expense.save(

            update_fields=[

                "delete_status",

                "deleted_at",

                "updated_at"

            ]

        )

        return expense

    def permanent_delete(

        self,

        user,

        expense_id,

        delete_password

    ):

        if not AuthService().verify_delete_password(

            user,

            delete_password

        ):

            return None

        expense = self._get(

            user,

            expense_id

        )

        if not expense:

            return False

        expense.delete()

        return True

    # ==========================
    # Private Helpers
    # ==========================

    def _get(

        self,

        user,

        expense_id

    ):

        return Expense.objects.filter(

            user=user,

            expense_id=expense_id

        ).first()

    def _get_queryset(self, user):

        return Expense.objects.filter(

            user=user

        ).select_related(

            "payment_method"

        )

    def _search(

        self,

        queryset,

        validated_data

    ):

        search = validated_data.get(

            "search"

        )

        if not search:

            return queryset

        return queryset.filter(

            Q(

                notes__icontains=search

            )

            |

            Q(

                payment_method__method_name__icontains=search

            )

        )

    def _filter(

        self,

        queryset,

        validated_data

    ):

        payment_method_id = validated_data.get(

            "payment_method_id"

        )

        if payment_method_id:

            queryset = queryset.filter(

                payment_method_id=payment_method_id

            )

        delete_status = validated_data.get(

            "delete_status"

        )

        if delete_status is not None:

            queryset = queryset.filter(

                delete_status=delete_status

            )

        return queryset

    def _order(

        self,

        queryset,

        validated_data

    ):

        order_by = validated_data.get(

            "order_by",

            "created_at"

        )

        order_type = validated_data.get(

            "order_type",

            "desc"

        )

        order_by = self.ALLOWED_ORDER_FIELDS.get(

            order_by,

            "created_at"

        )

        if order_type == "desc":

            order_by = f"-{order_by}"

        return queryset.order_by(

            order_by

        )

    def _paginate(

        self,

        queryset,

        validated_data

    ):

        paginator = Paginator(

            queryset,

            PaginationConstants.PAGE_SIZE

        )

        page = paginator.get_page(

            validated_data.get(

                "page",

                1

            )

        )

        return {

            "count": paginator.count,

            "total_pages": paginator.num_pages,

            "current_page": page.number,

            "results": page.object_list,

        }

    def _filter_month(

        self,

        queryset,

        validated_data

    ):

        month_offset = validated_data.get(

            "month_offset",

            0

        )

        today = date.today()

        total_months = (

            today.year * 12

            +

            today.month

            -

            1

            -

            month_offset

        )

        year = total_months // 12

        month = (total_months % 12) + 1

        first_day = date(

            year,

            month,

            1

        )

        last_day = date(

            year,

            month,

            calendar.monthrange(

                year,

                month

            )[1]

        )

        return queryset.filter(

            expense_date__range=(

                first_day,

                last_day

            )

        )

    def _build_response(
        self,
        queryset
    ):

        if not queryset.exists():

            return {

                "month": "",

                "summary": {

                    "total_credit": Decimal("0"),

                    "total_debit": Decimal("0"),

                    "balance": Decimal("0")

                },

                "weeks": []

            }

        first = queryset.first()

        month = first.expense_date.strftime(

            "%B %Y"

        )

        total_credit = Decimal("0")

        total_debit = Decimal("0")

        weeks = OrderedDict()

        for expense in queryset:

            if expense.amount_type == "credit":

                total_credit += expense.amount

            else:

                total_debit += expense.amount

            week_start = (

                expense.expense_date
                -
                timedelta(
                    days=expense.expense_date.weekday()
                )
            )

            week_end = (

                week_start
                +
                timedelta(days=6)
            )

            label = (

                f"{week_start.strftime('%d %b')}"

                " - "

                f"{week_end.strftime('%d %b')}"

            )

            if label not in weeks:

                weeks[label] = []

            weeks[label].append(
                expense
            )

        return {

            "month": month,

            "summary": {

                "total_credit": total_credit,

                "total_debit": total_debit,

                "balance":
                total_credit
                -
                total_debit

            },

            "weeks": [

                {

                    "week": label,

                    "expenses": expenses

                }

                for label, expenses
                in weeks.items()

            ]

        }

    def _expense_exists(

        self,

        user,

        validated_data,

        exclude_id=None

    ):

        queryset = Expense.objects.filter(

            user=user,

            amount=validated_data["amount"],

            amount_type=validated_data["amount_type"],

            expense_date=validated_data["expense_date"],

            notes__iexact=validated_data["notes"].strip(),

            payment_method=validated_data["payment_method"]

        )

        if exclude_id:

            queryset = queryset.exclude(

                expense_id=exclude_id

            )

        return queryset.exists()


    def timeline_years(
        self,
        user
    ):

        queryset = (
            Expense.objects
            .filter(
                user=user,
                delete_status=False
            )
            .annotate(
                year=ExtractYear("expense_date")
            )
            .values("year")
            .annotate(

                expense_count=Count("expense_id"),

                total_credit=Coalesce(

                    Sum(

                        Case(

                            When(
                                amount_type="credit",
                                then="amount"
                            ),

                            default=Value(Decimal("0.00")),

                            output_field=DecimalField()

                        )

                    ),

                    Value(Decimal("0.00")),

    output_field=DecimalField()

                ),

                total_debit=Coalesce(

                    Sum(

                        Case(

                            When(
                                amount_type="debit",
                                then="amount"
                            ),

                            default=Value(Decimal("0.00")),

                            output_field=DecimalField()

                        )

                    ),

                    Value(Decimal("0.00")),

    output_field=DecimalField()

                )

            )
            .order_by("-year")
        )

        results = []

        for item in queryset:

            results.append({

                "year":
                item["year"],

                "expense_count":
                item["expense_count"],

                "total_credit":
                item["total_credit"],

                "total_debit":
                item["total_debit"],

                "net_amount":
                item["total_credit"] -
                item["total_debit"]

            })

        return results


    def timeline_months(
        self,
        user,
        year
    ):

        queryset = (
            Expense.objects
            .filter(
                user=user,
                delete_status=False,
                expense_date__year=year
            )
            .annotate(
                month=ExtractMonth("expense_date")
            )
            .values("month")
            .annotate(

                expense_count=Count("expense_id"),

                total_credit=Coalesce(

                    Sum(

                        Case(

                            When(
                                amount_type="credit",
                                then="amount"
                            ),

                            default=Value(Decimal("0.00")),

                            output_field=DecimalField()

                        )

                    ),

                    Value(Decimal("0.00")),

    output_field=DecimalField()

                ),

                total_debit=Coalesce(

                    Sum(

                        Case(

                            When(
                                amount_type="debit",
                                then="amount"
                            ),

                            default=Value(Decimal("0.00")),

                            output_field=DecimalField()

                        )

                    ),

                    Value(Decimal("0.00")),

    output_field=DecimalField()

                )

            )
            .order_by("-month")
        )

        today = date.today()

        current_month = today.month

        current_year = today.year

        results = []

        for item in queryset:

            month = item["month"]

            month_offset = (
                (current_year - year) * 12
                + (current_month - month)
            )

            results.append({

                "month":
                month,

                "month_name":
                calendar.month_name[month],

                "expense_count":
                item["expense_count"],

                "total_credit":
                item["total_credit"],

                "total_debit":
                item["total_debit"],

                "net_amount":
                item["total_credit"] -
                item["total_debit"],

                "month_offset":
                month_offset

            })

        return results




