from rest_framework.views import APIView

from apps.expenses.services.expenses_service import ExpenseService

from common.responses import SuccessResponse


class ExpenseTimelineYearView(
    APIView
):

    service = ExpenseService()

    def post(
        self,
        request
    ):

        data = self.service.timeline_years(
            request.user
        )

        print(data)

        return SuccessResponse(
            data=data
        )
