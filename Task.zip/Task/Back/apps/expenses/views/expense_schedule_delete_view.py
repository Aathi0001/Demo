from rest_framework.views import APIView

from apps.expenses.services.expenses_service import ExpenseService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class ExpenseScheduleDeleteView(APIView):

    service = ExpenseService()

    def patch(self, request, expense_id):

        expense = self.service.schedule_delete(
            request.user,
            expense_id
        )

        if not expense:

            return ErrorResponse(
                message=Messages.EXPENSE_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )

        return SuccessResponse(
            message=Messages.EXPENSE_DELETE_SCHEDULED,
            status_code=StatusCode.OK
        )