from rest_framework.views import APIView

from apps.expenses.serializers.expense_serializer import ExpenseSerializer
from apps.expenses.services.expenses_service import ExpenseService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class ExpenseCreateView(APIView):

    service = ExpenseService()

    def post(self, request):

        serializer = ExpenseSerializer(
            data=request.data
        )

        if not serializer.is_valid():

            return ErrorResponse(

                message=Messages.VALIDATION_ERROR,

                errors=serializer.errors,

                status_code=StatusCode.BAD_REQUEST

            )

        expense = self.service.create(

            request.user,

            serializer.validated_data

        )

        if expense is None:

            return ErrorResponse(

                message=Messages.EXPENSE_ALREADY_EXISTS,

                status_code=StatusCode.BAD_REQUEST

            )

        return SuccessResponse(

            message=Messages.EXPENSE_CREATED,

            data=ExpenseSerializer(expense).data,

            status_code=StatusCode.CREATED

        )