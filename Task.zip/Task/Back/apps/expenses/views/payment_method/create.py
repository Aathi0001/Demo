from rest_framework.views import APIView

from apps.expenses.serializers.payment_method_serializer import PaymentMethodSerializer
from apps.expenses.services.expenses_service import ExpenseService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class PaymentMethodCreateView(APIView):

    service = ExpenseService()


    def post(self, request):

        serializer = PaymentMethodSerializer(
            data=request.data
        )


        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )


        method = self.service.create_payment_method(
            request.user,
            serializer.validated_data
        )

        if method is None:

            return ErrorResponse(
                message=Messages.PAYMENT_METHOD_ALREADY_EXISTS,
                status_code=StatusCode.BAD_REQUEST
            )


        return SuccessResponse(
            message=Messages.PAYMENT_METHOD_CREATED,

            data=PaymentMethodSerializer(
                method
            ).data,

            status_code=StatusCode.CREATED
        )