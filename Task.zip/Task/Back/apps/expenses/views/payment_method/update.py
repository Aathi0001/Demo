from rest_framework.views import APIView

from apps.expenses.serializers.payment_method_serializer import PaymentMethodSerializer
from apps.expenses.services.expenses_service import ExpenseService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class PaymentMethodUpdateView(APIView):

    service = ExpenseService()


    def put(self, request, payment_method_id):

        serializer = PaymentMethodSerializer(
            data=request.data
        )


        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )


        method = self.service.update_payment_method(
            request.user,
            payment_method_id,
            serializer.validated_data
        )

        if method is False:

            return ErrorResponse(
                message=Messages.PAYMENT_METHOD_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )


        if method is None:

            return ErrorResponse(
                message=Messages.PAYMENT_METHOD_ALREADY_EXISTS,
                status_code=StatusCode.BAD_REQUEST
            )


        return SuccessResponse(
            message=Messages.PAYMENT_METHOD_UPDATED,

            data=PaymentMethodSerializer(
                method
            ).data,

            status_code=StatusCode.OK
        )