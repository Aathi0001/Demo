from rest_framework.views import APIView

from apps.expenses.serializers.payment_method_serializer import PaymentMethodSerializer
from apps.expenses.services.expenses_service import ExpenseService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class PaymentMethodChangeStateView(APIView):

    service = ExpenseService()


    def patch(self, request, payment_method_id):

        method = self.service.change_payment_method_state(
            request.user,
            payment_method_id
        )


        if not method:

            return ErrorResponse(
                message=Messages.PAYMENT_METHOD_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )


        return SuccessResponse(
            message=Messages.PAYMENT_METHOD_UPDATED,

            data=PaymentMethodSerializer(
                method
            ).data,

            status_code=StatusCode.OK
        )