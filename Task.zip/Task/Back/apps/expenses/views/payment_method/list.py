from rest_framework.views import APIView

from apps.expenses.serializers.payment_method_serializer import PaymentMethodSerializer
from apps.expenses.services.expenses_service import ExpenseService

from common.responses import SuccessResponse
from common.messages import Messages
from common.status_codes import StatusCode


class PaymentMethodListView(APIView):

    service = ExpenseService()


    def get(self, request):

        methods = self.service.list_payment_method(
            request.user
        )


        return SuccessResponse(
            message=Messages.SUCCESS,

            data=PaymentMethodSerializer(
                methods,
                many=True
            ).data,

            status_code=StatusCode.OK
        )