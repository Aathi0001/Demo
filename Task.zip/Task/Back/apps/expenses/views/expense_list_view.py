from rest_framework.views import APIView

from apps.expenses.serializers.expense_list_serializer import ExpenseListSerializer
from apps.expenses.serializers.expense_serializer import ExpenseSerializer
from apps.expenses.services.expenses_service import ExpenseService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class ExpenseListView(APIView):

    service = ExpenseService()

    def post(self, request):

        serializer = ExpenseListSerializer(
            data=request.data
        )

        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )

        result = self.service.list(

            request.user,

            serializer.validated_data

        )

        for week in result["weeks"]:

            week["expenses"] = ExpenseSerializer(

                week["expenses"],

                many=True

            ).data

        return SuccessResponse(
            message=Messages.SUCCESS,
            data=result,
            status_code=StatusCode.OK
        )