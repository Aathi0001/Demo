from rest_framework.views import APIView

from apps.expenses.serializers.expense_serializer import ExpenseSerializer
from apps.expenses.services.expenses_service import ExpenseService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class ExpenseUpdateView(APIView):

    service = ExpenseService()

    def put(self, request, expense_id):

        serializer = ExpenseSerializer(
            data=request.data
        )

        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )

        expense = self.service.update(
            request.user,
            expense_id,
            serializer.validated_data
        )

        if expense is False:

            return ErrorResponse(
                message=Messages.EXPENSE_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )

        if expense is None:

            return ErrorResponse(
                message=Messages.EXPENSE_ALREADY_EXISTS,
                status_code=StatusCode.BAD_REQUEST
            )

        return SuccessResponse(
            message=Messages.EXPENSE_UPDATED,
            data=ExpenseSerializer(expense).data,
            status_code=StatusCode.OK
        )