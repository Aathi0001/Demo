from rest_framework.views import APIView

from apps.expenses.services.expenses_service import ExpenseService

from common.responses import SuccessResponse


class ExpenseTimelineMonthView(
    APIView
):

    service = ExpenseService()

    def post(
        self,
        request
    ):

        year = request.data.get(
            "year"
        )

        data = self.service.timeline_months(
            request.user,
            year
        )

        print(data)

        return SuccessResponse(
            data=data
        )
