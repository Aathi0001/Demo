from rest_framework.views import APIView

from apps.anime.serializers.delete_password_serializer import DeletePasswordSerializer

from apps.expenses.services.expenses_service import ExpenseService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class ExpensePermanentDeleteView(APIView):

    service = ExpenseService()

    def delete(self, request, expense_id):

        serializer = DeletePasswordSerializer(
            data=request.data
        )

        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )

        result = self.service.permanent_delete(
            request.user,
            expense_id,
            serializer.validated_data["delete_password"]
        )

        if result is None:

            return ErrorResponse(
                message=Messages.DELETE_PASSWORD_NOT_AVAILABLE,
                status_code=StatusCode.BAD_REQUEST
            )

        if result is False:

            return ErrorResponse(
                message=Messages.EXPENSE_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )

        return SuccessResponse(
            message=Messages.EXPENSE_DELETED,
            status_code=StatusCode.OK
        )