from rest_framework import serializers

from apps.expenses.models.payment_method import PaymentMethod


class PaymentMethodSerializer(serializers.ModelSerializer):

    id = serializers.IntegerField(
        source="payment_method_id",
        read_only=True
    )

    name = serializers.CharField(
        source="method_name"
    )


    class Meta:

        model = PaymentMethod

        fields = [
            "id",
            "name",
            "is_active",
        ]


    def validate_method_name(self, value):

        value = value.strip()

        if not value:

            raise serializers.ValidationError(
                "Payment method name cannot be empty."
            )

        return value