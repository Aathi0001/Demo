from rest_framework import serializers


class ExpenseListSerializer(serializers.Serializer):

    search = serializers.CharField(
        required=False,
        allow_blank=True,
        default=""
    )

    payment_method_id = serializers.IntegerField(
        required=False,
        allow_null=True,
        default=None
    )

    delete_status = serializers.BooleanField(
        required=False,
        default=False
    )

    order_by = serializers.CharField(
        required=False,
        default="created_at"
    )

    order_type = serializers.ChoiceField(

        choices=[

            "asc",

            "desc"

        ],

        required=False,

        default="desc"

    )

    month_offset = serializers.IntegerField(
        required=False,
        default=0
    )