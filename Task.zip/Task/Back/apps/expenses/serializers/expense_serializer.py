from rest_framework import serializers

from apps.expenses.models.expense import Expense
from apps.expenses.models.payment_method import PaymentMethod


class ExpenseSerializer(serializers.ModelSerializer):

    payment_method_id = serializers.PrimaryKeyRelatedField(
        source="payment_method",
        queryset=PaymentMethod.objects.all(),
        required=False,
        allow_null=True
    )

    payment_method_name = serializers.CharField(
        source="payment_method.method_name",
        read_only=True,
        allow_null=True
    )

    class Meta:

        model = Expense

        fields = [

            "expense_id",

            "payment_method_id",

            "payment_method_name",

            "amount",

            "amount_type",

            "expense_date",

            "notes",

            "delete_status",

            "created_at",

            "updated_at",

        ]

    def validate_amount(self, value):

        if value <= 0:

            raise serializers.ValidationError(
                "Amount must be greater than zero."
            )

        return value

    def validate_notes(self, value):

        value = value.strip()

        if not value:

            raise serializers.ValidationError(
                "Notes cannot be empty."
            )

        return value