from django.db import models

from apps.common.models.soft_delete_model import SoftDeleteModel


class Expense(SoftDeleteModel):

    expense_id = models.AutoField(
        primary_key=True
    )

    user = models.ForeignKey(
        "auth.User",
        on_delete=models.CASCADE,
        related_name="expenses"
    )

    payment_method = models.ForeignKey(
        "expenses.PaymentMethod",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="expenses"
    )

    amount = models.DecimalField(
        max_digits=12,
        decimal_places=2
    )

    amount_type = models.CharField(
        max_length=20
    )

    expense_date = models.DateField()

    notes = models.TextField()

    class Meta:

        db_table = "expense"

        ordering = [
            "-created_at"
        ]

    def __str__(self):

        return (
            f"{self.amount} - "
            f"{self.expense_date}"
        )