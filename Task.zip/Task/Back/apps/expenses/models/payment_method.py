from django.db import models
from django.contrib.auth.models import User

from apps.common.models.base_model import BaseModel


class PaymentMethod(BaseModel):

    payment_method_id = models.AutoField(
        primary_key=True
    )

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="payment_methods"
    )

    method_name = models.CharField(
        max_length=100
    )

    is_active = models.BooleanField(
        default=True
    )


    class Meta:

        db_table = "payment_method"

        constraints = [

            models.UniqueConstraint(
                fields=[
                    "user",
                    "method_name"
                ],
                name="unique_user_payment_method"
            )

        ]

        ordering = [
            "method_name"
        ]


    def __str__(self):

        return self.method_name