from django.urls import path

from apps.expenses.views.payment_method.list import PaymentMethodListView
from apps.expenses.views.payment_method.create import PaymentMethodCreateView
from apps.expenses.views.payment_method.update import PaymentMethodUpdateView
from apps.expenses.views.payment_method.change_state import PaymentMethodChangeStateView
from django.urls import path

from apps.expenses.views.expense_create_view import ExpenseCreateView
from apps.expenses.views.expense_list_view import ExpenseListView
from apps.expenses.views.expense_update_view import ExpenseUpdateView
from apps.expenses.views.expense_schedule_delete_view import ExpenseScheduleDeleteView
from apps.expenses.views.expense_restore_view import ExpenseRestoreView
from apps.expenses.views.expense_permanent_delete_view import ExpensePermanentDeleteView


from apps.expenses.views.expense_timeline_year import ExpenseTimelineYearView

from apps.expenses.views.expense_timeline_month import ExpenseTimelineMonthView


urlpatterns = [
# ==========================
# Payment Method
# ==========================

path(
    "payment-method/create/",
    PaymentMethodCreateView.as_view(),
    name="payment-method-create"
),

path(
    "payment-method/update/<int:payment_method_id>/",
    PaymentMethodUpdateView.as_view(),
    name="payment-method-update"
),

path(
    "payment-method/list/",
    PaymentMethodListView.as_view(),
    name="payment-method-list"
),

path(
    "payment-method/change-state/<int:payment_method_id>/",
    PaymentMethodChangeStateView.as_view(),
    name="payment-method-change-state"
),

path(
        "create/",
        ExpenseCreateView.as_view()
    ),

    path(
        "list/",
        ExpenseListView.as_view()
    ),

    path(
        "update/<int:expense_id>/",
        ExpenseUpdateView.as_view()
    ),

    path(
        "schedule-delete/<int:expense_id>/",
        ExpenseScheduleDeleteView.as_view()
    ),

    path(
        "restore/<int:expense_id>/",
        ExpenseRestoreView.as_view()
    ),

    path(
        "permanent-delete/<int:expense_id>/",
        ExpensePermanentDeleteView.as_view()
    ),

path(
    "timeline/years/",
    ExpenseTimelineYearView.as_view()
),

path(
    "timeline/month/",
    ExpenseTimelineMonthView.as_view()
),

]