from rest_framework.views import APIView

from apps.worklog.serializers.worklog_serializer import WorkLogSerializer
from apps.worklog.services.worklog_service import WorkLogService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class WorkLogUpdateView(APIView):

    service = WorkLogService()

    def put(self, request, worklog_id):

        serializer = WorkLogSerializer(
            data=request.data
        )

        print(request.data)

        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )

        worklog = self.service.update(
            request.user,
            worklog_id,
            serializer.validated_data
        )

        if worklog is False:

            return ErrorResponse(
                message=Messages.WORKLOG_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )

        if worklog is None:

            return ErrorResponse(
                message=Messages.WORKLOG_ALREADY_EXISTS,
                status_code=StatusCode.BAD_REQUEST
            )

        return SuccessResponse(
            message=Messages.WORKLOG_UPDATED,
            data=WorkLogSerializer(worklog).data,
            status_code=StatusCode.OK
        )