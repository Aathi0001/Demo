from rest_framework.views import APIView

from apps.worklog.services.worklog_service import WorkLogService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class WorkLogScheduleDeleteView(APIView):

    service = WorkLogService()

    def patch(self, request, worklog_id):

        worklog = self.service.schedule_delete(
            request.user,
            worklog_id
        )

        if not worklog:

            return ErrorResponse(
                message=Messages.WORKLOG_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )

        return SuccessResponse(
            message=Messages.WORKLOG_DELETE_SCHEDULED,
            status_code=StatusCode.OK
        )