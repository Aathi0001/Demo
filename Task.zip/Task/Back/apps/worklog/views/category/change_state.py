from rest_framework.views import APIView

from apps.worklog.serializers.category_serializer import WorklogCategorySerializer
from apps.worklog.services.worklog_service import WorkLogService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class WorklogCategoryChangeStateView(APIView):

    service = WorkLogService()


    def patch(self, request, category_id):

        category = self.service.change_category_state(
            request.user,
            category_id
        )


        if not category:

            return ErrorResponse(
                message=Messages.WORKLOG_CATEGORY_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )


        return SuccessResponse(
            message=Messages.WORKLOG_CATEGORY_UPDATED,
            data=WorklogCategorySerializer(category).data,
            status_code=StatusCode.OK
        )