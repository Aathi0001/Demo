from rest_framework.views import APIView

from apps.worklog.serializers.category_serializer import WorklogCategorySerializer
from apps.worklog.services.worklog_service import WorkLogService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class WorklogCategoryUpdateView(APIView):

    service = WorkLogService()


    def put(self, request, category_id):

        serializer = WorklogCategorySerializer(
            data=request.data
        )


        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )


        category = self.service.update_category(
            request.user,
            category_id,
            serializer.validated_data
        )

        if category is False:

            return ErrorResponse(
                message=Messages.WORKLOG_CATEGORY_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )


        if category is None:

            return ErrorResponse(
                message=Messages.WORKLOG_CATEGORY_ALREADY_EXISTS,
                status_code=StatusCode.BAD_REQUEST
            )


        return SuccessResponse(
            message=Messages.WORKLOG_CATEGORY_UPDATED,
            data=WorklogCategorySerializer(category).data,
            status_code=StatusCode.OK
        )