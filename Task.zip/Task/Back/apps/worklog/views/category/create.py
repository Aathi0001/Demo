from rest_framework.views import APIView

from apps.worklog.serializers.category_serializer import WorklogCategorySerializer
from apps.worklog.services.worklog_service import WorkLogService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class WorklogCategoryCreateView(APIView):

    service = WorkLogService()


    def post(self, request):

        serializer = WorklogCategorySerializer(
            data=request.data
        )


        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )


        category = self.service.create_category(
            request.user,
            serializer.validated_data
        )

        if category is None:

            return ErrorResponse(
                message=Messages.WORKLOG_CATEGORY_ALREADY_EXISTS,
                status_code=StatusCode.BAD_REQUEST
            )


        return SuccessResponse(
            message=Messages.WORKLOG_CATEGORY_CREATED,
            data=WorklogCategorySerializer(category).data,
            status_code=StatusCode.CREATED
        )