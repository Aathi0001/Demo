from rest_framework.views import APIView

from apps.worklog.serializers.category_serializer import WorklogCategorySerializer
from apps.worklog.services.worklog_service import WorkLogService

from common.responses import SuccessResponse
from common.messages import Messages
from common.status_codes import StatusCode


class WorklogCategoryListView(APIView):

    service = WorkLogService()


    def get(self, request):

        categories = self.service.list_category(
            request.user
        )


        return SuccessResponse(
            message=Messages.SUCCESS,
            data=WorklogCategorySerializer(
                categories,
                many=True
            ).data,
            status_code=StatusCode.OK
        )