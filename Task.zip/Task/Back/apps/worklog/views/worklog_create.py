from rest_framework.views import APIView

from apps.worklog.serializers.worklog_serializer import WorkLogSerializer
from apps.worklog.serializers.worklog_create_serializer import WorkLogCreateSerializer
from apps.worklog.services.worklog_service import WorkLogService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class WorkLogCreateView(APIView):

    service = WorkLogService()

    def post(self, request):

        serializer = WorkLogCreateSerializer(
            data=request.data
        )

        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )

        worklog = self.service.create(
            request.user,
            serializer.validated_data
        )

        if worklog is None:

            return ErrorResponse(
                message=Messages.WORKLOG_ALREADY_EXISTS,
                status_code=StatusCode.BAD_REQUEST
            )

        return SuccessResponse(
            message=Messages.WORKLOG_CREATED,
            data=WorkLogSerializer(worklog).data,
            status_code=StatusCode.CREATED
        )