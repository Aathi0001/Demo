from rest_framework.views import APIView

from apps.worklog.serializers.worklog_list_serializer import WorkLogListSerializer
from apps.worklog.serializers.worklog_serializer import WorkLogSerializer
from apps.worklog.services.worklog_service import WorkLogService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class WorkLogListView(APIView):

    service = WorkLogService()

    def post(self, request):

        serializer = WorkLogListSerializer(
            data=request.data
        )

        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )

        result = self.service.list(
            request.user,
            serializer.validated_data
        )

        result["results"] = WorkLogSerializer(
            result["results"],
            many=True
        ).data

        return SuccessResponse(
            message=Messages.SUCCESS,
            data=result,
            status_code=StatusCode.OK
        )