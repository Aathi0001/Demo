from rest_framework.views import APIView

from apps.worklog.serializers.project_serializer import WorklogProjectSerializer
from apps.worklog.services.worklog_service import WorkLogService

from common.responses import SuccessResponse
from common.messages import Messages
from common.status_codes import StatusCode


class WorklogProjectListView(APIView):

    service = WorkLogService()


    def get(self, request):

        projects = self.service.list_project(
            request.user
        )


        return SuccessResponse(
            message=Messages.SUCCESS,
            data=WorklogProjectSerializer(
                projects,
                many=True
            ).data,
            status_code=StatusCode.OK
        )