from rest_framework.views import APIView

from apps.worklog.serializers.project_serializer import WorklogProjectSerializer
from apps.worklog.services.worklog_service import WorkLogService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class WorklogProjectUpdateView(APIView):

    service = WorkLogService()


    def put(self, request, project_id):

        serializer = WorklogProjectSerializer(
            data=request.data
        )


        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )


        project = self.service.update_project(
            request.user,
            project_id,
            serializer.validated_data
        )

        if project is False:

            return ErrorResponse(
                message=Messages.WORKLOG_PROJECT_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )


        if project is None:

            return ErrorResponse(
                message=Messages.WORKLOG_PROJECT_ALREADY_EXISTS,
                status_code=StatusCode.BAD_REQUEST
            )


        return SuccessResponse(
            message=Messages.WORKLOG_PROJECT_UPDATED,
            data=WorklogProjectSerializer(project).data,
            status_code=StatusCode.OK
        )