from rest_framework.views import APIView

from apps.worklog.serializers.project_serializer import WorklogProjectSerializer
from apps.worklog.services.worklog_service import WorkLogService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class WorklogProjectChangeStateView(APIView):

    service = WorkLogService()


    def patch(self, request, project_id):

        project = self.service.change_project_state(
            request.user,
            project_id
        )


        if not project:

            return ErrorResponse(
                message=Messages.WORKLOG_PROJECT_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )


        return SuccessResponse(
            message=Messages.WORKLOG_PROJECT_UPDATED,
            data=WorklogProjectSerializer(project).data,
            status_code=StatusCode.OK
        )