from rest_framework.views import APIView

from apps.worklog.serializers.project_serializer import WorklogProjectSerializer
from apps.worklog.services.worklog_service import WorkLogService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class WorklogProjectCreateView(APIView):

    service = WorkLogService()


    def post(self, request):

        serializer = WorklogProjectSerializer(
            data=request.data
        )


        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )


        project = self.service.create_project(
            request.user,
            serializer.validated_data
        )

        if project is None:

            return ErrorResponse(
                message=Messages.WORKLOG_PROJECT_ALREADY_EXISTS,
                status_code=StatusCode.BAD_REQUEST
            )


        return SuccessResponse(
            message=Messages.WORKLOG_PROJECT_CREATED,
            data=WorklogProjectSerializer(project).data,
            status_code=StatusCode.CREATED
        )