from django.urls import path

from apps.worklog.views.category.list import WorklogCategoryListView
from apps.worklog.views.category.create import WorklogCategoryCreateView
from apps.worklog.views.category.update import WorklogCategoryUpdateView
from apps.worklog.views.category.change_state import WorklogCategoryChangeStateView


from apps.worklog.views.project.list import WorklogProjectListView
from apps.worklog.views.project.create import WorklogProjectCreateView
from apps.worklog.views.project.update import WorklogProjectUpdateView
from apps.worklog.views.project.change_state import WorklogProjectChangeStateView

from apps.worklog.views.worklog_create import WorkLogCreateView
from apps.worklog.views.worklog_update import WorkLogUpdateView
from apps.worklog.views.worklog_list import WorkLogListView
from apps.worklog.views.worklog_schedule_delete import WorkLogScheduleDeleteView
from apps.worklog.views.worklog_restore import WorkLogRestoreView
from apps.worklog.views.worklog_permanent_delete import WorkLogPermanentDeleteView
from apps.worklog.views.worklog_timeline import WorkLogTimelineView

from apps.worklog.views.worklog_timeline_years import WorkLogTimelineYearsView

urlpatterns = [

# ==========================
# Worklog Category
# ==========================

path(
    "category/create/",
    WorklogCategoryCreateView.as_view(),
    name="worklog-category-create"
),

path(
    "category/update/<int:category_id>/",
    WorklogCategoryUpdateView.as_view(),
    name="worklog-category-update"
),

path(
    "category/list/",
    WorklogCategoryListView.as_view(),
    name="worklog-category-list"
),

path(
    "category/change-state/<int:category_id>/",
    WorklogCategoryChangeStateView.as_view(),
    name="worklog-category-change-state"
),



# ==========================
# Worklog Project
# ==========================

path(
    "project/create/",
    WorklogProjectCreateView.as_view(),
    name="worklog-project-create"
),

path(
    "project/update/<int:project_id>/",
    WorklogProjectUpdateView.as_view(),
    name="worklog-project-update"
),

path(
    "project/list/",
    WorklogProjectListView.as_view(),
    name="worklog-project-list"
),

path(
    "project/change-state/<int:project_id>/",
    WorklogProjectChangeStateView.as_view(),
    name="worklog-project-change-state"
),

path(
    "create/",
    WorkLogCreateView.as_view(),
    name="worklog-create"
),

path(
    "update/<int:worklog_id>/",
    WorkLogUpdateView.as_view(),
    name="worklog-update"
),

path(
    "list/",
    WorkLogListView.as_view(),
    name="worklog-list"
),

path(
    "schedule-delete/<int:worklog_id>/",
    WorkLogScheduleDeleteView.as_view(),
    name="worklog-schedule-delete"
),

path(
    "restore/<int:worklog_id>/",
    WorkLogRestoreView.as_view(),
    name="worklog-restore"
),

path(
    "permanent-delete/<int:worklog_id>/",
    WorkLogPermanentDeleteView.as_view(),
    name="worklog-permanent-delete"
),

path(
    "timeline/years/",
    WorkLogTimelineYearsView.as_view(),
    name="worklog-timeline-years"
),

path(
    "timeline/",
    WorkLogTimelineView.as_view(),
    name="worklog-timeline"
),

]