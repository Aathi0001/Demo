from rest_framework import serializers

from apps.worklog.models import WorkLog

from apps.worklog.models.project import WorklogProject
from apps.worklog.models.category import WorklogCategory


class WorkLogSerializer(serializers.ModelSerializer):


    project_name = serializers.CharField(
        source="project.project_name",
        allow_null=True,
        read_only=True
    )

    category_name = serializers.CharField(
        source="category.category_name",
        allow_null=True,
        read_only=True
    )

    project_id = serializers.PrimaryKeyRelatedField(
        source="project",
        queryset=WorklogProject.objects.all(),
        allow_null=True,
        required=False
    )

    category_id = serializers.PrimaryKeyRelatedField(
        source="category",
        queryset=WorklogCategory.objects.all(),
        allow_null=True,
        required=False
    )

    class Meta:

        model = WorkLog

        fields = [
            "worklog_id",
            
            "project_id",
            "category_id",
            "project_name",
            "category_name",
            "title",
            "notes",
            "work_date",
            "duration",
            "delete_status",
            "created_at",
             "updated_at"

        ]

    def validate_title(self, value):

        if value is None:
            return value

        value = value.strip()

        if not value:
            raise serializers.ValidationError(
                "Title cannot be empty."
            )

        return value

    def validate_notes(self, value):

        value = value.strip()

        if not value:

            raise serializers.ValidationError(
                "Notes cannot be empty."
            )

        return value

    def validate_duration(self, value):

        if value is None:
            return value

        value = value.strip()

        if value:

            if len(value) > 20:

                raise serializers.ValidationError(
                    "Duration is too long."
                )

        return value