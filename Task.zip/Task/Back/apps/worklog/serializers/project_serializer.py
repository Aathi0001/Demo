from rest_framework import serializers

from apps.worklog.models import WorklogProject


class WorklogProjectSerializer(serializers.ModelSerializer):

    id = serializers.IntegerField(
        source="project_id",
        read_only=True
    )

    name = serializers.CharField(
        source="project_name"
    )


    class Meta:

        model = WorklogProject

        fields = [
            "id",
            "name",
            "is_active",
        ]


    def validate_project_name(self, value):

        value = value.strip()

        if not value:

            raise serializers.ValidationError(
                "Project name cannot be empty."
            )

        return value