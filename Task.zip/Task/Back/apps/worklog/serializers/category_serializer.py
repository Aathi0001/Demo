from rest_framework import serializers

from apps.worklog.models import WorklogCategory


class WorklogCategorySerializer(serializers.ModelSerializer):

    id = serializers.IntegerField(
        source="category_id",
        read_only=True
    )

    name = serializers.CharField(
        source="category_name"
    )


    class Meta:

        model = WorklogCategory

        fields = [
            "id",
            "name",
            "is_active",
        ]


    def validate_category_name(self, value):

        value = value.strip()

        if not value:

            raise serializers.ValidationError(
                "Category name cannot be empty."
            )

        return value