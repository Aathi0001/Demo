from rest_framework import serializers


class WorkLogListSerializer(serializers.Serializer):

    search = serializers.CharField(
        required=False,
        allow_blank=True
    )

    project_id = serializers.IntegerField(
        required=False,
        allow_null=True
    )

    category_id = serializers.IntegerField(
        required=False,
        allow_null=True
    )

    delete_status = serializers.BooleanField(
        required=False
    )

    order_by = serializers.CharField(
        required=False,
        default="created_at"
    )

    order_type = serializers.ChoiceField(
        choices=["asc", "desc"],
        default="desc"
    )

    week_offset = serializers.IntegerField(
    default=0
)