from rest_framework import serializers

from apps.worklog.models import WorkLog
from apps.worklog.models.project import WorklogProject
from apps.worklog.models.category import WorklogCategory


class WorkLogCreateSerializer(serializers.ModelSerializer):

    project_id = serializers.PrimaryKeyRelatedField(
        source="project",
        queryset=WorklogProject.objects.all(),
        allow_null=True,
        required=False
    )

    category_id = serializers.PrimaryKeyRelatedField(
        source="category",
        queryset=WorklogCategory.objects.all(),
        allow_null=True,
        required=False
    )


    class Meta:

        model = WorkLog

        fields = [

            "project_id",
            "category_id",
            "title",
            "notes",
            "work_date",
            "duration",

        ]