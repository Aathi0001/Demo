from django.db import models
from django.contrib.auth.models import User

from apps.common.models.base_model import BaseModel


class WorklogCategory(BaseModel):

    category_id = models.AutoField(
        primary_key=True
    )

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="worklog_categories"
    )

    category_name = models.CharField(
        max_length=100
    )

    is_active = models.BooleanField(
        default=True
    )


    class Meta:

        db_table = "worklog_category"

        constraints = [

            models.UniqueConstraint(
                fields=[
                    "user",
                    "category_name"
                ],
                name="unique_user_worklog_category"
            )

        ]

        ordering = [
            "category_name"
        ]


    def __str__(self):

        return self.category_name