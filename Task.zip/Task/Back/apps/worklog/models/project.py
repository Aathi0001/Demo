from django.db import models
from django.contrib.auth.models import User

from apps.common.models.base_model import BaseModel


class WorklogProject(BaseModel):

    project_id = models.AutoField(
        primary_key=True
    )

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name="worklog_projects"
    )

    project_name = models.CharField(
        max_length=100
    )

    is_active = models.BooleanField(
        default=True
    )


    class Meta:

        db_table = "worklog_project"

        constraints = [

            models.UniqueConstraint(
                fields=[
                    "user",
                    "project_name"
                ],
                name="unique_user_worklog_project"
            )

        ]

        ordering = [
            "project_name"
        ]


    def __str__(self):

        return self.project_name