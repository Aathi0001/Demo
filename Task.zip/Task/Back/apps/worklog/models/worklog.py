from django.db import models

from apps.common.models.soft_delete_model import SoftDeleteModel

from apps.worklog.models.project import WorklogProject
from apps.worklog.models.category import WorklogCategory


class WorkLog(SoftDeleteModel):

    worklog_id = models.AutoField(
        primary_key=True
    )

    user = models.ForeignKey(
        "auth.User",
        on_delete=models.CASCADE
    )

    project = models.ForeignKey(
        WorklogProject,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    category = models.ForeignKey(
        WorklogCategory,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    title = models.CharField(
        max_length=255,
        blank=True
    )

    notes = models.TextField()

    work_date = models.DateField()

    duration = models.CharField(
        max_length=20,
        blank=True
    )

    class Meta:

        db_table = "work_log"

        ordering = [
            "-work_date",
            "-created_at"
        ]