from datetime import timedelta

from django.core.paginator import Paginator
from django.db.models import Q
from django.utils import timezone

from apps.worklog.models import WorkLog

from apps.worklog.models import WorklogCategory

from apps.worklog.models import WorklogProject

from accounts.services.auth_service import AuthService

from common.constants import PaginationConstants

from datetime import timedelta

from django.utils import timezone

from collections import OrderedDict

from datetime import date

from django.db.models import Count



class WorkLogService:

    ALLOWED_ORDER_FIELDS = {

        "title": "title",

        "work_date": "work_date",

        "duration": "duration",

        "created_at": "created_at",

        "updated_at": "updated_at",

    }

    # ==========================
    # Worklog Category
    # ==========================

    def create_category(self, user, validated_data):

        if WorklogCategory.objects.filter(
            user=user,
            category_name__iexact=validated_data["category_name"]
        ).exists():

            return None

        return WorklogCategory.objects.create(
            user=user,
            **validated_data
        )



    def update_category(
        self,
        user,
        category_id,
        validated_data
    ):

        category = WorklogCategory.objects.filter(
            user=user,
            category_id=category_id
        ).first()

        if not category:
            return False

        if WorklogCategory.objects.filter(
            user=user,
            category_name__iexact=validated_data["category_name"]
        ).exclude(
            category_id=category_id
        ).exists():

            return None

        for field, value in validated_data.items():

            setattr(category, field, value)

        category.save()

        return category



    def list_category(self, user):

        return WorklogCategory.objects.filter(
            user=user
        ).order_by(
            "-created_at"
        )



    def change_category_state(
        self,
        user,
        category_id
    ):

        category = WorklogCategory.objects.filter(
            user=user,
            category_id=category_id
        ).first()


        if not category:

            return None


        category.is_active = not category.is_active


        category.save(
            update_fields=[
                "is_active",
                "updated_at"
            ]
        )


        return category


    # ==========================
    # Worklog Project
    # ==========================


    def create_project(self, user, validated_data):

        if WorklogProject.objects.filter(
            user=user,
            project_name__iexact=validated_data["project_name"]
        ).exists():

            return None

        return WorklogProject.objects.create(
            user=user,
            **validated_data
        )

    def update_project(
        self,
        user,
        project_id,
        validated_data
    ):

        project = WorklogProject.objects.filter(
            user=user,
            project_id=project_id
        ).first()

        if not project:
            return False

        if WorklogProject.objects.filter(
            user=user,
            project_name__iexact=validated_data["project_name"]
        ).exclude(
            project_id=project_id
        ).exists():

            return None

        for field, value in validated_data.items():

            setattr(project, field, value)

        project.save()

        return project



    def list_project(self, user):

        return WorklogProject.objects.filter(
            user=user
        ).order_by(
            "-created_at"
        )



    def change_project_state(
        self,
        user,
        project_id
    ):

        project = WorklogProject.objects.filter(
            user=user,
            project_id=project_id
        ).first()


        if not project:

            return None


        project.is_active = not project.is_active


        project.save(
            update_fields=[
                "is_active",
                "updated_at"
            ]
        )


        return project

    # ==========================
    # Work Log
    # ==========================

    def create(self, user, validated_data):

        if self._worklog_exists(
            user,
            validated_data
        ):

            return None

        return WorkLog.objects.create(

            user=user,

            **validated_data

        )

    def update(
        self,
        user,
        worklog_id,
        validated_data
    ):

        worklog = self._get(
            user,
            worklog_id
        )

        if not worklog:

            return False

        if self._worklog_exists(
            user,
            validated_data,
            worklog_id
        ):

            return None

        for field, value in validated_data.items():

            setattr(
                worklog,
                field,
                value
            )

        worklog.save()

        return worklog

    def list(self, user, validated_data):

        queryset = self._get_queryset(
            user
        )

        queryset = self._search(
            queryset,
            validated_data
        )

        queryset = self._filter(
            queryset,
            validated_data
        )

        queryset = self._order(
            queryset,
            validated_data
        )

        return self._week_filter(
            queryset,
            validated_data
        )

    def schedule_delete(
        self,
        user,
        worklog_id
    ):

        worklog = self._get(
            user,
            worklog_id
        )

        if not worklog:

            return None

        worklog.delete_status = True

        worklog.deleted_at = (

            timezone.now()

            + timedelta(

                hours=user.security.worklog_delete_after_hours

            )

        )

        worklog.save(

            update_fields=[

                "delete_status",

                "deleted_at",

                "updated_at"

            ]

        )

        return worklog

    def restore(
        self,
        user,
        worklog_id
    ):

        worklog = self._get(
            user,
            worklog_id
        )

        if not worklog:

            return None

        worklog.delete_status = False

        worklog.deleted_at = None

        worklog.save(

            update_fields=[

                "delete_status",

                "deleted_at",

                "updated_at"

            ]

        )

        return worklog

    def permanent_delete(
        self,
        user,
        worklog_id,
        delete_password
    ):

        if not AuthService().verify_delete_password(

            user,

            delete_password

        ):

            return None

        worklog = self._get(
            user,
            worklog_id
        )

        if not worklog:

            return False

        worklog.delete()

        return True

    # ==========================
    # Private Helpers
    # ==========================

    def _get(
        self,
        user,
        worklog_id
    ):

        return WorkLog.objects.filter(

            user=user,

            worklog_id=worklog_id

        ).first()

    def _get_queryset(
        self,
        user
    ):

        return WorkLog.objects.filter(
            user=user
        ).select_related(
            "project",
            "category"
        )

    def _search(
        self,
        queryset,
        validated_data
    ):

        search = validated_data.get(
            "search"
        )

        if not search:

            return queryset

        return queryset.filter(

            Q(title__icontains=search)

            | Q(notes__icontains=search)

            | Q(project__project_name__icontains=search)

            | Q(category__category_name__icontains=search)

        )

    def _filter(
        self,
        queryset,
        validated_data
    ):

        project_id = validated_data.get(
            "project_id"
        )

        if project_id:

            queryset = queryset.filter(
                project_id=project_id
            )

        category_id = validated_data.get(
            "category_id"
        )

        if category_id:

            queryset = queryset.filter(
                category_id=category_id
            )

        delete_status = validated_data.get(
            "delete_status"
        )

        if delete_status is not None:

            queryset = queryset.filter(
                delete_status=delete_status
            )

        return queryset

    def _order(
        self,
        queryset,
        validated_data
    ):

        order_by = validated_data.get(

            "order_by",

            "created_at"

        )

        order_type = validated_data.get(

            "order_type",

            "desc"

        )

        order_by = self.ALLOWED_ORDER_FIELDS.get(

            order_by,

            "created_at"

        )

        if order_type == "desc":

            order_by = f"-{order_by}"

        return queryset.order_by(
            order_by
        )

    def _paginate(
        self,
        queryset,
        validated_data
    ):

        paginator = Paginator(

            queryset,

            PaginationConstants.PAGE_SIZE

        )

        page = paginator.get_page(

            validated_data.get(
                "page",
                1
            )

        )

        return {

            "count": paginator.count,

            "total_pages": paginator.num_pages,

            "current_page": page.number,

            "results": page.object_list,

        }


    def _week_filter(
        self,
        queryset,
        validated_data
    ):

        week_offset = validated_data.get(
            "week_offset",
            0
        )

        today = timezone.localdate()

        week_start = today - timedelta(
            days=today.weekday()
        )

        week_start += timedelta(
            weeks=week_offset
        )

        week_end = week_start + timedelta(
            days=6
        )

        queryset = queryset.filter(

            work_date__range=(

                week_start,

                week_end

            )

        )

        return {

            "week_start": week_start,

            "week_end": week_end,

            "total_entries": queryset.count(),

            "results": queryset

        }
    def _worklog_exists(
        self,
        user,
        validated_data,
        exclude_id=None
    ):

        queryset = WorkLog.objects.filter(

            user=user,

            title__iexact=validated_data.get(
                "title",
                ""
            ).strip(),

            work_date=validated_data["work_date"],

            notes__iexact=validated_data["notes"].strip()

        )

        if exclude_id:

            queryset = queryset.exclude(
                worklog_id=exclude_id
            )

        return queryset.exists()


    def get_timeline_years(
        self,
        user
    ):

        years = (

            WorkLog.objects

            .filter(

                user=user,

                delete_status=False

            )

            .values(

                "work_date__year"

            )

            .annotate(

                total_logs=Count(
                    "worklog_id"
                )

            )

            .order_by(

                "-work_date__year"

            )

        )

        return [

            {

                "year":
                item["work_date__year"],

                "total_logs":
                item["total_logs"]

            }

            for item in years

        ]


    def get_timeline(
        self,
        user,
        year
    ):

        worklogs = (

            WorkLog.objects

            .filter(

                user=user,

                delete_status=False,

                work_date__year=year

            )

            .order_by(

                "-work_date"

            )

        )

        today = date.today()

        current_week_start = (

            today -

            timedelta(
                days=today.weekday()
            )

        )

        months = OrderedDict()

        weeks = {}

        for worklog in worklogs:

            work_date = worklog.work_date

            week_start = (

                work_date -

                timedelta(
                    days=work_date.weekday()
                )

            )

            week_end = (

                week_start +

                timedelta(days=6)

            )

            week_key = week_start.isoformat()

            month_key = (

                week_start.month,

                week_start.strftime("%B")

            )

            if month_key not in months:

                months[month_key] = {

                    "month":
                    week_start.month,

                    "month_name":
                    week_start.strftime("%B"),

                    "total_logs":0,

                    "weeks":[]

                }

            if week_key not in weeks:

                week_offset = (

                    week_start -

                    current_week_start

                ).days // 7

                week = {

                    "week_start":
                    week_start,

                    "week_end":
                    week_end,

                    "week_offset":
                    week_offset,

                    "log_count":0

                }

                weeks[week_key] = week

                months[month_key][
                    "weeks"
                ].append(
                    week
                )

            weeks[
                week_key
            ][
                "log_count"
            ] += 1

            months[
                month_key
            ][
                "total_logs"
            ] += 1

        return {

            "year":year,

            "months":
            list(
                months.values()
            )

        }


