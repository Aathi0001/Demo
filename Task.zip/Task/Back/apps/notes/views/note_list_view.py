from rest_framework.views import APIView

from apps.notes.serializers.note_list_serializer import NoteListSerializer
from apps.notes.serializers.note_serializer import NoteSerializer
from apps.notes.services.note_service import NoteService
from apps.notes.serializers.note_list_response_serializer import NoteListResponseSerializer

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class NoteListView(APIView):

    service = NoteService()

    def post(self, request):

        serializer = NoteListSerializer(
            data=request.data
        )

        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )

        result = self.service.list(
            request.user,
            serializer.validated_data
        )

        result["results"] = NoteListResponseSerializer(
            result["results"],
            many=True
        ).data

        return SuccessResponse(
            message=Messages.SUCCESS,
            data=result,
            status_code=StatusCode.OK
        )