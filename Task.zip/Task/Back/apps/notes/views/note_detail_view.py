from rest_framework.views import APIView

from apps.notes.serializers.note_serializer import NoteSerializer
from apps.notes.services.note_service import NoteService
from apps.notes.serializers.note_detail_serializer import NoteDetailSerializer

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class NoteDetailView(APIView):

    service = NoteService()

    def get(self, request, note_id):

        note = self.service.detail(
            request.user,
            note_id
        )

        if not note:

            return ErrorResponse(
                message=Messages.NOTE_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )

        return SuccessResponse(
            message=Messages.SUCCESS,
            data=NoteDetailSerializer(note).data,
            status_code=StatusCode.OK
        )