from rest_framework.views import APIView

from apps.notes.serializers.note_serializer import NoteSerializer
from apps.notes.services.note_service import NoteService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class NoteUpdateView(APIView):

    service = NoteService()

    def put(self, request, note_id):

        serializer = NoteSerializer(
            data=request.data
        )

        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )

        note = self.service.update(
            request.user,
            note_id,
            serializer.validated_data
        )

        if note is False:

            return ErrorResponse(
                message=Messages.NOTE_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )

        if note is None:

            return ErrorResponse(
                message=Messages.NOTE_ALREADY_EXISTS,
                status_code=StatusCode.BAD_REQUEST
            )

        return SuccessResponse(
            message=Messages.NOTE_UPDATED,
            data=NoteSerializer(note).data,
            status_code=StatusCode.OK
        )