from rest_framework.views import APIView

from apps.notes.serializers.note_serializer import NoteSerializer
from apps.notes.services.note_service import NoteService
from apps.notes.serializers.note_detail_serializer import NoteDetailSerializer

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class NoteCreateView(APIView):

    service = NoteService()

    def post(self, request):

        serializer = NoteSerializer(
            data=request.data
        )

        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )

        note = self.service.create(
            request.user,
            serializer.validated_data
        )

        if note is None:

            return ErrorResponse(
                message=Messages.NOTE_ALREADY_EXISTS,
                status_code=StatusCode.BAD_REQUEST
            )

        return SuccessResponse(
            message=Messages.NOTE_CREATED,
            data=NoteSerializer(note).data,
            status_code=StatusCode.CREATED
        )