from rest_framework.views import APIView

from apps.notes.services.note_service import NoteService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class NoteScheduleDeleteView(APIView):

    service = NoteService()

    def patch(self, request, note_id):

        note = self.service.schedule_delete(
            request.user,
            note_id
        )

        if not note:

            return ErrorResponse(
                message=Messages.NOTE_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )

        return SuccessResponse(
            message=Messages.NOTE_DELETE_SCHEDULED,
            status_code=StatusCode.OK
        )