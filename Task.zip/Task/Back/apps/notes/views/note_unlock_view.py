from rest_framework.views import APIView

from apps.notes.serializers.lock_password_serializer import LockPasswordSerializer
from apps.notes.serializers.note_serializer import NoteSerializer
from apps.notes.services.note_service import NoteService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class NoteUnlockView(APIView):

    service = NoteService()

    def post(self, request, note_id):

        serializer = LockPasswordSerializer(
            data=request.data
        )

        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )

        note = self.service.unlock(
            request.user,
            note_id,
            serializer.validated_data["lock_password"]
        )

        if note is None:

            return ErrorResponse(
                message=Messages.LOCK_PASSWORD_NOT_AVAILABLE,
                status_code=StatusCode.BAD_REQUEST
            )

        if note is False:

            return ErrorResponse(
                message=Messages.NOTE_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )

        print(NoteSerializer(note).data)

        return SuccessResponse(
            message=Messages.SUCCESS,
            data=NoteSerializer(note).data,
            status_code=StatusCode.OK
        )