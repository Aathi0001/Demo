from django.db import models

from django.contrib.auth.models import User

from common.models import BaseModel
from apps.common.models.soft_delete_model import SoftDeleteModel


class Note(
    BaseModel,
    SoftDeleteModel
):

    note_id = models.AutoField(
        primary_key=True
    )

    user = models.ForeignKey(

        User,

        on_delete=models.CASCADE,

        related_name="notes"

    )

    title = models.CharField(

        max_length=255,

        blank=True

    )

    content = models.TextField()

    is_pinned = models.BooleanField(

        default=False

    )

    is_locked = models.BooleanField(

        default=False

    )

    is_encrypted = models.BooleanField(

        default=False

    )

    class Meta:

        db_table = "personal_note"

        ordering = [
            "-created_at"
        ]

    def __str__(self):

        return self.title or f"Note {self.note_id}"