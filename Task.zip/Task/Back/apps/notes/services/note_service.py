from django.db.models import Q
from django.core.paginator import Paginator
from django.utils import timezone
from datetime import timedelta

from apps.notes.models import Note

from accounts.services.auth_service import AuthService

from common.constants import PaginationConstants

from common.utils.encryption import encrypt_text

from common.utils.encryption import decrypt_text

class NoteService:

    # ==========================
    # Create
    # ==========================

    def create(self, user, validated_data):

        if self._title_exists(
            user,
            validated_data.get("title", "")
        ):

            return None

        validated_data["content"] = self._encrypt_content(
            validated_data
        )

        return Note.objects.create(
            user=user,
            **validated_data
        )

    # ==========================
    # Update
    # ==========================

    def update(
        self,
        user,
        note_id,
        validated_data
    ):

        note = self._get(
            user,
            note_id
        )

        if not note:

            return False

        if self._title_exists(
            user,
            validated_data.get("title", ""),
            note_id
        ):

            return None

        validated_data["is_encrypted"] = (
            note.is_encrypted or
            validated_data.get(
                "is_encrypted",
                False
            )
        )

        validated_data["content"] = (
            self._encrypt_content(
                validated_data
            )
        )

        for field, value in validated_data.items():

            setattr(
                note,
                field,
                value
            )

        note.save()

        return note

    # ==========================
    # List
    # ==========================

    def list(
        self,
        user,
        validated_data
    ):

        queryset = Note.objects.filter(
            user=user,
            delete_status=validated_data.get("delete_status")
        )


        search = validated_data.get(
            "search"
        )

        if search:

            queryset = queryset.filter(
                title__icontains=search
            )

        queryset = queryset.order_by(
            "-is_pinned",
            "-updated_at"
        )

        paginator = Paginator(

            queryset,

            PaginationConstants.PAGE_SIZE

        )

        page = paginator.get_page(

            validated_data.get(
                "page",
                1
            )

        )

        return {

            "count":
                paginator.count,

            "total_pages":
                paginator.num_pages,

            "current_page":
                page.number,

            "results":
                page.object_list

        }

    # ==========================
    # Detail
    # ==========================

    def detail(
        self,
        user,
        note_id
    ):

        note = self._get(
            user,
            note_id
        )

        if not note:

            return None

        return self._decrypt_note(
            note
        )
    # ==========================
    # Unlock
    # ==========================

    def unlock(
        self,
        user,
        note_id,
        password
    ):

        note = self._get(
            user,
            note_id
        )

        if not note:

            return False

        if not note.is_locked:

            return note

        if not AuthService().verify_lock_password(
            user,
            password
        ):

            return None

        return  self._decrypt_note(note)

    # ==========================
    # Schedule Delete
    # ==========================

    def schedule_delete(
        self,
        user,
        note_id
    ):

        note = self._get(
            user,
            note_id
        )

        if not note:

            return None

        note.delete_status = True

        note.deleted_at = (

            timezone.now()

            +

            timedelta(

                hours=user.security.notes_delete_after_hours

            )

        )

        note.save(

            update_fields=[

                "delete_status",

                "deleted_at",

                "updated_at"

            ]

        )

        return note

    # ==========================
    # Restore
    # ==========================

    def restore(
        self,
        user,
        note_id
    ):

        note = self._get(
            user,
            note_id
        )

        if not note:

            return None

        note.delete_status = False

        note.deleted_at = None

        note.save(

            update_fields=[

                "delete_status",

                "deleted_at",

                "updated_at"

            ]

        )

        return note

    # ==========================
    # Permanent Delete
    # ==========================

    def permanent_delete(
        self,
        user,
        note_id,
        delete_password
    ):

        if not AuthService().verify_delete_password(

            user,

            delete_password

        ):

            return None

        note = self._get(
            user,
            note_id
        )

        if not note:

            return False

        note.delete()

        return True

    # ==========================
    # Private Helpers
    # ==========================

    def _get(
        self,
        user,
        note_id
    ):

        return Note.objects.filter(

            user=user,

            note_id=note_id

        ).first()

    def _title_exists(
        self,
        user,
        title,
        exclude_id=None
    ):

        if not title:

            return False

        queryset = Note.objects.filter(

            user=user,

            title__iexact=title.strip()

        )

        if exclude_id:

            queryset = queryset.exclude(

                note_id=exclude_id

            )

        return queryset.exists()


    def _encrypt_content(
        self,
        validated_data
    ):

        content = validated_data["content"]

        if not validated_data.get(
            "is_encrypted",
            False
        ):

            return content

        return encrypt_text(
            content
        )

    def _decrypt_note(
        self,
        note
    ):

        if not note.is_encrypted:

            return note

        note.content = decrypt_text(
            note.content
        )

        return note