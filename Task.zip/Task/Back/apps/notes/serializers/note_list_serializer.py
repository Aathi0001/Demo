from rest_framework import serializers


class NoteListSerializer(serializers.Serializer):

    search = serializers.CharField(
        required=False,
        allow_blank=True
    )

    page = serializers.IntegerField(
        required=False,
        default=1,
        min_value=1
    )

    delete_status = serializers.BooleanField(
        required=False,
        default=False
    )