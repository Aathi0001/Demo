from rest_framework import serializers


class NoteSerializer(serializers.Serializer):

    title = serializers.CharField(
        required=False,
        allow_blank=True,
        max_length=255
    )

    content = serializers.CharField()

    is_pinned = serializers.BooleanField(
        required=False,
        default=False
    )

    is_locked = serializers.BooleanField(
        required=False,
        default=False
    )

    is_encrypted = serializers.BooleanField(
        required=False,
        default=False
    )

    def validate_title(self, value):

        return value.strip()

    def validate_content(self, value):

        value = value.strip()

        if not value:

            raise serializers.ValidationError(
                "Content cannot be empty."
            )

        return value