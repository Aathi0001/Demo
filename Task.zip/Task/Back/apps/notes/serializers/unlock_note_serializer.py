from rest_framework import serializers


class UnlockNoteSerializer(serializers.Serializer):

    lock_password = serializers.CharField()