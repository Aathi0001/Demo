from rest_framework import serializers

from apps.notes.models import Note


class NoteListResponseSerializer(serializers.ModelSerializer):

    class Meta:

        model = Note

        fields = [

            "note_id",

            "title",

            "is_pinned",

            "is_locked",

            "delete_status",

            "is_encrypted",

            "created_at",

            "updated_at"

        ]