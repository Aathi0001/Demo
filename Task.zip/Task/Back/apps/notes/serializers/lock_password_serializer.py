from rest_framework import serializers


class LockPasswordSerializer(
    serializers.Serializer
):

    lock_password = serializers.CharField(

        max_length=255

    )