from rest_framework import serializers

from apps.notes.models import Note


class NoteDetailSerializer(serializers.ModelSerializer):

    class Meta:

        model = Note

        fields = [

            "note_id",

            "title",

            "content",

            "is_pinned",

            "is_locked",

            "is_encrypted",

            "created_at",

            "updated_at"

        ]