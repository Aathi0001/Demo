from rest_framework import serializers


class DeletePasswordSerializer(
    serializers.Serializer
):

    delete_password = serializers.CharField(

        max_length=255

    )