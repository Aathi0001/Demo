from django.urls import path

from apps.notes.views.note_create_view import NoteCreateView
from apps.notes.views.note_update_view import NoteUpdateView
from apps.notes.views.note_list_view import NoteListView
from apps.notes.views.note_schedule_delete_view import NoteScheduleDeleteView
from apps.notes.views.note_restore_view import NoteRestoreView
from apps.notes.views.note_permanent_delete_view import NotePermanentDeleteView
from apps.notes.views.note_unlock_view import NoteUnlockView
from apps.notes.views.note_detail_view import NoteDetailView

urlpatterns = [

    path(
        "create/",
        NoteCreateView.as_view()
    ),

    path(
        "update/<int:note_id>/",
        NoteUpdateView.as_view()
    ),

    path(
        "list/",
        NoteListView.as_view()
    ),

    path(
        "schedule-delete/<int:note_id>/",
        NoteScheduleDeleteView.as_view()
    ),

    path(
        "restore/<int:note_id>/",
        NoteRestoreView.as_view()
    ),

    path(
        "permanent-delete/<int:note_id>/",
        NotePermanentDeleteView.as_view()
    ),

    path(
        "unlock/<int:note_id>/",
        NoteUnlockView.as_view()
    ),

    path(
        "detail/<int:note_id>/",
        NoteDetailView.as_view()
    ),
]