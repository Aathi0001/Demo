from rest_framework import serializers


class DeletePasswordSerializer(serializers.Serializer):

    delete_password = serializers.CharField(
        trim_whitespace=False
    )