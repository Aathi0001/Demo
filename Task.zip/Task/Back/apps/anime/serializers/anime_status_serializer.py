from rest_framework import serializers

from apps.anime.models import AnimeStatus

class AnimeStatusSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(source="status_id", read_only=True)
    name = serializers.CharField(source="status_name")
    class Meta:
        model = AnimeStatus

        fields = [
            "id",
            "name",
            "is_active",
        ]

    def validate_status_name(self, value):

        value = value.strip()

        if not value:
            raise serializers.ValidationError(
                "Status name cannot be empty."
            )

        return value