from rest_framework import serializers

from apps.anime.models import Anime


class AnimeSerializer(serializers.ModelSerializer):

    anime_id = serializers.IntegerField(
        read_only=True
    )

    status_name = serializers.CharField(
        source="status.status_name",
        read_only=True
    )

    class Meta:

        model = Anime

        fields = [

            "anime_id",

            "anime_name",

            "status",

            "status_name",

            "updated_till",

            "watched_episode",

            "notes",

        ]

    def validate_anime_name(self, value):

        value = value.strip()

        if not value:

            raise serializers.ValidationError(
                "Anime name cannot be empty."
            )

        return value