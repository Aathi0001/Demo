from django.urls import path

from apps.anime.views.anime.create import AnimeCreateView
from apps.anime.views.anime.update import AnimeUpdateView
from apps.anime.views.anime.list import AnimeListView
from apps.anime.views.anime.schedule_delete import AnimeScheduleDeleteView
from apps.anime.views.anime.restore import AnimeRestoreView
from apps.anime.views.anime.permanent_delete import AnimePermanentDeleteView

from apps.anime.views.status.create import AnimeStatusCreateView
from apps.anime.views.status.update import AnimeStatusUpdateView
from apps.anime.views.status.list import AnimeStatusListView
from apps.anime.views.status.change_state import AnimeStatusChangeStateView


urlpatterns = [

    # ==========================
    # Anime
    # ==========================

    path(
        "create/",
        AnimeCreateView.as_view(),
        name="anime-create"
    ),

    path(
        "update/<int:anime_id>/",
        AnimeUpdateView.as_view(),
        name="anime-update"
    ),

    path(
        "list/",
        AnimeListView.as_view(),
        name="anime-list"
    ),

    path(
        "schedule-delete/<int:anime_id>/",
        AnimeScheduleDeleteView.as_view(),
        name="anime-schedule-delete"
    ),

    path(
        "restore/<int:anime_id>/",
        AnimeRestoreView.as_view(),
        name="anime-restore"
    ),

    path(
        "permanent-delete/<int:anime_id>/",
        AnimePermanentDeleteView.as_view(),
        name="anime-permanent-delete"
    ),

    # ==========================
    # Anime Status
    # ==========================

    path(
        "status/create/",
        AnimeStatusCreateView.as_view(),
        name="anime-status-create"
    ),

    path(
        "status/update/<int:status_id>/",
        AnimeStatusUpdateView.as_view(),
        name="anime-status-update"
    ),

    path(
        "status/list/",
        AnimeStatusListView.as_view(),
        name="anime-status-list"
    ),

    path(
        "status/change-state/<int:status_id>/",
        AnimeStatusChangeStateView.as_view(),
        name="anime-status-change-state"
    ),

]