from rest_framework.views import APIView

from apps.anime.serializers.anime_serializer import AnimeSerializer
from apps.anime.services.anime_service import AnimeService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class AnimeUpdateView(APIView):

    service = AnimeService()

    def put(self, request, anime_id):

        serializer = AnimeSerializer(
            data=request.data
        )

        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )

        anime = self.service.update(
            request.user,
            anime_id,
            serializer.validated_data
        )

        if anime is False:

            return ErrorResponse(
                message=Messages.ANIME_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )

        if anime is None:

            return ErrorResponse(
                message=Messages.ANIME_ALREADY_EXISTS,
                status_code=StatusCode.BAD_REQUEST
            )

        return SuccessResponse(
            message=Messages.ANIME_UPDATED,
            data=AnimeSerializer(anime).data,
            status_code=StatusCode.OK
        )