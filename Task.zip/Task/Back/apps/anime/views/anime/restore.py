from rest_framework.views import APIView

from apps.anime.services.anime_service import AnimeService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class AnimeRestoreView(APIView):

    service = AnimeService()

    def patch(self, request, anime_id):

        anime = self.service.restore(
            request.user,
            anime_id
        )

        if not anime:

            return ErrorResponse(
                message=Messages.ANIME_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )

        return SuccessResponse(
            message=Messages.ANIME_RESTORED,
            status_code=StatusCode.OK
        )