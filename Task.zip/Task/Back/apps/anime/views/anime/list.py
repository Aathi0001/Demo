from rest_framework.views import APIView

from apps.anime.serializers.anime_list_serializer import AnimeListSerializer
from apps.anime.serializers.anime_serializer import AnimeSerializer
from apps.anime.services.anime_service import AnimeService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class AnimeListView(APIView):

    service = AnimeService()

    def post(self, request):

        serializer = AnimeListSerializer(
            data=request.data
        )

        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )

        result = self.service.list(
            request.user,
            serializer.validated_data
        )

        result["results"] = AnimeSerializer(
            result["results"],
            many=True
        ).data

        return SuccessResponse(
            message=Messages.SUCCESS,
            data=result,
            status_code=StatusCode.OK
        )