from rest_framework.views import APIView

from apps.anime.serializers.anime_status_serializer import AnimeStatusSerializer
from apps.anime.services.anime_service import AnimeService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class AnimeStatusCreateView(APIView):

    service = AnimeService()

    def post(self, request):

        serializer = AnimeStatusSerializer(
            data=request.data
        )

        if not serializer.is_valid():
            print(serializer.errors)

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )

        status = self.service.create_status(
            request.user,
            serializer.validated_data
        )

        if status is None:

            return ErrorResponse(
                message=Messages.ANIME_STATUS_ALREADY_EXISTS,
                status_code=StatusCode.BAD_REQUEST
            )

        return SuccessResponse(
            message=Messages.ANIME_STATUS_CREATED,
            data=AnimeStatusSerializer(status).data,
            status_code=StatusCode.CREATED
        )