from rest_framework.views import APIView

from apps.anime.serializers.anime_status_serializer import AnimeStatusSerializer
from apps.anime.services.anime_service import AnimeService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class AnimeStatusUpdateView(APIView):

    service = AnimeService()

    def put(self, request, status_id):

        serializer = AnimeStatusSerializer(
            data=request.data
        )


        if not serializer.is_valid():

            return ErrorResponse(
                message=Messages.VALIDATION_ERROR,
                errors=serializer.errors,
                status_code=StatusCode.BAD_REQUEST
            )

        status = self.service.update_status(
            request.user,
            status_id,
            serializer.validated_data
        )

        if status is False:

            return ErrorResponse(
                message=Messages.ANIME_STATUS_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )


        if status is None:

            return ErrorResponse(
                message=Messages.ANIME_STATUS_ALREADY_EXISTS,
                status_code=StatusCode.BAD_REQUEST
            )

        return SuccessResponse(
            message=Messages.ANIME_STATUS_UPDATED,
            data=AnimeStatusSerializer(status).data,
            status_code=StatusCode.OK
        )