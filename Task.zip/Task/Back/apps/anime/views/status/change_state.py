from rest_framework.views import APIView

from apps.anime.serializers.anime_status_serializer import AnimeStatusSerializer
from apps.anime.services.anime_service import AnimeService

from common.responses import SuccessResponse, ErrorResponse
from common.messages import Messages
from common.status_codes import StatusCode


class AnimeStatusChangeStateView(APIView):

    service = AnimeService()

    def patch(self, request, status_id):

        status = self.service.change_status_state(
            request.user,
            status_id
        )

        if not status:

            return ErrorResponse(
                message=Messages.ANIME_STATUS_NOT_FOUND,
                status_code=StatusCode.NOT_FOUND
            )

        return SuccessResponse(
            message=Messages.ANIME_STATUS_UPDATED,
            data=AnimeStatusSerializer(status).data,
            status_code=StatusCode.OK
        )