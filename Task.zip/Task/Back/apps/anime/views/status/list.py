from rest_framework.views import APIView

from apps.anime.serializers.anime_status_serializer import AnimeStatusSerializer
from apps.anime.services.anime_service import AnimeService

from common.responses import SuccessResponse
from common.messages import Messages
from common.status_codes import StatusCode


class AnimeStatusListView(APIView):

    service = AnimeService()

    def get(self, request):

        status = self.service.list_status(
            request.user
        )

        return SuccessResponse(
            message=Messages.SUCCESS,
            data=AnimeStatusSerializer(
                status,
                many=True
            ).data,
            status_code=StatusCode.OK
        )