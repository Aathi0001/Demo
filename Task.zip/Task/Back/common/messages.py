class Messages:

    # ------------------------
    # Authentication
    # ------------------------

    USER_REGISTERED = "User registered successfully."

    LOGIN_SUCCESS = "Login successful."

    LOGOUT_SUCCESS = "Logout successful."

    TOKEN_REFRESHED = "Token refreshed successfully."

    INVALID_CREDENTIALS = "Invalid username or password."

    INVALID_REFRESH_TOKEN = "Invalid or expired refresh token."

    LOGIN_PASSWORD_CHANGED = "Login password changed successfully."

    # ------------------------
    # Profile
    # ------------------------

    PROFILE_FETCHED = "Profile fetched successfully."

    PROFILE_UPDATED = "Profile updated successfully."

    # ------------------------
    # Security Password
    # ------------------------

    LOCK_PASSWORD_SET = "Lock password set successfully."

    LOCK_PASSWORD_CHANGED = "Lock password changed successfully."

    LOCK_PASSWORD_VERIFIED = "Lock password verified successfully."

    LOCK_PASSWORD_RESET_SCHEDULED = "Lock password reset has been scheduled."

    DELETE_PASSWORD_SET = "Delete password set successfully."

    DELETE_PASSWORD_CHANGED = "Delete password changed successfully."

    DELETE_PASSWORD_VERIFIED = "Delete password verified successfully."

    DELETE_PASSWORD_RESET_SCHEDULED = "Delete password reset has been scheduled."

    PASSWORD_ALREADY_SET = "Password is already set."

    PASSWORD_NOT_SET = "Password is not set."

    PASSWORD_RESET_ALREADY_SCHEDULED = "Password reset has already been scheduled."

    PASSWORD_RESET_PENDING = "Password reset is still pending."

    INVALID_PASSWORD = "Invalid password."

    PASSWORDS_DO_NOT_MATCH = "Passwords do not match."

    # ------------------------
    # Validation
    # ------------------------

    USERNAME_ALREADY_EXISTS = "Username already exists."

    EMAIL_ALREADY_EXISTS = "Email already exists."

    SECURITY_UPDATED = "Security settings updated successfully."

    VALIDATION_ERROR = "Validation failed."

    NOT_FOUND = "Page Not found"

    SUCCESS = "Success"

    ANIME_STATUS_CREATED = "Anime status Creatated"

    ANIME_STATUS_UPDATED = "Anime status updated"

    ANIME_STATUS_NOT_FOUND = "Anime Status not found"


    # ==========================================
    # Worklog Category
    # ==========================================

    WORKLOG_CATEGORY_CREATED = "Worklog category created successfully."

    WORKLOG_CATEGORY_UPDATED = "Worklog category updated successfully."

    WORKLOG_CATEGORY_NOT_FOUND = "Worklog category not found."


    # ==========================================
    # Worklog Project
    # ==========================================

    WORKLOG_PROJECT_CREATED = "Worklog project created successfully."

    WORKLOG_PROJECT_UPDATED = "Worklog project updated successfully."

    WORKLOG_PROJECT_NOT_FOUND = "Worklog project not found."


    # ==========================================
    # Payment Method
    # ==========================================

    PAYMENT_METHOD_CREATED = "Payment method created successfully."

    PAYMENT_METHOD_UPDATED = "Payment method updated successfully."

    PAYMENT_METHOD_NOT_FOUND = "Payment method not found."

    ANIME_STATUS_ALREADY_EXISTS = "Anime status already exists."

    WORKLOG_CATEGORY_ALREADY_EXISTS = "Worklog category already exists."

    WORKLOG_PROJECT_ALREADY_EXISTS = "Worklog project already exists."

    PAYMENT_METHOD_ALREADY_EXISTS = "Payment method already exists."


    # ==========================
    # Anime
    # ==========================

    ANIME_CREATED = "Anime created successfully."

    ANIME_UPDATED = "Anime updated successfully."

    ANIME_DELETED = "Anime deleted permanently."

    ANIME_DELETE_SCHEDULED = "Anime scheduled for deletion."

    ANIME_RESTORED = "Anime restored successfully."

    ANIME_NOT_FOUND = "Anime not found."

    ANIME_ALREADY_EXISTS = "Anime with this name already exists."

    INVALID_DELETE_PASSWORD = "Invalid delete password."

    DELETE_PASSWORD_NOT_AVAILABLE = "Delete password is invalid or not available. Please check your Security settings."

    WORKLOG_CREATED = "Work log created successfully."

    WORKLOG_ALREADY_EXISTS = "A work log with the same details already exists."

    WORKLOG_NOT_FOUND = "Work log not found."

    WORKLOG_RESTORED = "Work log restored successfully."

    WORKLOG_DELETED = "Work log permanently deleted successfully."

    WORKLOG_UPDATED = "Work log updated successfully."

    WORKLOG_DELETE_SCHEDULED = "Work log scheduled for deletion."

    WORKLOG_ALREADY_EXISTS = "A work log with the same details already exists."

    WORKLOG_NOT_FOUND = "Work log not found."

    # ==========================
    # Expense
    # ==========================

    EXPENSE_CREATED = (
        "Expense created successfully."
    )

    EXPENSE_UPDATED = (
        "Expense updated successfully."
    )

    EXPENSE_DELETED = (
        "Expense deleted successfully."
    )

    EXPENSE_RESTORED = (
        "Expense restored successfully."
    )

    EXPENSE_DELETE_SCHEDULED = (
        "Expense scheduled for deletion successfully."
    )

    EXPENSE_ALREADY_EXISTS = (
        "Expense already exists."
    )

    EXPENSE_NOT_FOUND = (
        "Expense not found."
    )

    # ==========================
    # Note
    # ==========================

    NOTE_CREATED = (
        "Note created successfully."
    )

    NOTE_UPDATED = (
        "Note updated successfully."
    )

    NOTE_DELETED = (
        "Note deleted permanently."
    )

    NOTE_RESTORED = (
        "Note restored successfully."
    )

    NOTE_DELETE_SCHEDULED = (
        "Note scheduled for deletion."
    )

    NOTE_ALREADY_EXISTS = (
        "A note with this title already exists."
    )

    NOTE_NOT_FOUND = (
        "Note not found."
    )

    NOTE_UNLOCKED = (
        "Note unlocked successfully."
    )

    NOTE_LOCKED = (
        "This note is locked."
    )

    LOCK_PASSWORD_NOT_AVAILABLE = (
        "Lock password is invalid or not available. Please check your Security settings."
    )

    WORKLOG_TIMELINE_LOADED = "Timeline loaded successfully."

    WORKLOG_TIMELINE_YEARS_LOADED = "Timeline years loaded successfully."