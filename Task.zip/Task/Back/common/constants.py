from datetime import timedelta

DEFAULT_DELETE_AFTER_HOURS = 24

DEFAULT_TIMEZONE = "Asia/Kolkata"

class SecurityConstants:

    LOCK_PASSWORD_RESET_DURATION = timedelta(hours=24)

    DELETE_PASSWORD_RESET_DURATION = timedelta(hours=24)

class PaginationConstants:

    PAGE_SIZE = 20
