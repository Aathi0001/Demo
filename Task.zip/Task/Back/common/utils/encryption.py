from cryptography.fernet import Fernet

from django.conf import settings


cipher = Fernet(
    settings.NOTE_ENCRYPTION_KEY.encode()
)


def encrypt_text(text):

    return cipher.encrypt(

        text.encode()

    ).decode()


def decrypt_text(text):

    return cipher.decrypt(

        text.encode()

    ).decode()