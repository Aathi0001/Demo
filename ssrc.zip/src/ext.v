dependencies {
    // Core Media3 Components
    implementation "androidx.media3:media3-exoplayer:1.3.1"
    implementation "androidx.media3:media3-ui:1.3.1"
    implementation "androidx.media3:media3-common:1.3.1"
    implementation "androidx.media3:media3-extractor:1.3.1"

    // Pre-built FFmpeg software decoder (handles all audio/video codecs device chips lack)
    implementation "org.jellyfin.media3:media3-ffmpeg-decoder:1.3.1+2"
}
