package com.example.videoplayer.config

/**
 * =========================================================================
 * GENERAL CONFIGURATION
 * Contains all static thresholds, buffer limits, gesture sensitivity,
 * playback speed presets, zoom constraints, and screenshot parameters.
 * =========================================================================
 */
object GeneralConfig {

    // =========================================================================
    // 1. MEMORY & LOW-RAM PLAYBACK BUFFER LIMITS (Media3 / ExoPlayer)
    // Optimized for 2GB RAM devices to keep active heap strictly below 100MB.
    // =========================================================================
// Lower time buffers reduce memory pressure on budget devices (2.5s - 10s is ideal)
    const val BUFFER_MIN_MS: Int = 2_500          // 2.5 seconds minimum buffer
    const val BUFFER_MAX_MS: Int = 10_000         // 10 seconds maximum buffer
    const val BUFFER_PLAY_START_MS: Int = 1_000   // Starts playback after 1s buffered
    const val BUFFER_REBUFFER_MS: Int = 2_000     // Buffer after rebuffer: 2s

    // Remove or set to C.LENGTH_UNSET (-1) so ExoPlayer dynamically calculates buffer size based on bitrate
    const val BUFFER_TARGET_SIZE_BYTES: Int = androidx.media3.common.C.LENGTH_UNSET
    // =========================================================================
    // 2. SEEKING & TIMING CONTROLS
    // =========================================================================
    const val DOUBLE_TAP_SEEK_MS: Long = 10_000L   // 10-second skip per double-tap
    const val DEBOUNCE_SEEK_DELAY_MS: Long = 200L  // Throttle time for rapid consecutive taps
    const val CONTROLS_HIDE_TIMEOUT_MS: Long = 3_500L // Auto-hide controls after 3.5s of inactivity

    // =========================================================================
    // 3. GESTURE & TOUCH SENSITIVITIES
    // =========================================================================
    const val SWIPE_SENSITIVITY: Float = 0.005f    // Speed ratio for vertical brightness/volume drag
    const val GESTURE_BORDER_PADDING_PX: Float = 48f // Margin from screen edge to avoid OS gesture conflicts
    const val MIN_PINCH_SCALE: Float = 1.0f        // Default 100% Fit scale
    const val MAX_PINCH_SCALE: Float = 3.0f        // 300% Maximum zoom-in scale

    // =========================================================================
    // 4. PLAYBACK SPEEDS
    // Pitch correction is applied automatically across all presets.
    // =========================================================================
    val PLAYBACK_SPEED_PRESETS: List<Float> = listOf(
        0.5f,
        0.75f,
        1.0f,  // Default normal speed
        1.25f,
        1.5f,
        2.0f
    )
    const val DEFAULT_PLAYBACK_SPEED: Float = 1.0f

    // =========================================================================
    // 5. SCREENSHOT ENGINE CONFIGURATION
    // =========================================================================
    const val SCREENSHOT_QUEUE_CAPACITY: Int = 10   // Max rapid burst shots queued in memory
    const val SCREENSHOT_JPEG_QUALITY: Int = 95      // 95% High quality with zero compression artifacts
    const val SCREENSHOT_FILE_EXTENSION: String = ".jpg"
    const val SCREENSHOT_MIME_TYPE: String = "image/jpeg"
    const val SCREENSHOT_FOLDER_NAME: String = "Captures"

    // =========================================================================
    // 6. RESUME STATE & CACHE POLICIES
    // =========================================================================
    const val RESUME_MAX_ENTRIES: Int = 20          // Retain positions for up to 20 recent videos
    const val RESUME_PURGE_THRESHOLD_RATIO: Float = 0.97f // Delete resume state if video watched >95% (credits)
    const val RESUME_PREFS_NAME: String = "video_player_resume_state"
}
