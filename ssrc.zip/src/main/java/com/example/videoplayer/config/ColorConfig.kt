package com.example.videoplayer.config

/**
 * =========================================================================
 * 1. RAW COLOR PALETTE (Direct 32-bit ARGB Integers)
 * =========================================================================
 */
object RawColors {
    val PureBlack            = 0xFF000000.toInt()
    val PureWhite            = 0xFFFFFFFF.toInt()
    val Transparent          = 0x00000000

    val DarkBackground       = 0xFF121212.toInt()
    val DarkSurface          = 0xFF1E1E1E.toInt()
    val DarkSurfaceVariant   = 0xFF2C2C2C.toInt()
    val DarkBorder           = 0xFF383838.toInt()
    val DarkTextPrimary      = 0xFFEDEDED.toInt()
    val DarkTextSecondary    = 0xFFA0A0A0.toInt()

    val LightBackground      = 0xFFF8F9FA.toInt()
    val LightSurface         = 0xFFFFFFFF.toInt()
    val LightSurfaceVariant  = 0xFFE9ECEF.toInt()
    val LightBorder          = 0xFFDEE2E6.toInt()
    val LightTextPrimary     = 0xFF212529.toInt()
    val LightTextSecondary   = 0xFF6C757D.toInt()

    val OledBackground       = 0xFF000000.toInt()
    val OledSurface          = 0xFF0D0D0D.toInt()
    val OledSurfaceVariant   = 0xFF171717.toInt()
    val OledBorder           = 0xFF262626.toInt()

    val AccentRed            = 0xFFFF5252.toInt()
    val AccentBlue           = 0xFF448AFF.toInt()
    val SuccessGreen         = 0xFF4CAF50.toInt()
    val WarningYellow        = 0xFFFFC107.toInt()
    val ErrorRed             = 0xFFCF6679.toInt()

    val OverlayScrim         = 0x99000000.toInt()
    val OverlayScrimHeavy    = 0xCC000000.toInt()
    val OverlayGestureHud    = 0xB3000000.toInt()
}

/**
 * =========================================================================
 * 2. SEMANTIC COLOR CONTRACT
 * =========================================================================
 */
data class AppColorScheme(
    val backgroundArgb: Int,
    val surfaceArgb: Int,
    val surfaceVariantArgb: Int,
    val borderArgb: Int,
    val textPrimaryArgb: Int,
    val textSecondaryArgb: Int,
    val accentArgb: Int,
    val seekIndicatorArgb: Int,
    val overlayBackgroundArgb: Int,
    val overlayDialogArgb: Int,
    val gestureHudBackgroundArgb: Int,
    val successArgb: Int,
    val errorArgb: Int
)

/**
 * =========================================================================
 * 3. THEME DEFINITIONS
 * =========================================================================
 */
val DarkThemeColors = AppColorScheme(
    backgroundArgb = RawColors.DarkBackground,
    surfaceArgb = RawColors.DarkSurface,
    surfaceVariantArgb = RawColors.DarkSurfaceVariant,
    borderArgb = RawColors.DarkBorder,
    textPrimaryArgb = RawColors.DarkTextPrimary,
    textSecondaryArgb = RawColors.DarkTextSecondary,
    accentArgb = RawColors.AccentRed,
    seekIndicatorArgb = RawColors.AccentBlue,
    overlayBackgroundArgb = RawColors.OverlayScrim,
    overlayDialogArgb = RawColors.OverlayScrimHeavy,
    gestureHudBackgroundArgb = RawColors.OverlayGestureHud,
    successArgb = RawColors.SuccessGreen,
    errorArgb = RawColors.ErrorRed
)

val LightThemeColors = AppColorScheme(
    backgroundArgb = RawColors.LightBackground,
    surfaceArgb = RawColors.LightSurface,
    surfaceVariantArgb = RawColors.LightSurfaceVariant,
    borderArgb = RawColors.LightBorder,
    textPrimaryArgb = RawColors.LightTextPrimary,
    textSecondaryArgb = RawColors.LightTextSecondary,
    accentArgb = RawColors.AccentRed,
    seekIndicatorArgb = RawColors.AccentBlue,
    overlayBackgroundArgb = RawColors.OverlayScrim,
    overlayDialogArgb = RawColors.OverlayScrimHeavy,
    gestureHudBackgroundArgb = RawColors.OverlayGestureHud,
    successArgb = RawColors.SuccessGreen,
    errorArgb = RawColors.ErrorRed
)

val OledBlackThemeColors = AppColorScheme(
    backgroundArgb = RawColors.OledBackground,
    surfaceArgb = RawColors.OledSurface,
    surfaceVariantArgb = RawColors.OledSurfaceVariant,
    borderArgb = RawColors.OledBorder,
    textPrimaryArgb = RawColors.PureWhite,
    textSecondaryArgb = RawColors.DarkTextSecondary,
    accentArgb = RawColors.AccentRed,
    seekIndicatorArgb = RawColors.AccentBlue,
    overlayBackgroundArgb = RawColors.OverlayScrimHeavy,
    overlayDialogArgb = RawColors.OverlayScrimHeavy,
    gestureHudBackgroundArgb = RawColors.OverlayGestureHud,
    successArgb = RawColors.SuccessGreen,
    errorArgb = RawColors.ErrorRed
)

/**
 * =========================================================================
 * 4. THEME CONTROLLER & REGISTRY
 * =========================================================================
 */
enum class ThemeMode {
    DARK,
    LIGHT,
    OLED_BLACK
}

object ThemeManager {
    private val themeRegistry: Map<ThemeMode, AppColorScheme> = mapOf(
        ThemeMode.DARK to DarkThemeColors,
        ThemeMode.LIGHT to LightThemeColors,
        ThemeMode.OLED_BLACK to OledBlackThemeColors
    )

    var currentMode: ThemeMode = ThemeMode.DARK

    val colors: AppColorScheme
        get() = themeRegistry[currentMode] ?: DarkThemeColors
}
