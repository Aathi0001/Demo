package com.example.videoplayer.player

import androidx.media3.common.C
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.upstream.DefaultAllocator
import com.example.videoplayer.config.GeneralConfig

/**
 * =========================================================================
 * OBJECT: LowRamLoadControl
 * Description: Factory producing a Media3 DefaultLoadControl tailored strictly
 *              for low-RAM hardware (2GB+ target). Uses dynamic time-based
 *              thresholds to maintain low memory pressure without choking
 *              high-bitrate HEVC decoders.
 * =========================================================================
 */
object LowRamLoadControl {

    /**
     * Builds a DefaultLoadControl instance with customized buffer durations.
     */
    fun create(): DefaultLoadControl {
        // Individual 64KB memory chunk allocator
        val allocator = DefaultAllocator(true, C.DEFAULT_BUFFER_SEGMENT_SIZE)

        val builder = DefaultLoadControl.Builder()
            .setAllocator(allocator)
            .setBufferDurationsMs(
                GeneralConfig.BUFFER_MIN_MS,
                GeneralConfig.BUFFER_MAX_MS,
                GeneralConfig.BUFFER_PLAY_START_MS,
                GeneralConfig.BUFFER_REBUFFER_MS
            )
            .setPrioritizeTimeOverSizeThresholds(true)

        // Only enforce a byte limit if it is explicitly set (not C.LENGTH_UNSET)
        if (GeneralConfig.BUFFER_TARGET_SIZE_BYTES != C.LENGTH_UNSET) {
            builder.setTargetBufferBytes(GeneralConfig.BUFFER_TARGET_SIZE_BYTES)
        }

        return builder.build()
    }
}