package com.example.videoplayer.player

import android.content.Context
import android.view.LayoutInflater
import android.widget.RadioButton
import android.widget.RadioGroup
import com.example.videoplayer.R
import com.example.videoplayer.data.local.AppPreferences
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.switchmaterial.SwitchMaterial

object SettingsHelper {

    fun showSettingsDialog(
        context: Context,
        appPreferences: AppPreferences,
        onSettingsUpdated: () -> Unit
    ) {
        val dialog = BottomSheetDialog(context)
        val view = LayoutInflater.from(context).inflate(R.layout.bottom_sheet_settings, null)
        dialog.setContentView(view)

        // Find Switches
        val switchSwipeScreenshot = view.findViewById<SwitchMaterial>(R.id.switchSwipeScreenshot)
        val switchBrightness = view.findViewById<SwitchMaterial>(R.id.switchBrightness)
        val switchVolume = view.findViewById<SwitchMaterial>(R.id.switchVolume)
        val switchScrubbing = view.findViewById<SwitchMaterial>(R.id.switchScrubbing)
        val switchDoubleTapSeek = view.findViewById<SwitchMaterial>(R.id.switchDoubleTapSeek)
        val switchShowScreenshotBtn = view.findViewById<SwitchMaterial>(R.id.switchShowScreenshotBtn)
        val switchShowSpeedBtn = view.findViewById<SwitchMaterial>(R.id.switchShowSpeedBtn)

        // Find RadioGroup for Seek Duration
        val rgSeekDuration = view.findViewById<RadioGroup>(R.id.rgSeekDuration)

        // Initialize state from AppPreferences
        switchSwipeScreenshot.isChecked = appPreferences.isSwipeScreenshotEnabled
        switchBrightness.isChecked = appPreferences.isBrightnessGestureEnabled
        switchVolume.isChecked = appPreferences.isVolumeGestureEnabled
        switchScrubbing.isChecked = appPreferences.isHorizontalScrubEnabled
        switchDoubleTapSeek.isChecked = appPreferences.isDoubleTapSeekEnabled
        switchShowScreenshotBtn.isChecked = appPreferences.showScreenshotButton
        switchShowSpeedBtn.isChecked = appPreferences.showSpeedButton

        when (appPreferences.doubleTapSeekSeconds) {
            5 -> view.findViewById<RadioButton>(R.id.rbSeek5).isChecked = true
            15 -> view.findViewById<RadioButton>(R.id.rbSeek15).isChecked = true
            30 -> view.findViewById<RadioButton>(R.id.rbSeek30).isChecked = true
            else -> view.findViewById<RadioButton>(R.id.rbSeek10).isChecked = true
        }

        // Listeners for switches
        switchSwipeScreenshot.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isSwipeScreenshotEnabled = isChecked
            onSettingsUpdated()
        }

        switchBrightness.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isBrightnessGestureEnabled = isChecked
            onSettingsUpdated()
        }

        switchVolume.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isVolumeGestureEnabled = isChecked
            onSettingsUpdated()
        }

        switchScrubbing.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isHorizontalScrubEnabled = isChecked
            onSettingsUpdated()
        }

        switchDoubleTapSeek.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isDoubleTapSeekEnabled = isChecked
            onSettingsUpdated()
        }

        switchShowScreenshotBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showScreenshotButton = isChecked
            onSettingsUpdated()
        }

        switchShowSpeedBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showSpeedButton = isChecked
            onSettingsUpdated()
        }

        // Listener for Seek Duration
        rgSeekDuration.setOnCheckedChangeListener { _, checkedId ->
            val seconds = when (checkedId) {
                R.id.rbSeek5 -> 5
                R.id.rbSeek15 -> 15
                R.id.rbSeek30 -> 30
                else -> 10
            }
            appPreferences.doubleTapSeekSeconds = seconds
            onSettingsUpdated()
        }

        dialog.show()
    }
}
