package com.example.videoplayer.ui.filepicker

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.videoplayer.config.ThemeManager
import com.example.videoplayer.config.textPrimaryArgb
import com.example.videoplayer.config.textSecondaryArgb
import com.example.videoplayer.data.model.FolderItem
import com.example.videoplayer.data.model.VideoItem
import com.example.videoplayer.utils.GeneralFunc

/**
 * =========================================================================
 * CLASS: VideoPickerAdapter
 * Description: RecyclerView adapter rendering folders or video items.
 * =========================================================================
 */
class VideoPickerAdapter(
    private val onFolderClick: (FolderItem) -> Unit,
    private val onVideoClick: (VideoItem) -> Unit
) : RecyclerView.Adapter<VideoPickerAdapter.ViewHolder>() {

    private var folderList: List<FolderItem> = emptyList()
    private var videoList: List<VideoItem> = emptyList()
    private var isFolderView = true

    fun setFolders(folders: List<FolderItem>) {
        isFolderView = true
        folderList = folders
        videoList = emptyList()
        notifyDataSetChanged()
    }

    fun setVideos(videos: List<VideoItem>) {
        isFolderView = false
        videoList = videos
        folderList = emptyList()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(android.R.layout.simple_list_item_2, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val colors = ThemeManager.colors

        if (isFolderView) {
            val folder = folderList[position]
            holder.text1.text = "📁 ${folder.folderName}"
            holder.text2.text = "${folder.videoCount} videos"
            holder.itemView.setOnClickListener { onFolderClick(folder) }
        } else {
            val video = videoList[position]
            holder.text1.text = "🎬 ${video.title}"
            holder.text2.text = GeneralFunc.formatDurationToTime(video.durationMs)
            holder.itemView.setOnClickListener { onVideoClick(video) }
        }

        // Dynamically match the current active theme
        holder.text1.setTextColor(colors.textPrimaryArgb)
        holder.text2.setTextColor(colors.textSecondaryArgb)
    }

    override fun getItemCount(): Int = if (isFolderView) folderList.size else videoList.size

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val text1: TextView = view.findViewById(android.R.id.text1)
        val text2: TextView = view.findViewById(android.R.id.text2)
    }
}