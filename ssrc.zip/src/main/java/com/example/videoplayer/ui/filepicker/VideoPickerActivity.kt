package com.example.videoplayer.ui.filepicker

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.videoplayer.R
import com.example.videoplayer.config.ThemeManager
import com.example.videoplayer.config.ThemeMode
import com.example.videoplayer.config.backgroundArgb
import com.example.videoplayer.config.textPrimaryArgb
import com.example.videoplayer.config.textSecondaryArgb
import com.example.videoplayer.data.local.AppPreferences
import com.example.videoplayer.data.model.FolderItem
import com.example.videoplayer.data.repository.VideoRepository
import com.example.videoplayer.player.SettingsHelper
import com.example.videoplayer.ui.player.PlayerActivity
import kotlinx.coroutines.launch

class VideoPickerActivity : AppCompatActivity() {

    private lateinit var repo: VideoRepository
    private lateinit var adapter: VideoPickerAdapter
    private lateinit var appPreferences: AppPreferences
    private lateinit var rootLayout: View
    private lateinit var tvHeaderTitle: TextView
    private lateinit var btnToggleTheme: ImageButton
    private lateinit var btnSettings: ImageButton
    private lateinit var tvEmptyState: TextView
    private var currentFolder: FolderItem? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video_picker)

        appPreferences = AppPreferences(this)
        repo = VideoRepository(this)
        rootLayout = findViewById(R.id.rootPickerLayout)
        tvHeaderTitle = findViewById(R.id.tvHeaderTitle)
        btnToggleTheme = findViewById(R.id.btnToggleTheme)
        btnSettings = findViewById(R.id.btnSettings)
        tvEmptyState = findViewById(R.id.tvEmptyState)

        val rv = findViewById<RecyclerView>(R.id.rvMediaList)
        rv.layoutManager = LinearLayoutManager(this)

        adapter = VideoPickerAdapter(
            onFolderClick = { folder ->
                currentFolder = folder
                tvHeaderTitle.text = folder.folderName
                loadVideosInFolder(folder.folderPath)
            },
            onVideoClick = { video ->
                val intent = Intent(this, PlayerActivity::class.java).apply {
                    data = video.uri
                    putExtra("VIDEO_TITLE", video.title)
                    putExtra("FOLDER_PATH", video.folderPath)
                }
                startActivity(intent)
            }
        )
        rv.adapter = adapter

        // Theme toggle button action: DARK -> LIGHT -> OLED_BLACK -> DARK
        btnToggleTheme.setOnClickListener {
            ThemeManager.currentMode = when (ThemeManager.currentMode) {
                ThemeMode.DARK -> ThemeMode.LIGHT
                ThemeMode.LIGHT -> ThemeMode.OLED_BLACK
                ThemeMode.OLED_BLACK -> ThemeMode.DARK
            }
            applyThemeColors()
            adapter.notifyDataSetChanged()
        }

        // Settings button action: opens unified player/gesture settings bottom sheet
        btnSettings.setOnClickListener {
            SettingsHelper.showSettingsDialog(this, appPreferences) {
                // UI updates if needed
            }
        }

        // Modern Back Press Callback
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (currentFolder != null) {
                    currentFolder = null
                    loadFolders()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        applyThemeColors()
        checkPermissionsAndLoad()
    }

    private fun applyThemeColors() {
        val colors = ThemeManager.colors
        rootLayout.setBackgroundColor(colors.backgroundArgb)
        tvHeaderTitle.setTextColor(colors.textPrimaryArgb)
        btnToggleTheme.setColorFilter(colors.textPrimaryArgb)
        btnSettings.setColorFilter(colors.textPrimaryArgb)
        tvEmptyState.setTextColor(colors.textSecondaryArgb)
    }

    private fun checkPermissionsAndLoad() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_VIDEO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            loadFolders()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(permission), 101)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            loadFolders()
        } else {
            Toast.makeText(this, "Permission required to load videos", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadFolders() {
        lifecycleScope.launch {
            val folders = repo.getAllFoldersWithVideos()
            tvHeaderTitle.text = "Video Folders"
            tvEmptyState.visibility = if (folders.isEmpty()) View.VISIBLE else View.GONE
            adapter.setFolders(folders)
        }
    }

    private fun loadVideosInFolder(folderPath: String) {
        lifecycleScope.launch {
            val videos = repo.getVideosInFolder(folderPath)
            tvEmptyState.visibility = if (videos.isEmpty()) View.VISIBLE else View.GONE
            adapter.setVideos(videos)
        }
    }
}
