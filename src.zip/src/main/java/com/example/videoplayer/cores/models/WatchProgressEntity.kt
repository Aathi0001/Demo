package com.example.videoplayer.cores.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.videoplayer.configs.QueryConfig

/**
 * =========================================================================
 * DATA CLASS: WatchProgressEntity
 * PACKAGE: com.example.videoplayer.cores.models
 * DESCRIPTION: Tracks video playback timestamps, completion tick (✓),
 *              and last watched time keyed uniquely by the file path in Room.
 * =========================================================================
 */
@Entity(tableName = QueryConfig.TABLE_WATCH_PROGRESS)
data class WatchProgressEntity(
    @PrimaryKey
    @ColumnInfo(name = "video_path")
    val videoPath: String,

    @ColumnInfo(name = "last_position_ms")
    val lastPositionMs: Long,

    @ColumnInfo(name = "duration_ms")
    val durationMs: Long,

    @ColumnInfo(name = "is_completed")
    val isCompleted: Boolean,

    @ColumnInfo(name = "last_watched_at")
    val lastWatchedAt: Long = System.currentTimeMillis()
)