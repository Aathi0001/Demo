package com.example.videoplayer.cores.player

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.core.widget.CompoundButtonCompat
import androidx.media3.common.C
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.exoplayer.ExoPlayer
import com.example.videoplayer.R
import com.example.videoplayer.configs.ThemeManager
import com.example.videoplayer.ui.screens.SyncAdjustmentDialog
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.tabs.TabLayout
import org.videolan.libvlc.MediaPlayer

/**
 * =========================================================================
 * OBJECT: TrackSelectionHelper
 * PACKAGE: com.example.videoplayer.cores.player
 * DESCRIPTION: Unified track selection bottom sheet managing Audio, Subtitle,
 *              and Video streams with instant full expansion and cleaner action pills.
 * =========================================================================
 */
object TrackSelectionHelper {

    /**
     * -------------------------------------------------------------------------
     * Function: showUnifiedTrackSelector
     * Description: Displays track selection dialog for the active engine.
     * Input: context (Context), playerEngine (PlayerEngine),
     *        onPickExternalSubtitle (() -> Unit)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun showUnifiedTrackSelector(
        context: Context,
        playerEngine: PlayerEngine,
        onPickExternalSubtitle: () -> Unit
    ) {
        val dialog = BottomSheetDialog(context)
        val view = LayoutInflater.from(context).inflate(R.layout.bottom_sheet_tracks_unified, null)

        val tabLayout = view.findViewById<TabLayout>(R.id.tabLayoutTracks)
        val rgTracks = view.findViewById<RadioGroup>(R.id.rgUnifiedTracks)
        val layoutSubtitleActions = view.findViewById<LinearLayout>(R.id.layoutSubtitleActions)
        val btnPickSubtitleFile = view.findViewById<Button>(R.id.btnPickSubtitleFile)
        val btnAdjustSync = view.findViewById<Button>(R.id.btnAdjustSync)

        tabLayout.addTab(tabLayout.newTab().setText("Audio"))
        tabLayout.addTab(tabLayout.newTab().setText("Subtitles"))
        tabLayout.addTab(tabLayout.newTab().setText("Video"))

        btnPickSubtitleFile.setOnClickListener {
            dialog.dismiss()
            onPickExternalSubtitle()
        }

        btnAdjustSync.setOnClickListener {
            dialog.dismiss()
            SyncAdjustmentDialog.show(context, playerEngine) {}
        }

        fun renderTracksForType(trackType: Int) {
            rgTracks.removeAllViews()

            layoutSubtitleActions.visibility = if (trackType == C.TRACK_TYPE_TEXT) View.VISIBLE else View.GONE

            when (playerEngine.activeEngine) {
                ActiveEngine.EXO_PLAYER -> {
                    val player = playerEngine.exoPlayer ?: return
                    renderExoTracks(context, player, trackType, rgTracks, dialog)
                }
                ActiveEngine.LIB_VLC -> {
                    val vlcPlayer = playerEngine.vlcMediaPlayer ?: return
                    renderVlcTracks(context, vlcPlayer, trackType, rgTracks, dialog)
                }
            }
        }

        renderTracksForType(C.TRACK_TYPE_AUDIO)

        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> renderTracksForType(C.TRACK_TYPE_AUDIO)
                    1 -> renderTracksForType(C.TRACK_TYPE_TEXT)
                    2 -> renderTracksForType(C.TRACK_TYPE_VIDEO)
                }
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        dialog.setContentView(view)

        // Force bottom sheet to open at 75% height without manual swipe-up
        dialog.setOnShowListener {
            val bottomSheet = dialog.findViewById<FrameLayout>(com.google.android.material.R.id.design_bottom_sheet)
            bottomSheet?.let { sheet ->
                val behavior = BottomSheetBehavior.from(sheet)
                val displayMetrics = context.resources.displayMetrics
                val targetHeight = (displayMetrics.heightPixels * 0.75).toInt()
                sheet.layoutParams.height = targetHeight
                behavior.peekHeight = targetHeight
                behavior.state = BottomSheetBehavior.STATE_EXPANDED
                behavior.skipCollapsed = true
            }
        }

        dialog.show()
    }

    private fun renderExoTracks(
        context: Context,
        player: ExoPlayer,
        trackType: Int,
        rgTracks: RadioGroup,
        dialog: BottomSheetDialog
    ) {
        val tracks = player.currentTracks

        if (trackType == C.TRACK_TYPE_TEXT) {
            val isTextDisabled = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
            val rbOff = createCompactRadioButton(context, "Disable Subtitles", isTextDisabled)
            rbOff.setOnClickListener {
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    .build()
                dialog.dismiss()
            }
            rgTracks.addView(rbOff)
        }

        val trackList = mutableListOf<Triple<TrackGroup, Int, Boolean>>()

        for (group in tracks.groups) {
            if (group.type == trackType) {
                val mediaTrackGroup = group.mediaTrackGroup
                for (i in 0 until mediaTrackGroup.length) {
                    val isSelected = group.isTrackSelected(i)
                    trackList.add(Triple(mediaTrackGroup, i, isSelected))
                }
            }
        }

        if (trackList.isEmpty() && trackType != C.TRACK_TYPE_TEXT) {
            val rbEmpty = createCompactRadioButton(context, "No tracks found", false).apply {
                isEnabled = false
            }
            rgTracks.addView(rbEmpty)
            return
        }

        trackList.forEachIndexed { index, (group, trackIndex, isSelected) ->
            val format = group.getFormat(trackIndex)
            val label = buildString {
                append(format.label ?: format.language?.uppercase() ?: "Track ${index + 1}")
                if (format.bitrate > 0) append(" • ${format.bitrate / 1000} kbps")
                if (format.width > 0 && format.height > 0) append(" • ${format.width}x${format.height}")
            }

            val rb = createCompactRadioButton(context, label, isSelected)
            rb.setOnClickListener {
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(trackType, false)
                    .setOverrideForType(TrackSelectionOverride(group, trackIndex))
                    .build()
                dialog.dismiss()
            }
            rgTracks.addView(rb)
        }
    }

    private fun renderVlcTracks(
        context: Context,
        vlcPlayer: MediaPlayer,
        trackType: Int,
        rgTracks: RadioGroup,
        dialog: BottomSheetDialog
    ) {
        val tracks = when (trackType) {
            C.TRACK_TYPE_AUDIO -> vlcPlayer.audioTracks
            C.TRACK_TYPE_TEXT -> vlcPlayer.spuTracks
            else -> vlcPlayer.videoTracks
        }

        val currentTrackId = when (trackType) {
            C.TRACK_TYPE_AUDIO -> vlcPlayer.audioTrack
            C.TRACK_TYPE_TEXT -> vlcPlayer.spuTrack
            else -> vlcPlayer.videoTrack
        }

        if (trackType == C.TRACK_TYPE_TEXT) {
            val isOffSelected = currentTrackId == -1
            val rbOff = createCompactRadioButton(context, "Disable Subtitles", isOffSelected)
            rbOff.setOnClickListener {
                vlcPlayer.setSpuTrack(-1)
                dialog.dismiss()
            }
            rgTracks.addView(rbOff)
        }

        if (tracks.isNullOrEmpty() && trackType != C.TRACK_TYPE_TEXT) {
            val rbEmpty = createCompactRadioButton(context, "No tracks found", false).apply {
                isEnabled = false
            }
            rgTracks.addView(rbEmpty)
            return
        }

        tracks?.forEachIndexed { _, track ->
            val isSelected = track.id == currentTrackId
            val label = if (track.name.isNullOrBlank()) "Track #${track.id}" else track.name

            val rb = createCompactRadioButton(context, label, isSelected)
            rb.setOnClickListener {
                when (trackType) {
                    C.TRACK_TYPE_AUDIO -> vlcPlayer.setAudioTrack(track.id)
                    C.TRACK_TYPE_TEXT -> vlcPlayer.setSpuTrack(track.id)
                    C.TRACK_TYPE_VIDEO -> vlcPlayer.setVideoTrack(track.id)
                }
                dialog.dismiss()
            }
            rgTracks.addView(rb)
        }
    }

    private fun createCompactRadioButton(context: Context, label: String, isChecked: Boolean): RadioButton {
        return RadioButton(context).apply {
            text = label
            this.isChecked = isChecked
            textSize = 14spToFloat()
            setTextColor(if (isChecked) ThemeManager.colors.accentArgb else Color.parseColor("#EDEDED"))
            setPadding(16, 14, 16, 14)
            layoutParams = RadioGroup.LayoutParams(
                RadioGroup.LayoutParams.MATCH_PARENT,
                RadioGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 4, 0, 4)
            }

            val colorStateList = ColorStateList(
                arrayOf(
                    intArrayOf(android.R.attr.state_checked),
                    intArrayOf(-android.R.attr.state_checked)
                ),
                intArrayOf(
                    ThemeManager.colors.accentArgb,
                    Color.parseColor("#666666")
                )
            )
            CompoundButtonCompat.setButtonTintList(this, colorStateList)
        }
    }

    private fun RadioButton.spToFloat(): Float = 14f
}