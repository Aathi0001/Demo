package com.example.videoplayer.cores.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.videoplayer.configs.QueryConfig
import com.example.videoplayer.cores.models.FolderSortEntity
import com.example.videoplayer.cores.models.WatchProgressEntity

/**
 * =========================================================================
 * INTERFACE: AppDatabaseDao
 * PACKAGE: com.example.videoplayer.cores.db
 * DESCRIPTION: Direct database access interface executing persistent queries
 *              and record mutations defined in QueryConfig.
 * =========================================================================
 */
@Dao
interface AppDatabaseDao {

    /**
     * -------------------------------------------------------------------------
     * Function: upsertWatchProgress
     * Description: Inserts or updates the playback progress record for a video.
     * Input: progress (WatchProgressEntity)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWatchProgress(progress: WatchProgressEntity)

    /**
     * -------------------------------------------------------------------------
     * Function: getWatchProgress
     * Description: Fetches the stored playback progress for a given video path.
     * Input: path (String)
     * Output: WatchProgressEntity? (null if never watched)
     * -------------------------------------------------------------------------
     */
    @Query(QueryConfig.GET_WATCH_PROGRESS_BY_PATH)
    suspend fun getWatchProgress(path: String): WatchProgressEntity?

    /**
     * -------------------------------------------------------------------------
     * Function: getAllWatchProgress
     * Description: Retrieves all stored playback records for initial cache preloading.
     * Input: None
     * Output: List<WatchProgressEntity>
     * -------------------------------------------------------------------------
     */
    @Query(QueryConfig.GET_ALL_WATCH_PROGRESS)
    suspend fun getAllWatchProgress(): List<WatchProgressEntity>

    /**
     * -------------------------------------------------------------------------
     * Function: deleteWatchProgress
     * Description: Removes the playback progress record for a specified video path.
     * Input: path (String)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    @Query(QueryConfig.DELETE_WATCH_PROGRESS_BY_PATH)
    suspend fun deleteWatchProgress(path: String)

    /**
     * -------------------------------------------------------------------------
     * Function: pruneWatchProgress
     * Description: Deletes older playback records exceeding the top 1000 limit.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    @Query(QueryConfig.PRUNE_WATCH_PROGRESS)
    suspend fun pruneWatchProgress()

    /**
     * -------------------------------------------------------------------------
     * Function: upsertFolderSort
     * Description: Inserts or updates the custom sort mode assigned to a folder.
     * Input: folderSort (FolderSortEntity)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertFolderSort(folderSort: FolderSortEntity)

    /**
     * -------------------------------------------------------------------------
     * Function: getFolderSort
     * Description: Fetches the custom sort mode integer for a folder path.
     * Input: folderPath (String)
     * Output: Int? (null if folder has no explicit override)
     * -------------------------------------------------------------------------
     */
    @Query(QueryConfig.GET_FOLDER_SORT)
    suspend fun getFolderSort(folderPath: String): Int?

    /**
     * -------------------------------------------------------------------------
     * Function: deleteFolderSort
     * Description: Clears custom sort override for a specific folder path.
     * Input: folderPath (String)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    @Query(QueryConfig.DELETE_FOLDER_SORT)
    suspend fun deleteFolderSort(folderPath: String)

    /**
     * -------------------------------------------------------------------------
     * Function: pruneFolderSorts
     * Description: Clears old folder sort entries exceeding the top 500 limit.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    @Query(QueryConfig.PRUNE_FOLDER_SORTS)
    suspend fun pruneFolderSorts()
}