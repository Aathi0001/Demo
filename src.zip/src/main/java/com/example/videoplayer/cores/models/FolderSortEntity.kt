package com.example.videoplayer.cores.models

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.videoplayer.configs.QueryConfig

/**
 * =========================================================================
 * DATA CLASS: FolderSortEntity
 * PACKAGE: com.example.videoplayer.cores.models
 * DESCRIPTION: Stores custom sort mode choice keyed by the directory path in Room.
 * =========================================================================
 */
@Entity(tableName = QueryConfig.TABLE_FOLDER_SORT)
data class FolderSortEntity(
    @PrimaryKey
    @ColumnInfo(name = "folder_path")
    val folderPath: String,

    @ColumnInfo(name = "sort_mode")
    val sortMode: Int,

    @ColumnInfo(name = "updated_at")
    val updatedAt: Long = System.currentTimeMillis()
)