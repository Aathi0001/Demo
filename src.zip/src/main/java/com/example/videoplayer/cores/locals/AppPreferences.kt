package com.example.videoplayer.cores.locals

import android.content.Context
import android.content.SharedPreferences

/**
 * =========================================================================
 * CLASS: AppPreferences
 * PACKAGE: com.example.videoplayer.cores.locals
 * DESCRIPTION: Wraps SharedPreferences for persistent UI settings, button
 *              visibility, normal gesture flags, and lock-screen allowances.
 * =========================================================================
 */
class AppPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("video_player_user_prefs", Context.MODE_PRIVATE)

    companion object {
        // Base Gestures
        private const val KEY_SWIPE_SCREENSHOT_ENABLED = "key_swipe_screenshot_enabled"
        private const val KEY_VOLUME_GESTURE_ENABLED = "key_volume_gesture_enabled"
        private const val KEY_BRIGHTNESS_GESTURE_ENABLED = "key_brightness_gesture_enabled"
        private const val KEY_DOUBLE_TAP_SEEK_ENABLED = "key_double_tap_seek_enabled"
        private const val KEY_HORIZONTAL_SCRUB_ENABLED = "key_horizontal_scrub_enabled"
        private const val KEY_SEEK_SECONDS = "key_seek_seconds"

        // Playback Behavior
        private const val KEY_AUTO_PLAY_NEXT = "key_auto_play_next"
        private const val KEY_BACKGROUND_AUDIO_ENABLED = "key_background_audio_enabled"

        // UI Button Visibility
        private const val KEY_SHOW_NEXT_PREV_BUTTONS = "key_show_next_prev_buttons"
        private const val KEY_SHOW_SCREENSHOT_BUTTON = "key_show_screenshot_button"
        private const val KEY_SHOW_ASPECT_RATIO_BUTTON = "key_show_aspect_ratio_button"
        private const val KEY_SHOW_SPEED_BUTTON = "key_show_speed_button"
        private const val KEY_SHOW_ORIENTATION_BUTTON = "key_show_orientation_button"
        private const val KEY_SHOW_PIP_BUTTON = "key_show_pip_button"
        private const val KEY_SHOW_DECODER_TOGGLE_BUTTON = "key_show_decoder_toggle_button"
        private const val KEY_SHOW_BACKGROUND_AUDIO_BUTTON = "key_show_background_audio_button"
        private const val KEY_SHOW_TRACKS_BUTTON = "key_show_tracks_button"
        private const val KEY_SHOW_LOCK_BUTTON = "key_show_lock_button"

        // New Advanced Gestures (Normal Mode)
        private const val KEY_LONG_PRESS_2X_ENABLED = "key_long_press_2x_enabled"
        private const val KEY_TWO_FINGER_SWIPE_TRACKS = "key_two_finger_swipe_tracks"
        private const val KEY_TWO_FINGER_LOCK_TOGGLE = "key_two_finger_lock_toggle"
        private const val KEY_SPEED_DRAG_LOCK_ENABLED = "key_speed_drag_lock_enabled"

        // Lock Screen Allowances (Actions permitted while isLocked == true)
        private const val KEY_LOCK_ALLOW_VOLUME = "key_lock_allow_volume"
        private const val KEY_LOCK_ALLOW_BRIGHTNESS = "key_lock_allow_brightness"
        private const val KEY_LOCK_ALLOW_SEEK = "key_lock_allow_seek"
        private const val KEY_LOCK_ALLOW_SCREENSHOT = "key_lock_allow_screenshot"
        private const val KEY_LOCK_ALLOW_ZOOM = "key_lock_allow_zoom"
        private const val KEY_LOCK_ALLOW_LONG_PRESS_2X = "key_lock_allow_long_press_2x"
        private const val KEY_LOCK_ALLOW_TWO_FINGER_TRACKS = "key_lock_allow_two_finger_tracks"
        private const val KEY_LOCK_ALLOW_TWO_FINGER_UNLOCK = "key_lock_allow_two_finger_unlock"
        private const val KEY_LOCK_ALLOW_SPEED_DRAG_LOCK = "key_lock_allow_speed_drag_lock"
    }

    // --- Base Gestures ---

    var isSwipeScreenshotEnabled: Boolean
        get() = prefs.getBoolean(KEY_SWIPE_SCREENSHOT_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_SWIPE_SCREENSHOT_ENABLED, value).apply()

    var isVolumeGestureEnabled: Boolean
        get() = prefs.getBoolean(KEY_VOLUME_GESTURE_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_VOLUME_GESTURE_ENABLED, value).apply()

    var isBrightnessGestureEnabled: Boolean
        get() = prefs.getBoolean(KEY_BRIGHTNESS_GESTURE_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_BRIGHTNESS_GESTURE_ENABLED, value).apply()

    var isDoubleTapSeekEnabled: Boolean
        get() = prefs.getBoolean(KEY_DOUBLE_TAP_SEEK_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_DOUBLE_TAP_SEEK_ENABLED, value).apply()

    var isHorizontalScrubEnabled: Boolean
        get() = prefs.getBoolean(KEY_HORIZONTAL_SCRUB_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_HORIZONTAL_SCRUB_ENABLED, value).apply()

    var doubleTapSeekSeconds: Int
        get() = prefs.getInt(KEY_SEEK_SECONDS, 10)
        set(value) = prefs.edit().putInt(KEY_SEEK_SECONDS, value).apply()

    // --- Playback Behavior ---

    var isAutoPlayNextEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTO_PLAY_NEXT, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_PLAY_NEXT, value).apply()

    var isBackgroundAudioEnabled: Boolean
        get() = prefs.getBoolean(KEY_BACKGROUND_AUDIO_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_BACKGROUND_AUDIO_ENABLED, value).apply()

    // --- UI Control Visibility ---

    var showNextPrevButtons: Boolean
        get() = prefs.getBoolean(KEY_SHOW_NEXT_PREV_BUTTONS, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_NEXT_PREV_BUTTONS, value).apply()

    var showScreenshotButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_SCREENSHOT_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_SCREENSHOT_BUTTON, value).apply()

    var showAspectRatioButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_ASPECT_RATIO_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_ASPECT_RATIO_BUTTON, value).apply()

    var showSpeedButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_SPEED_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_SPEED_BUTTON, value).apply()

    var showOrientationButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_ORIENTATION_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_ORIENTATION_BUTTON, value).apply()

    var showPipButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_PIP_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_PIP_BUTTON, value).apply()

    var showDecoderToggleButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_DECODER_TOGGLE_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_DECODER_TOGGLE_BUTTON, value).apply()

    var showBackgroundAudioButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_BACKGROUND_AUDIO_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_BACKGROUND_AUDIO_BUTTON, value).apply()

    var showTracksButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_TRACKS_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_TRACKS_BUTTON, value).apply()

    var showLockButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_LOCK_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_LOCK_BUTTON, value).apply()

    // --- New Advanced Gestures (Normal Mode) ---

    var isLongPress2xEnabled: Boolean
        get() = prefs.getBoolean(KEY_LONG_PRESS_2X_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_LONG_PRESS_2X_ENABLED, value).apply()

    var isTwoFingerSwipeTracksEnabled: Boolean
        get() = prefs.getBoolean(KEY_TWO_FINGER_SWIPE_TRACKS, true)
        set(value) = prefs.edit().putBoolean(KEY_TWO_FINGER_SWIPE_TRACKS, value).apply()

    var isTwoFingerLockToggleEnabled: Boolean
        get() = prefs.getBoolean(KEY_TWO_FINGER_LOCK_TOGGLE, true)
        set(value) = prefs.edit().putBoolean(KEY_TWO_FINGER_LOCK_TOGGLE, value).apply()

    var isSpeedDragLockEnabled: Boolean
        get() = prefs.getBoolean(KEY_SPEED_DRAG_LOCK_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_SPEED_DRAG_LOCK_ENABLED, value).apply()

    // --- Lock Screen Active Allowances ---

    var lockAllowVolume: Boolean
        get() = prefs.getBoolean(KEY_LOCK_ALLOW_VOLUME, false)
        set(value) = prefs.edit().putBoolean(KEY_LOCK_ALLOW_VOLUME, value).apply()

    var lockAllowBrightness: Boolean
        get() = prefs.getBoolean(KEY_LOCK_ALLOW_BRIGHTNESS, false)
        set(value) = prefs.edit().putBoolean(KEY_LOCK_ALLOW_BRIGHTNESS, value).apply()

    var lockAllowSeek: Boolean
        get() = prefs.getBoolean(KEY_LOCK_ALLOW_SEEK, false)
        set(value) = prefs.edit().putBoolean(KEY_LOCK_ALLOW_SEEK, value).apply()

    var lockAllowScreenshot: Boolean
        get() = prefs.getBoolean(KEY_LOCK_ALLOW_SCREENSHOT, false)
        set(value) = prefs.edit().putBoolean(KEY_LOCK_ALLOW_SCREENSHOT, value).apply()

    var lockAllowZoom: Boolean
        get() = prefs.getBoolean(KEY_LOCK_ALLOW_ZOOM, false)
        set(value) = prefs.edit().putBoolean(KEY_LOCK_ALLOW_ZOOM, value).apply()

    var lockAllowLongPress2x: Boolean
        get() = prefs.getBoolean(KEY_LOCK_ALLOW_LONG_PRESS_2X, false)
        set(value) = prefs.edit().putBoolean(KEY_LOCK_ALLOW_LONG_PRESS_2X, value).apply()

    var lockAllowTwoFingerTracks: Boolean
        get() = prefs.getBoolean(KEY_LOCK_ALLOW_TWO_FINGER_TRACKS, false)
        set(value) = prefs.edit().putBoolean(KEY_LOCK_ALLOW_TWO_FINGER_TRACKS, value).apply()

    var lockAllowTwoFingerUnlock: Boolean
        get() = prefs.getBoolean(KEY_LOCK_ALLOW_TWO_FINGER_UNLOCK, true)
        set(value) = prefs.edit().putBoolean(KEY_LOCK_ALLOW_TWO_FINGER_UNLOCK, value).apply()

    var lockAllowSpeedDragLock: Boolean
        get() = prefs.getBoolean(KEY_LOCK_ALLOW_SPEED_DRAG_LOCK, false)
        set(value) = prefs.edit().putBoolean(KEY_LOCK_ALLOW_SPEED_DRAG_LOCK, value).apply()
}