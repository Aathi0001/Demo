package com.example.videoplayer.cores.locals

import android.content.Context
import com.example.videoplayer.configs.GeneralConfig
import com.example.videoplayer.cores.db.AppDatabase
import com.example.videoplayer.cores.db.AppDatabaseDao
import com.example.videoplayer.cores.models.FolderSortEntity
import com.example.videoplayer.cores.models.WatchProgressEntity
import com.example.videoplayer.utils.AppFunc
import java.util.concurrent.ConcurrentHashMap

/**
 * =========================================================================
 * CLASS: DatabaseManager
 * PACKAGE: com.example.videoplayer.cores.locals
 * DESCRIPTION: Thread-safe singleton coordinator for SQLite Room operations.
 *              Maintains a high-speed in-memory watch progress cache to prevent
 *              disk I/O bottlenecks during fast RecyclerView scrolling.
 * =========================================================================
 */
class DatabaseManager private constructor(context: Context) {

    private val dao: AppDatabaseDao = AppDatabase.getInstance(context).appDao()

    // Fast in-memory cache mapping videoPath -> WatchProgressEntity
    private val watchCache = ConcurrentHashMap<String, WatchProgressEntity>()

    companion object {
        @Volatile
        private var INSTANCE: DatabaseManager? = null

        /**
         * -------------------------------------------------------------------------
         * Function: getInstance
         * Description: Returns thread-safe singleton instance of DatabaseManager.
         * Input: context (Context)
         * Output: DatabaseManager
         * -------------------------------------------------------------------------
         */
        fun getInstance(context: Context): DatabaseManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: DatabaseManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: preloadWatchCache
     * Description: Asynchronously primes the in-memory cache with all watch
     *              progress records from Room to eliminate disk queries during scroll.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    suspend fun preloadWatchCache() {
        try {
            val allRecords = dao.getAllWatchProgress()
            for (record in allRecords) {
                watchCache[record.videoPath] = record
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: getWatchProgress
     * Description: Retrieves watch progress for a video path. Checks RAM cache
     *              first; falls back to Room SQLite query if cache misses.
     * Input: videoPath (String) - Absolute file path identifier.
     * Output: WatchProgressEntity? - Saved entity or null if unwatched.
     * -------------------------------------------------------------------------
     */
    suspend fun getWatchProgress(videoPath: String): WatchProgressEntity? {
        watchCache[videoPath]?.let { return it }

        return try {
            val fromDb = dao.getWatchProgress(videoPath)
            if (fromDb != null) {
                watchCache[videoPath] = fromDb
            }
            fromDb
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: saveWatchProgress
     * Description: Evaluates eligibility, updates RAM cache immediately, and
     *              asynchronously commits the progress record to Room SQLite.
     * Input: videoPath (String), positionMs (Long), durationMs (Long)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    suspend fun saveWatchProgress(videoPath: String, positionMs: Long, durationMs: Long) {
        if (videoPath.isBlank() || durationMs <= 0L) return

        val isEligible = AppFunc.isResumeEligible(positionMs, durationMs)
        val isCompleted = !isEligible && positionMs >= (durationMs * GeneralConfig.COMPLETION_PERCENTAGE)

        val entity = WatchProgressEntity(
            videoPath = videoPath,
            lastPositionMs = if (isCompleted) 0L else positionMs,
            durationMs = durationMs,
            isCompleted = isCompleted,
            lastWatchedAt = System.currentTimeMillis()
        )

        // Write directly to RAM first for zero latency UI responsiveness
        watchCache[videoPath] = entity

        try {
            dao.upsertWatchProgress(entity)
            dao.pruneWatchProgress()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: getFolderSortMode
     * Description: Retrieves the persistent custom sort mode configured for a folder.
     * Input: folderPath (String)
     * Output: Int? - Sort mode constant or null if default.
     * -------------------------------------------------------------------------
     */
    suspend fun getFolderSortMode(folderPath: String): Int? {
        return try {
            dao.getFolderSort(folderPath)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: saveFolderSortMode
     * Description: Persists a custom sort mode selection for a folder directory.
     * Input: folderPath (String), sortMode (Int)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    suspend fun saveFolderSortMode(folderPath: String, sortMode: Int) {
        try {
            val entity = FolderSortEntity(
                folderPath = folderPath,
                sortMode = sortMode,
                updatedAt = System.currentTimeMillis()
            )
            dao.upsertFolderSort(entity)
            dao.pruneFolderSorts()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}