package com.example.videoplayer.cores.locals

import android.content.Context
import android.database.Cursor
import android.provider.MediaStore
import com.example.videoplayer.configs.GeneralConfig
import com.example.videoplayer.cores.models.VideoItem
import com.example.videoplayer.utils.AppFunc
import com.example.videoplayer.utils.GeneralFunc
import com.example.videoplayer.utils.NaturalSortComparator
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter

/**
 * =========================================================================
 * CLASS: ChunkWriter
 * PACKAGE: com.example.videoplayer.cores.locals
 * DESCRIPTION: Streams MediaStore cursor results, partitions items into batches
 *              strictly bounded by 4MB / 15,000 items, sorts via the requested
 *              comparator, and flushes sequential chunk files to disk.
 * =========================================================================
 */
class ChunkWriter(private val context: Context) {

    /**
     * -------------------------------------------------------------------------
     * Function: getBucketDirectory
     * Description: Creates or retrieves the isolated cache directory for a bucket ID.
     * Input: bucketId (String) - MediaStore bucket identifier for target folder.
     * Output: File - Isolated cache directory.
     * -------------------------------------------------------------------------
     */
    fun getBucketDirectory(bucketId: String): File {
        val root = File(context.cacheDir, GeneralConfig.SORT_CACHE_DIR)
        val bucketDir = File(root, "bucket_$bucketId")
        if (!bucketDir.exists()) {
            bucketDir.mkdirs()
        }
        return bucketDir
    }

    /**
     * -------------------------------------------------------------------------
     * Function: clearBucketDirectory
     * Description: Deletes all temporary chunk partitions for a specific folder.
     * Input: bucketId (String) - MediaStore bucket identifier.
     * Output: Boolean - True if successfully wiped.
     * -------------------------------------------------------------------------
     */
    fun clearBucketDirectory(bucketId: String): Boolean {
        val bucketDir = File(context.cacheDir, "${GeneralConfig.SORT_CACHE_DIR}/bucket_$bucketId")
        return if (bucketDir.exists()) bucketDir.deleteRecursively() else true
    }

    /**
     * -------------------------------------------------------------------------
     * Function: createChunksFromCursor
     * Description: Iterates a MediaStore cursor, measures real-time JVM memory
     *              footprint, and flushes sorted chunk files when thresholds hit.
     * Input: cursor (Cursor) - Active MediaStore cursor with cached column projections.
     *        bucketId (String) - Folder bucket identifier.
     *        sortMode (Int) - Target sorting mode constant.
     * Output: List<File> - Ordered list of flushed temporary chunk files.
     * -------------------------------------------------------------------------
     */
    fun createChunksFromCursor(cursor: Cursor, bucketId: String, sortMode: Int): List<File> {
        val chunkFiles = ArrayList<File>()
        val bucketDir = getBucketDirectory(bucketId)
        val comparator = NaturalSortComparator.getComparator(sortMode)

        // Clear stale chunks from any prior ungracefully terminated session
        bucketDir.listFiles()?.forEach { it.delete() }

        // Cache column indices outside iteration loop to maximize throughput
        val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
        val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
        val pathCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
        val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
        val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
        val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)

        val currentBatch = ArrayList<VideoItem>(GeneralConfig.CHUNK_MAX_ITEM_LIMIT)
        var currentBatchBytes = 0L
        var chunkIndex = 0

        while (cursor.moveToNext()) {
            val id = cursor.getLong(idCol)
            val name = cursor.getString(nameCol) ?: "Unknown"
            val path = cursor.getString(pathCol) ?: ""
            val duration = cursor.getLong(durCol)
            val size = cursor.getLong(sizeCol)
            val date = cursor.getLong(dateCol)

            val item = VideoItem(id, name, path, duration, size, date)
            currentBatch.add(item)

            // Track memory: 48 bytes object/pointer overhead + character array memory
            currentBatchBytes += 48L + GeneralFunc.estimateStringMemoryBytes(name) + GeneralFunc.estimateStringMemoryBytes(path)

            // Dual-condition trigger: flush if either 4MB limit or 15,000 items exceeded
            if (currentBatchBytes >= GeneralConfig.CHUNK_MAX_BYTE_LIMIT || currentBatch.size >= GeneralConfig.CHUNK_MAX_ITEM_LIMIT) {
                val file = flushBatch(currentBatch, bucketDir, chunkIndex++, comparator)
                chunkFiles.add(file)
                currentBatch.clear()
                currentBatchBytes = 0L
            }
        }

        // Flush any remaining trailing elements
        if (currentBatch.isNotEmpty()) {
            val file = flushBatch(currentBatch, bucketDir, chunkIndex, comparator)
            chunkFiles.add(file)
            currentBatch.clear()
        }

        return chunkFiles
    }

    /**
     * -------------------------------------------------------------------------
     * Function: flushBatch
     * Description: Sorts in-memory items via the active comparator and persists
     *              them to a disk chunk using a buffered stream.
     * Input: batch (MutableList<VideoItem>) - Current accumulated in-memory items.
     *        targetDir (File) - Destination bucket directory.
     *        index (Int) - Sequential chunk partition index.
     *        comparator (Comparator<VideoItem>) - Sorting comparator.
     * Output: File - Reference to the written chunk file.
     * -------------------------------------------------------------------------
     */
    private fun flushBatch(
        batch: MutableList<VideoItem>,
        targetDir: File,
        index: Int,
        comparator: Comparator<VideoItem>
    ): File {
        batch.sortWith(comparator)
        val file = File(targetDir, "chunk_$index.tmp")

        BufferedWriter(FileWriter(file), 32 * 1024).use { writer ->
            for (i in 0 until batch.size) {
                writer.write(AppFunc.serializeChunkLine(batch[i]))
            }
            writer.flush()
        }
        return file
    }
}