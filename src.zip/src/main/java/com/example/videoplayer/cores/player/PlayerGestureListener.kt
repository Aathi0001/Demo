package com.example.videoplayer.cores.player

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import com.example.videoplayer.configs.GeneralConfig
import com.example.videoplayer.cores.locals.AppPreferences
import com.example.videoplayer.utils.GeneralFunc
import kotlin.math.abs

/**
 * =========================================================================
 * INTERFACE: PlayerGestureCallback
 * PACKAGE: com.example.videoplayer.cores.player
 * DESCRIPTION: Dispatches interpreted UI interaction events (taps, scrubs,
 *              swipes, zoom scale) to the governing Activity/UI layer.
 * =========================================================================
 */
interface PlayerGestureCallback {
    fun onSingleTap()
    fun onDoubleTapSeek(isForward: Boolean, targetPositionMs: Long)
    fun onDoubleTapPlayPause()
    fun onVolumeChanged(currentVolumeRatio: Float)
    fun onBrightnessChanged(currentBrightnessRatio: Float)
    fun onScaleChanged(scaleFactor: Float)
    fun onHorizontalScrub(seekPositionMs: Long, deltaMs: Long, isFinalCommit: Boolean)
    fun onScreenshotGestureTriggered()

    // Hold & Speed Locks
    fun onHold2xSpeedStart()
    fun onHold2xSpeedEnd()
    fun onLock2xSpeedCommitted()
    fun onUnlock2xSpeedCommitted()

    // Multi-touch Gestures
    fun onTwoFingerSwipeTracks(isAudioTrack: Boolean)
    fun onTwoFingerDoubleTapLockToggle()
}

/**
 * =========================================================================
 * CLASS: PlayerGestureListener
 * PACKAGE: com.example.videoplayer.cores.player
 * DESCRIPTION: Multi-touch gesture dispatcher handling single/double taps,
 *              horizontal progressive scrubbing, vertical brightness/volume drags,
 *              two-finger pinch-to-zoom scaling, and edge deadzones.
 * =========================================================================
 */
class PlayerGestureListener(
    private val context: Context,
    private val targetView: View,
    private val playerEngine: PlayerEngine,
    private val callback: PlayerGestureCallback,
    private val appPreferences: AppPreferences
) : View.OnTouchListener {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat().coerceAtLeast(1f)

    private var volumeAccumulator: Float = 0f
    private var brightnessAccumulator: Float = 0.5f

    private enum class GestureMode { 
        NONE, VERTICAL_BRIGHTNESS, VERTICAL_VOLUME, HORIZONTAL_SCRUB, SCREENSHOT_TRIGGERED, SCALE, TWO_FINGER_SWIPE 
    }
    private var activeMode = GestureMode.NONE

    private enum class SpeedLockAction {
        NONE, LOCK_2X, UNLOCK_2X
    }
    private var pendingSpeedLockAction = SpeedLockAction.NONE

    private var initialSeekPositionMs = 0L
    private var scrubDeltaMs = 0L
    private var currentScale = 1.0f

    // Long press & speed lock state
    private var isHolding2xSpeed = false
    private var longPressStartY = 0f

    // Two finger tracking state
    private var twoFingerStartX = 0f
    private var twoFingerStartY = 0f
    private var lastTwoFingerTapTime = 0L
    private var isTwoFingerGestureActive = false

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {

        /**
         * -------------------------------------------------------------------------
         * Function: onDown
         * Description: Captures base volume, current screen brightness, and playback
         *              position prior to gesture movement initiation.
         * -------------------------------------------------------------------------
         */
        override fun onDown(e: MotionEvent): Boolean {
            volumeAccumulator = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()

            val activity = context as? Activity
            val lp = activity?.window?.attributes
            val currentBrightness = lp?.screenBrightness ?: -1f
            brightnessAccumulator = if (currentBrightness < 0f) 0.5f else currentBrightness

            initialSeekPositionMs = playerEngine.currentPosition
            scrubDeltaMs = 0L
            activeMode = GestureMode.NONE
            return true
        }       

        override fun onLongPress(e: MotionEvent) {
            if (activeMode != GestureMode.NONE) return

            if (appPreferences.isLongPress2xEnabled) {
                isHolding2xSpeed = true
                longPressStartY = e.y
                pendingSpeedLockAction = SpeedLockAction.NONE
                callback.onHold2xSpeedStart()
            }
        }

        /**
         * -------------------------------------------------------------------------
         * Function: onSingleTapConfirmed
         * Description: Dispatches single tap event to toggle playback controller visibility.
         * -------------------------------------------------------------------------
         */
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            callback.onSingleTap()
            return true
        }

        /**
         * -------------------------------------------------------------------------
         * Function: onDoubleTap
         * Description: Partitions the screen into three zones (Left 35% Rewind,
         *              Center 30% Play/Pause, Right 35% Fast Forward).
         * -------------------------------------------------------------------------
         */
        override fun onDoubleTap(e: MotionEvent): Boolean {
            val width = targetView.width
            val height = targetView.height
            val x = e.x
            val y = e.y

            // Ignore double tap if initiated within 5% edge boundaries
            if (x < width * 0.05f || x > width * 0.95f || y < height * 0.05f || y > height * 0.95f) {
                return false
            }

            val seekDurationMs = appPreferences.doubleTapSeekSeconds * 1000L

            when {
                // Left 35%: Rewind
                x < width * 0.35f -> {
                    if (appPreferences.isDoubleTapSeekEnabled) {
                        val newPos = playerEngine.seekRelative(-seekDurationMs)
                        callback.onDoubleTapSeek(false, newPos)
                    }
                }
                // Right 35%: Fast Forward
                x > width * 0.65f -> {
                    if (appPreferences.isDoubleTapSeekEnabled) {
                        val newPos = playerEngine.seekRelative(seekDurationMs)
                        callback.onDoubleTapSeek(true, newPos)
                    }
                }
                // Center 30%: Play / Pause
                else -> {
                    callback.onDoubleTapPlayPause()
                }
            }
            return true
        }

        /**
         * -------------------------------------------------------------------------
         * Function: onScroll
         * Description: Evaluates scroll delta vectors to discriminate between
         *              horizontal seek scrubbing and vertical brightness/volume adjustments.
         * -------------------------------------------------------------------------
         */
        override fun onScroll(
            e1: MotionEvent?,
            e2: MotionEvent,
            distanceX: Float,
            distanceY: Float
        ): Boolean {
            if (e1 == null || e2.pointerCount > 1 || isHolding2xSpeed) return false
            // rest of your onScroll remains unchanged...
            val width = targetView.width.coerceAtLeast(1)
            val height = targetView.height.coerceAtLeast(1)

            // 5% Deadzone boundaries on all four screen edges (Left, Right, Top, Bottom)
            val isInsideHorizontalDeadzone = e1.x < (width * 0.05f) || e1.x > (width * 0.95f)
            val isInsideVerticalDeadzone = e1.y < (height * 0.05f) || e1.y > (height * 0.95f)

            if (isInsideHorizontalDeadzone || isInsideVerticalDeadzone) {
                return false
            }

            // Detect dominant gesture direction on initial movement
            if (activeMode == GestureMode.NONE) {
                if (abs(distanceX) > abs(distanceY)) {
                    if (appPreferences.isHorizontalScrubEnabled) {
                        activeMode = GestureMode.HORIZONTAL_SCRUB
                    }
                } else {
                    val startX = e1.x
                    activeMode = when {
                        startX < width * 0.35f && appPreferences.isBrightnessGestureEnabled -> GestureMode.VERTICAL_BRIGHTNESS
                        startX > width * 0.65f && appPreferences.isVolumeGestureEnabled -> GestureMode.VERTICAL_VOLUME
                        else -> GestureMode.NONE
                    }
                }
            }

            when (activeMode) {
                GestureMode.VERTICAL_BRIGHTNESS -> {
                    val deltaRatio = distanceY / height
                    adjustBrightness(deltaRatio)
                }
                GestureMode.VERTICAL_VOLUME -> {
                    val deltaRatio = distanceY / height
                    adjustVolume(deltaRatio)
                }
                GestureMode.HORIZONTAL_SCRUB -> {
                    val totalDeltaX = e2.x - e1.x
                    val totalDuration = playerEngine.duration.coerceAtLeast(1L)

                    // VLC-style progressive scrubbing: fine drags near center, accelerating on long swipes
                    val distanceRatio = abs(totalDeltaX) / width.toFloat()
                    val accelerationMultiplier = 1.0f + (distanceRatio * 3.0f)
                    scrubDeltaMs = (totalDeltaX * 50f * accelerationMultiplier).toLong()

                    val targetSeek = (initialSeekPositionMs + scrubDeltaMs).coerceIn(0L, totalDuration)
                    callback.onHorizontalScrub(targetSeek, scrubDeltaMs, false)
                }
                GestureMode.NONE -> {
                    if (appPreferences.isSwipeScreenshotEnabled) {
                        val verticalDisplacement = abs(e2.y - e1.y)
                        if (verticalDisplacement > 90 * context.resources.displayMetrics.density) {
                            callback.onScreenshotGestureTriggered()
                            activeMode = GestureMode.SCREENSHOT_TRIGGERED
                        }
                    }
                }
                GestureMode.SCREENSHOT_TRIGGERED -> {
                    // Consumed
                }
            }
            return true
        }
    })

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
            activeMode = GestureMode.SCALE
            return true
        }

         /**
         * -------------------------------------------------------------------------
         * Function: onScale
         * Description: Handles pinch-to-zoom scaling constrained by GeneralConfig limits.
         * -------------------------------------------------------------------------
         */
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            currentScale *= detector.scaleFactor
            currentScale = GeneralFunc.clampValue(
                currentScale,
                GeneralConfig.MIN_PINCH_SCALE,
                GeneralConfig.MAX_PINCH_SCALE
            )
            callback.onScaleChanged(currentScale)
            return true
        }
    })

    /**
     * -------------------------------------------------------------------------
     * Function: onTouch
     * Description: Root touch event dispatcher separating multi-touch scale from
     *              single-touch gestures, and committing seek on ACTION_UP.
     * Input: v (View), event (MotionEvent)
     * Output: Boolean
     * -------------------------------------------------------------------------
     */
    override fun onTouch(v: View, event: MotionEvent): Boolean {
        // --- 1. Two-Finger Multi-Touch Processing ---
        if (event.pointerCount == 2) {
            isTwoFingerGestureActive = true

            // Cancel single-finger 2x speed hold when a second finger touches
            if (isHolding2xSpeed) {
                isHolding2xSpeed = false
                callback.onHold2xSpeedEnd()
            }

            when (event.actionMasked) {
                MotionEvent.ACTION_POINTER_DOWN -> {
                    twoFingerStartX = (event.getX(0) + event.getX(1)) / 2f
                    twoFingerStartY = (event.getY(0) + event.getY(1)) / 2f
                }
                MotionEvent.ACTION_MOVE -> {
                    if (activeMode != GestureMode.SCALE) {
                        val currentX = (event.getX(0) + event.getX(1)) / 2f
                        val currentY = (event.getY(0) + event.getY(1)) / 2f
                        val dx = currentX - twoFingerStartX
                        val dy = currentY - twoFingerStartY

                        // Swipe left/right threshold > 120px
                        if (abs(dx) > abs(dy) && abs(dx) > 120f && activeMode != GestureMode.TWO_FINGER_SWIPE) {
                            activeMode = GestureMode.TWO_FINGER_SWIPE
                            if (appPreferences.isTwoFingerSwipeTracksEnabled) {
                                if (dx < 0) {
                                    callback.onTwoFingerSwipeTracks(isAudioTrack = true) // Left: Audio
                                } else {
                                    callback.onTwoFingerSwipeTracks(isAudioTrack = false) // Right: Subtitles
                                }
                            }
                        }
                    }
                }
            }

            scaleDetector.onTouchEvent(event)
            return true
        }

        // --- 2. Single-Finger Gesture Processing ---
        gestureDetector.onTouchEvent(event)

        // Track drag down (Lock 2x) or drag up (Unlock 2x) while holding
        if (isHolding2xSpeed && event.action == MotionEvent.ACTION_MOVE) {
            val deltaY = event.y - longPressStartY

            if (appPreferences.isSpeedDragLockEnabled) {
                pendingSpeedLockAction = when {
                    deltaY > 120f -> SpeedLockAction.LOCK_2X
                    deltaY < -120f -> SpeedLockAction.UNLOCK_2X
                    else -> SpeedLockAction.NONE
                }
            }
        }

        // --- 3. Pointer Release / Cleanup ---
        if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_CANCEL) {
            // Two-Finger Double Tap -> Toggle Lock Screen
            if (isTwoFingerGestureActive && activeMode != GestureMode.TWO_FINGER_SWIPE && activeMode != GestureMode.SCALE) {
                val now = System.currentTimeMillis()
                if (now - lastTwoFingerTapTime < 320L) {
                    if (appPreferences.isTwoFingerLockToggleEnabled) {
                        callback.onTwoFingerDoubleTapLockToggle()
                    }
                    lastTwoFingerTapTime = 0L
                } else {
                    lastTwoFingerTapTime = now
                }
            }
            isTwoFingerGestureActive = false

            // Process Long-Press Speed Commit / Release
            if (isHolding2xSpeed) {
                isHolding2xSpeed = false
                when (pendingSpeedLockAction) {
                    SpeedLockAction.LOCK_2X -> callback.onLock2xSpeedCommitted()
                    SpeedLockAction.UNLOCK_2X -> callback.onUnlock2xSpeedCommitted()
                    SpeedLockAction.NONE -> callback.onHold2xSpeedEnd()
                }
            }

            // Commit timeline seek if dragging
            if (activeMode == GestureMode.HORIZONTAL_SCRUB) {
                val totalDuration = playerEngine.duration.coerceAtLeast(1L)
                val targetSeek = (initialSeekPositionMs + scrubDeltaMs).coerceIn(0L, totalDuration)
                playerEngine.seekTo(targetSeek)
                callback.onHorizontalScrub(targetSeek, scrubDeltaMs, true)
            }

            activeMode = GestureMode.NONE
            scrubDeltaMs = 0L
            pendingSpeedLockAction = SpeedLockAction.NONE
        }

        return true
    }

    /**
     * -------------------------------------------------------------------------
     * Function: adjustBrightness
     * Description: Adjusts window screen brightness by normalized ratio.
     * Input: deltaRatio (Float)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun adjustBrightness(deltaRatio: Float) {
        val activity = context as? Activity ?: return
        val layoutParams = activity.window.attributes

        brightnessAccumulator = GeneralFunc.clampValue(brightnessAccumulator + (deltaRatio * 1.2f), 0.01f, 1.0f)
        layoutParams.screenBrightness = brightnessAccumulator
        activity.window.attributes = layoutParams

        callback.onBrightnessChanged(brightnessAccumulator)
    }

    /**
     * -------------------------------------------------------------------------
     * Function: adjustVolume
     * Description: Adjusts music stream volume and delivers normalized ratio to callback.
     * Input: deltaRatio (Float)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun adjustVolume(deltaRatio: Float) {
        val delta = deltaRatio * maxVolume * 1.5f
        volumeAccumulator = GeneralFunc.clampValue(volumeAccumulator + delta, 0f, maxVolume)

        val targetStep = volumeAccumulator.toInt()
        audioManager.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            targetStep,
            AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE
        )

        val normalizedRatio = volumeAccumulator / maxVolume
        callback.onVolumeChanged(normalizedRatio)
    }
}