package com.example.videoplayer.cores.player

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.view.View
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.example.videoplayer.configs.GeneralConfig
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File
import java.io.FileOutputStream

/**
 * =========================================================================
 * ENUM: ActiveEngine
 * PACKAGE: com.example.videoplayer.cores.player
 * DESCRIPTION: Identifies the active hardware/software playback backend.
 * =========================================================================
 */
enum class ActiveEngine {
    EXO_PLAYER,
    LIB_VLC
}

/**
 * =========================================================================
 * CLASS: PlayerEngine
 * PACKAGE: com.example.videoplayer.cores.player
 * DESCRIPTION: Unified dual-engine media playback manager coordinating between
 *              Google Media3 (ExoPlayer) for fast HW decoding and LibVLC
 *              as a software fallback engine for complex codecs and containers.
 * =========================================================================
 */
class PlayerEngine(
    private val context: Context,
    private val playerView: PlayerView,
    private val vlcVideoLayout: VLCVideoLayout,
    private val onEngineChanged: (ActiveEngine) -> Unit,
    private val onPlaybackEnded: () -> Unit
) {
    var activeEngine: ActiveEngine = ActiveEngine.EXO_PLAYER
        private set

    var exoPlayer: ExoPlayer? = null
        private set

    private var libVLC: LibVLC? = null
    var vlcMediaPlayer: MediaPlayer? = null
        private set
    private var pfd: ParcelFileDescriptor? = null

    private var currentUri: Uri? = null
    private var lastKnownPositionMs: Long = 0L
    private var pendingVlcSeekPos: Long = 0L
    private var isVlcViewsAttached: Boolean = false

    var subtitleDelayMs: Long = 0L
        private set
    var audioDelayMs: Long = 0L
        private set

    val isPlaying: Boolean
        get() = when (activeEngine) {
            ActiveEngine.EXO_PLAYER -> exoPlayer?.isPlaying == true
            ActiveEngine.LIB_VLC -> vlcMediaPlayer?.isPlaying == true
        }

    val currentPosition: Long
        get() = when (activeEngine) {
            ActiveEngine.EXO_PLAYER -> exoPlayer?.currentPosition ?: lastKnownPositionMs
            ActiveEngine.LIB_VLC -> vlcMediaPlayer?.time ?: lastKnownPositionMs
        }

    val duration: Long
        get() = when (activeEngine) {
            ActiveEngine.EXO_PLAYER -> exoPlayer?.duration?.coerceAtLeast(0L) ?: 0L
            ActiveEngine.LIB_VLC -> vlcMediaPlayer?.length?.coerceAtLeast(0L) ?: 0L
        }

    init {
        initExoPlayer()
    }

    /**
     * -------------------------------------------------------------------------
     * Function: initExoPlayer
     * Description: Initializes ExoPlayer with low-RAM load control, extension
     *              renderers enabled, and decoder fallback active.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun initExoPlayer() {
        if (exoPlayer != null) return

        val renderersFactory = DefaultRenderersFactory(context).apply {
            setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            setEnableDecoderFallback(true)
        }

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val loadControl = LowRamLoadControl.create()

        exoPlayer = ExoPlayer.Builder(context, renderersFactory)
            .setAudioAttributes(audioAttributes, true)
            .setLoadControl(loadControl)
            .setSeekParameters(SeekParameters.CLOSEST_SYNC)
            .build()
            .apply {
                playerView.player = this
                videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
                addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_ENDED) {
                            onPlaybackEnded()
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        switchToVlc(force = false)
                    }
                })
            }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: playMedia
     * Description: Initiates media playback at the specified position using
     *              either the preferred or current active engine.
     * Input: uri (Uri), startPositionMs (Long), preferredEngine (ActiveEngine?)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun playMedia(uri: Uri, startPositionMs: Long = 0L, preferredEngine: ActiveEngine? = null) {
        cleanupSubtitleCache()
        currentUri = uri
        lastKnownPositionMs = startPositionMs

        if (preferredEngine == ActiveEngine.LIB_VLC || (preferredEngine == null && activeEngine == ActiveEngine.LIB_VLC)) {
            startVlcPlayback(uri, startPositionMs, force = true)
            return
        }

        if (activeEngine == ActiveEngine.LIB_VLC) {
            stopVlc()
        }

        activeEngine = ActiveEngine.EXO_PLAYER
        vlcVideoLayout.visibility = View.GONE
        playerView.visibility = View.VISIBLE
        onEngineChanged(ActiveEngine.EXO_PLAYER)

        if (exoPlayer == null) {
            initExoPlayer()
        }

        exoPlayer?.let { player ->
            playerView.player = player
            val mediaItem = MediaItem.fromUri(uri)
            player.setMediaItem(mediaItem)
            if (startPositionMs > 0L) {
                player.seekTo(startPositionMs)
            }
            player.prepare()
            player.playWhenReady = true
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: switchToVlc
     * Description: Seamlessly hot-swaps active playback from ExoPlayer to LibVLC,
     *              preserving current playback position.
     * Input: force (Boolean) - Whether to force software decoder mode.
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun switchToVlc(force: Boolean = true) {
        val resumePos = if (activeEngine == ActiveEngine.EXO_PLAYER) {
            exoPlayer?.currentPosition ?: lastKnownPositionMs
        } else {
            vlcMediaPlayer?.time ?: lastKnownPositionMs
        }
        currentUri?.let { startVlcPlayback(it, resumePos, force) }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: startVlcPlayback
     * Description: Configures LibVLC instance, attaches layout views, and starts playback.
     * Input: uri (Uri), resumePos (Long), force (Boolean)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun startVlcPlayback(uri: Uri, resumePos: Long, force: Boolean) {
        lastKnownPositionMs = resumePos
        pendingVlcSeekPos = resumePos

        exoPlayer?.stop()
        exoPlayer?.clearMediaItems()
        playerView.player = null
        playerView.visibility = View.GONE

        vlcVideoLayout.visibility = View.VISIBLE
        activeEngine = ActiveEngine.LIB_VLC
        onEngineChanged(ActiveEngine.LIB_VLC)

        if (libVLC == null) {
            val options = ArrayList<String>().apply {
                add("--no-drop-late-frames")
                add("--no-skip-frames")
                add("--aout=opensles")
                add("--audio-time-stretch")
                add("--file-caching=1500")
                add("--network-caching=1500")
                add("--codec=mediacodec_ndk,all")
            }
            libVLC = LibVLC(context, options)
        }

        if (vlcMediaPlayer == null) {
            vlcMediaPlayer = MediaPlayer(libVLC)
        }

        vlcMediaPlayer?.setEventListener { event ->
            when (event.type) {
                MediaPlayer.Event.Playing -> {
                    if (pendingVlcSeekPos > 0L) {
                        vlcMediaPlayer?.time = pendingVlcSeekPos
                        pendingVlcSeekPos = 0L
                    }
                }
                MediaPlayer.Event.EndReached -> {
                    onPlaybackEnded()
                }
            }
        }

        safeAttachVlcViews()

        try {
            val media = if (uri.scheme == "content") {
                pfd?.close()
                pfd = context.contentResolver.openFileDescriptor(uri, "r")
                if (pfd != null) {
                    Media(libVLC, pfd!!.fileDescriptor)
                } else {
                    Media(libVLC, uri)
                }
            } else {
                Media(libVLC, uri)
            }

            media.apply {
                setHWDecoderEnabled(!force, false)
            }

            vlcMediaPlayer?.apply {
                this.media = media
                play()
            }
            media.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: switchToExoPlayer
     * Description: Switches playback back to ExoPlayer from LibVLC without ghost audio.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun switchToExoPlayer() {
        if (activeEngine == ActiveEngine.EXO_PLAYER) return
        val currentPos = vlcMediaPlayer?.time ?: lastKnownPositionMs

        stopVlc()

        currentUri?.let { uri ->
            activeEngine = ActiveEngine.EXO_PLAYER
            playMedia(uri, currentPos, ActiveEngine.EXO_PLAYER)
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: safeAttachVlcViews
     * Description: Safely attaches VLC rendering views to VLCVideoLayout.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun safeAttachVlcViews() {
        vlcVideoLayout.post {
            try {
                if (isVlcViewsAttached) {
                    vlcMediaPlayer?.detachViews()
                    isVlcViewsAttached = false
                }
                vlcMediaPlayer?.attachViews(vlcVideoLayout, null, false, false)
                isVlcViewsAttached = true
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: enableBackgroundAudioMode
     * Description: Detaches video surfaces to allow audio playback with screen off.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun enableBackgroundAudioMode() {
        if (activeEngine == ActiveEngine.LIB_VLC) {
            try {
                if (isVlcViewsAttached) {
                    vlcMediaPlayer?.detachViews()
                    isVlcViewsAttached = false
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
            exoPlayer?.clearVideoSurface()
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: exitBackgroundAudioMode
     * Description: Re-attaches video rendering surfaces when returning to foreground.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun exitBackgroundAudioMode() {
        if (activeEngine == ActiveEngine.LIB_VLC && vlcMediaPlayer != null) {
            safeAttachVlcViews()
        } else if (activeEngine == ActiveEngine.EXO_PLAYER) {
            exoPlayer?.let { player ->
                playerView.player = player
            }
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: onActivityResume
     * Description: Lifecycle hook to restore video output on screen resume.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun onActivityResume() {
        exitBackgroundAudioMode()
    }

    /**
     * -------------------------------------------------------------------------
     * Function: addSubtitleSource
     * Description: Dynamically attaches external subtitle files (.srt, .vtt, .ass).
     * Input: uri (Uri) - Subtitle file Uri.
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun addSubtitleSource(uri: Uri) {
        when (activeEngine) {
            ActiveEngine.EXO_PLAYER -> {
                exoPlayer?.let { player ->
                    val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(uri)
                        .setMimeType(
                            when {
                                uri.toString().endsWith(".vtt", ignoreCase = true) -> MimeTypes.TEXT_VTT
                                uri.toString().endsWith(".ass", ignoreCase = true) || uri.toString().endsWith(".ssa", ignoreCase = true) -> MimeTypes.TEXT_SSA
                                else -> MimeTypes.APPLICATION_SUBRIP
                            }
                        )
                        .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                        .build()

                    currentUri?.let { videoUri ->
                        val currentPos = player.currentPosition
                        val mediaItem = MediaItem.Builder()
                            .setUri(videoUri)
                            .setSubtitleConfigurations(listOf(subtitleConfig))
                            .build()
                        player.setMediaItem(mediaItem, currentPos)
                        player.prepare()
                        player.play()
                    }
                }
            }
            ActiveEngine.LIB_VLC -> {
                try {
                    val fileUri = if (uri.scheme == "content") {
                        val tempFile = File(context.cacheDir, "temp_sub_${System.currentTimeMillis()}.srt")
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            FileOutputStream(tempFile).use { output ->
                                input.copyTo(output)
                            }
                        }
                        Uri.fromFile(tempFile)
                    } else {
                        uri
                    }
                    vlcMediaPlayer?.addSlave(0, fileUri, true)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: cleanupSubtitleCache
     * Description: Clears temporary cached subtitle files from internal storage.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun cleanupSubtitleCache() {
        try {
            context.cacheDir.listFiles()?.forEach { file ->
                if (file.name.startsWith("temp_sub_")) {
                    file.delete()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: setSubtitleDelay
     * Description: Adjusts subtitle timing offset in milliseconds.
     * Input: delayMs (Long)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun setSubtitleDelay(delayMs: Long) {
        subtitleDelayMs = delayMs
        if (activeEngine == ActiveEngine.LIB_VLC) {
            vlcMediaPlayer?.setSpuDelay(delayMs * 1000L)
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: setAudioDelay
     * Description: Adjusts audio stream sync offset in milliseconds.
     * Input: delayMs (Long)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun setAudioDelay(delayMs: Long) {
        audioDelayMs = delayMs
        if (activeEngine == ActiveEngine.LIB_VLC) {
            vlcMediaPlayer?.setAudioDelay(delayMs * 1000L)
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: togglePlayPause
     * Description: Toggles playback state of active engine.
     * Input: None
     * Output: Boolean - True if playing, false if paused.
     * -------------------------------------------------------------------------
     */
    fun togglePlayPause(): Boolean {
        return when (activeEngine) {
            ActiveEngine.EXO_PLAYER -> {
                exoPlayer?.let {
                    if (it.isPlaying) {
                        it.pause()
                        false
                    } else {
                        it.play()
                        true
                    }
                } ?: false
            }
            ActiveEngine.LIB_VLC -> {
                vlcMediaPlayer?.let {
                    if (it.isPlaying) {
                        it.pause()
                        false
                    } else {
                        it.play()
                        true
                    }
                } ?: false
            }
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: seekTo
     * Description: Seeks active engine to explicit timestamp in milliseconds.
     * Input: positionMs (Long)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun seekTo(positionMs: Long) {
        lastKnownPositionMs = positionMs
        when (activeEngine) {
            ActiveEngine.EXO_PLAYER -> exoPlayer?.seekTo(positionMs)
            ActiveEngine.LIB_VLC -> vlcMediaPlayer?.time = positionMs
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: seekRelative
     * Description: Seeks forward or backward by delta milliseconds bounded to [0, duration].
     * Input: deltaMs (Long)
     * Output: Long - Final seek timestamp.
     * -------------------------------------------------------------------------
     */
    fun seekRelative(deltaMs: Long): Long {
        val current = currentPosition
        val total = duration
        val target = (current + deltaMs).coerceIn(0L, total.coerceAtLeast(0L))
        seekTo(target)
        return target
    }

    /**
     * -------------------------------------------------------------------------
     * Function: setPlaybackSpeed
     * Description: Applies speed multiplier to active engine.
     * Input: speed (Float)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun setPlaybackSpeed(speed: Float) {
        val validSpeed = if (speed in GeneralConfig.PLAYBACK_SPEED_PRESETS) speed else GeneralConfig.DEFAULT_PLAYBACK_SPEED
        when (activeEngine) {
            ActiveEngine.EXO_PLAYER -> exoPlayer?.playbackParameters = PlaybackParameters(validSpeed)
            ActiveEngine.LIB_VLC -> vlcMediaPlayer?.rate = validSpeed
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: setAspectRatio
     * Description: Toggles aspect ratio scaling mode (Fit, Fill, Zoom, 16:9, 4:3).
     * Input: modeIndex (Int)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun setAspectRatio(modeIndex: Int) {
        when (activeEngine) {
            ActiveEngine.EXO_PLAYER -> {
                when (modeIndex) {
                    0 -> playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    1 -> playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
                    2 -> playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    else -> playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
                }
            }
            ActiveEngine.LIB_VLC -> {
                when (modeIndex) {
                    0 -> vlcMediaPlayer?.aspectRatio = null
                    1 -> vlcMediaPlayer?.aspectRatio = "16:9"
                    2 -> vlcMediaPlayer?.aspectRatio = "4:3"
                    else -> vlcMediaPlayer?.aspectRatio = "fill"
                }
            }
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: stopVlc
     * Description: Completely tears down and releases LibVLC native instances.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun stopVlc() {
        try {
            if (isVlcViewsAttached) {
                vlcMediaPlayer?.detachViews()
                isVlcViewsAttached = false
            }
            vlcMediaPlayer?.apply {
                stop()
                release()
            }
            vlcMediaPlayer = null
            pfd?.close()
            pfd = null
            libVLC?.release()
            libVLC = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: release
     * Description: Cleans up both ExoPlayer and LibVLC engines upon Activity destruction.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun release() {
        cleanupSubtitleCache()
        exoPlayer?.apply {
            stop()
            clearMediaItems()
            release()
        }
        exoPlayer = null
        playerView.player = null

        stopVlc()
    }

    /**
     * -------------------------------------------------------------------------
     * Function: cycleNextTrack
     * Description: Cycles to the next available audio or subtitle track.
     * Input: isAudio (Boolean) - True for audio, False for subtitles.
     * Output: String - Description of the active track to show on the HUD.
     * -------------------------------------------------------------------------
     */
    fun cycleNextTrack(isAudio: Boolean): String {
        return if (activeEngine == ActiveEngine.EXO_PLAYER) {
            cycleExoTrack(isAudio)
        } else {
            cycleVlcTrack(isAudio)
        }
    }

    private fun cycleExoTrack(isAudio: Boolean): String {
        val player = exoPlayer ?: return "No player"
        val trackType = if (isAudio) androidx.media3.common.C.TRACK_TYPE_AUDIO else androidx.media3.common.C.TRACK_TYPE_TEXT
        val tracks = player.currentTracks

        val availableOverrides = mutableListOf<Pair<androidx.media3.common.TrackGroup, Int>>()
        var selectedIdx = -1

        for (group in tracks.groups) {
            if (group.type == trackType) {
                val mediaTrackGroup = group.mediaTrackGroup
                for (i in 0 until mediaTrackGroup.length) {
                    availableOverrides.add(Pair(mediaTrackGroup, i))
                    if (group.isTrackSelected(i)) {
                        selectedIdx = availableOverrides.size - 1
                    }
                }
            }
        }

        if (availableOverrides.isEmpty()) return if (isAudio) "No audio tracks" else "No subtitles"

        // For subtitles: let it cycle to "Off" after the last track
        if (!isAudio && selectedIdx == availableOverrides.size - 1) {
            player.trackSelectionParameters = player.trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_TEXT, true)
                .build()
            return "Subtitles: Off"
        }

        val nextIndex = (selectedIdx + 1) % availableOverrides.size
        val (group, trackIndex) = availableOverrides[nextIndex]

        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(trackType, false)
            .setOverrideForType(androidx.media3.common.TrackSelectionOverride(group, trackIndex))
            .build()

        val format = group.getFormat(trackIndex)
        val name = format.label ?: format.language?.uppercase() ?: "Track ${nextIndex + 1}"
        return if (isAudio) "Audio: $name" else "Subtitles: $name"
    }

    private fun cycleVlcTrack(isAudio: Boolean): String {
        val vlc = vlcMediaPlayer ?: return "No player"
        val tracks = if (isAudio) vlc.audioTracks else vlc.spuTracks
        val currentId = if (isAudio) vlc.audioTrack else vlc.spuTrack

        if (tracks.isNullOrEmpty()) return if (isAudio) "No audio tracks" else "No subtitles"

        val currentIdx = tracks.indexOfFirst { it.id == currentId }
        val nextIdx = (currentIdx + 1) % tracks.size
        val targetTrack = tracks[nextIdx]

        if (isAudio) {
            vlc.setAudioTrack(targetTrack.id)
        } else {
            vlc.setSpuTrack(targetTrack.id)
        }

        val name = if (targetTrack.name.isNullOrBlank()) "Track #${targetTrack.id}" else targetTrack.name
        return if (isAudio) "Audio: $name" else "Subtitles: $name"
    }
}