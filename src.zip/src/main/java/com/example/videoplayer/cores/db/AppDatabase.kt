package com.example.videoplayer.cores.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.videoplayer.configs.GeneralConfig
import com.example.videoplayer.cores.models.FolderSortEntity
import com.example.videoplayer.cores.models.WatchProgressEntity

/**
 * =========================================================================
 * CLASS: AppDatabase
 * PACKAGE: com.example.videoplayer.cores.db
 * DESCRIPTION: Main Room Database provider configuring SQLite instances,
 *              table entities, and exposing AppDatabaseDao.
 * =========================================================================
 */
@Database(
    entities = [WatchProgressEntity::class, FolderSortEntity::class],
    version = GeneralConfig.DATABASE_VERSION,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun appDao(): AppDatabaseDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /**
         * -------------------------------------------------------------------------
         * Function: getInstance
         * Description: Thread-safe singleton accessor for the Room database instance.
         * Input: context (Context)
         * Output: AppDatabase
         * -------------------------------------------------------------------------
         */
        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    GeneralConfig.DATABASE_NAME
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}