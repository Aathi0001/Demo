package com.example.videoplayer.cores.player

import android.content.Context
import android.view.LayoutInflater
import android.widget.RadioButton
import android.widget.RadioGroup
import com.example.videoplayer.R
import com.example.videoplayer.cores.locals.AppPreferences
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.switchmaterial.SwitchMaterial

/**
 * =========================================================================
 * OBJECT: SettingsHelper
 * PACKAGE: com.example.videoplayer.cores.player
 * DESCRIPTION: Manages the player settings bottom sheet dialog, binding
 *              persistent user toggles, lock allowances, and gestures.
 * =========================================================================
 */
object SettingsHelper {

    fun showSettingsDialog(
        context: Context,
        appPreferences: AppPreferences,
        onSettingsUpdated: () -> Unit
    ) {
        val dialog = BottomSheetDialog(context)
        val view = LayoutInflater.from(context).inflate(R.layout.bottom_sheet_settings, null)
        dialog.setContentView(view)

        // Playback
        val switchAutoPlayNext = view.findViewById<SwitchMaterial>(R.id.switchAutoPlayNext)
        val switchBackgroundAudio = view.findViewById<SwitchMaterial>(R.id.switchBackgroundAudio)

        // Core Gestures
        val switchSwipeScreenshot = view.findViewById<SwitchMaterial>(R.id.switchSwipeScreenshot)
        val switchBrightness = view.findViewById<SwitchMaterial>(R.id.switchBrightness)
        val switchVolume = view.findViewById<SwitchMaterial>(R.id.switchVolume)
        val switchScrubbing = view.findViewById<SwitchMaterial>(R.id.switchScrubbing)
        val switchDoubleTapSeek = view.findViewById<SwitchMaterial>(R.id.switchDoubleTapSeek)

        // Advanced Gestures
        val switchLongPress2x = view.findViewById<SwitchMaterial>(R.id.switchLongPress2x)
        val switchSpeedDragLock = view.findViewById<SwitchMaterial>(R.id.switchSpeedDragLock)
        val switchTwoFingerTracks = view.findViewById<SwitchMaterial>(R.id.switchTwoFingerTracks)
        val switchTwoFingerLockToggle = view.findViewById<SwitchMaterial>(R.id.switchTwoFingerLockToggle)

        // UI Buttons
        val switchShowNextPrev = view.findViewById<SwitchMaterial>(R.id.switchShowNextPrev)
        val switchShowScreenshotBtn = view.findViewById<SwitchMaterial>(R.id.switchShowScreenshotBtn)
        val switchShowAspectRatioBtn = view.findViewById<SwitchMaterial>(R.id.switchShowAspectRatioBtn)
        val switchShowOrientationBtn = view.findViewById<SwitchMaterial>(R.id.switchShowOrientationBtn)
        val switchShowPipBtn = view.findViewById<SwitchMaterial>(R.id.switchShowPipBtn)
        val switchShowSpeedBtn = view.findViewById<SwitchMaterial>(R.id.switchShowSpeedBtn)
        val switchShowDecoderBtn = view.findViewById<SwitchMaterial>(R.id.switchShowDecoderBtn)
        val switchShowBackgroundAudioBtn = view.findViewById<SwitchMaterial>(R.id.switchShowBackgroundAudioBtn)
        val switchShowTracksBtn = view.findViewById<SwitchMaterial>(R.id.switchShowTracksBtn)
        val switchShowLockBtn = view.findViewById<SwitchMaterial>(R.id.switchShowLockBtn)

        // Lock Screen Allowances
        val switchLockAllowVolume = view.findViewById<SwitchMaterial>(R.id.switchLockAllowVolume)
        val switchLockAllowBrightness = view.findViewById<SwitchMaterial>(R.id.switchLockAllowBrightness)
        val switchLockAllowSeek = view.findViewById<SwitchMaterial>(R.id.switchLockAllowSeek)
        val switchLockAllowScreenshot = view.findViewById<SwitchMaterial>(R.id.switchLockAllowScreenshot)
        val switchLockAllowZoom = view.findViewById<SwitchMaterial>(R.id.switchLockAllowZoom)
        val switchLockAllowLongPress2x = view.findViewById<SwitchMaterial>(R.id.switchLockAllowLongPress2x)
        val switchLockAllowSpeedDragLock = view.findViewById<SwitchMaterial>(R.id.switchLockAllowSpeedDragLock)
        val switchLockAllowTwoFingerTracks = view.findViewById<SwitchMaterial>(R.id.switchLockAllowTwoFingerTracks)
        val switchLockAllowTwoFingerUnlock = view.findViewById<SwitchMaterial>(R.id.switchLockAllowTwoFingerUnlock)

        // Seek Duration
        val rgSeekDuration = view.findViewById<RadioGroup>(R.id.rgSeekDuration)

        // --- Load Values from AppPreferences ---
        switchAutoPlayNext.isChecked = appPreferences.isAutoPlayNextEnabled
        switchBackgroundAudio.isChecked = appPreferences.isBackgroundAudioEnabled

        switchSwipeScreenshot.isChecked = appPreferences.isSwipeScreenshotEnabled
        switchBrightness.isChecked = appPreferences.isBrightnessGestureEnabled
        switchVolume.isChecked = appPreferences.isVolumeGestureEnabled
        switchScrubbing.isChecked = appPreferences.isHorizontalScrubEnabled
        switchDoubleTapSeek.isChecked = appPreferences.isDoubleTapSeekEnabled

        switchLongPress2x.isChecked = appPreferences.isLongPress2xEnabled
        switchSpeedDragLock.isChecked = appPreferences.isSpeedDragLockEnabled
        switchTwoFingerTracks.isChecked = appPreferences.isTwoFingerSwipeTracksEnabled
        switchTwoFingerLockToggle.isChecked = appPreferences.isTwoFingerLockToggleEnabled

        switchShowNextPrev.isChecked = appPreferences.showNextPrevButtons
        switchShowScreenshotBtn.isChecked = appPreferences.showScreenshotButton
        switchShowAspectRatioBtn.isChecked = appPreferences.showAspectRatioButton
        switchShowOrientationBtn.isChecked = appPreferences.showOrientationButton
        switchShowPipBtn.isChecked = appPreferences.showPipButton
        switchShowSpeedBtn.isChecked = appPreferences.showSpeedButton
        switchShowDecoderBtn.isChecked = appPreferences.showDecoderToggleButton
        switchShowBackgroundAudioBtn.isChecked = appPreferences.showBackgroundAudioButton
        switchShowTracksBtn.isChecked = appPreferences.showTracksButton
        switchShowLockBtn.isChecked = appPreferences.showLockButton

        switchLockAllowVolume.isChecked = appPreferences.lockAllowVolume
        switchLockAllowBrightness.isChecked = appPreferences.lockAllowBrightness
        switchLockAllowSeek.isChecked = appPreferences.lockAllowSeek
        switchLockAllowScreenshot.isChecked = appPreferences.lockAllowScreenshot
        switchLockAllowZoom.isChecked = appPreferences.lockAllowZoom
        switchLockAllowLongPress2x.isChecked = appPreferences.lockAllowLongPress2x
        switchLockAllowSpeedDragLock.isChecked = appPreferences.lockAllowSpeedDragLock
        switchLockAllowTwoFingerTracks.isChecked = appPreferences.lockAllowTwoFingerTracks
        switchLockAllowTwoFingerUnlock.isChecked = appPreferences.lockAllowTwoFingerUnlock

        when (appPreferences.doubleTapSeekSeconds) {
            5 -> view.findViewById<RadioButton>(R.id.rbSeek5).isChecked = true
            15 -> view.findViewById<RadioButton>(R.id.rbSeek15).isChecked = true
            30 -> view.findViewById<RadioButton>(R.id.rbSeek30).isChecked = true
            else -> view.findViewById<RadioButton>(R.id.rbSeek10).isChecked = true
        }

        // --- Change Listeners ---
        switchAutoPlayNext.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isAutoPlayNextEnabled = isChecked
            onSettingsUpdated()
        }

        switchBackgroundAudio.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isBackgroundAudioEnabled = isChecked
            onSettingsUpdated()
        }

        switchSwipeScreenshot.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isSwipeScreenshotEnabled = isChecked
            onSettingsUpdated()
        }

        switchBrightness.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isBrightnessGestureEnabled = isChecked
            onSettingsUpdated()
        }

        switchVolume.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isVolumeGestureEnabled = isChecked
            onSettingsUpdated()
        }

        switchScrubbing.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isHorizontalScrubEnabled = isChecked
            onSettingsUpdated()
        }

        switchDoubleTapSeek.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isDoubleTapSeekEnabled = isChecked
            onSettingsUpdated()
        }

        switchLongPress2x.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isLongPress2xEnabled = isChecked
            onSettingsUpdated()
        }

        switchSpeedDragLock.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isSpeedDragLockEnabled = isChecked
            onSettingsUpdated()
        }

        switchTwoFingerTracks.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isTwoFingerSwipeTracksEnabled = isChecked
            onSettingsUpdated()
        }

        switchTwoFingerLockToggle.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isTwoFingerLockToggleEnabled = isChecked
            onSettingsUpdated()
        }

        switchShowNextPrev.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showNextPrevButtons = isChecked
            onSettingsUpdated()
        }

        switchShowScreenshotBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showScreenshotButton = isChecked
            onSettingsUpdated()
        }

        switchShowAspectRatioBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showAspectRatioButton = isChecked
            onSettingsUpdated()
        }

        switchShowOrientationBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showOrientationButton = isChecked
            onSettingsUpdated()
        }

        switchShowPipBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showPipButton = isChecked
            onSettingsUpdated()
        }

        switchShowSpeedBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showSpeedButton = isChecked
            onSettingsUpdated()
        }

        switchShowDecoderBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showDecoderToggleButton = isChecked
            onSettingsUpdated()
        }

        switchShowBackgroundAudioBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showBackgroundAudioButton = isChecked
            onSettingsUpdated()
        }

        switchShowTracksBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showTracksButton = isChecked
            onSettingsUpdated()
        }

        switchShowLockBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showLockButton = isChecked
            onSettingsUpdated()
        }

        switchLockAllowVolume.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.lockAllowVolume = isChecked
            onSettingsUpdated()
        }

        switchLockAllowBrightness.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.lockAllowBrightness = isChecked
            onSettingsUpdated()
        }

        switchLockAllowSeek.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.lockAllowSeek = isChecked
            onSettingsUpdated()
        }

        switchLockAllowScreenshot.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.lockAllowScreenshot = isChecked
            onSettingsUpdated()
        }

        switchLockAllowZoom.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.lockAllowZoom = isChecked
            onSettingsUpdated()
        }

        switchLockAllowLongPress2x.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.lockAllowLongPress2x = isChecked
            onSettingsUpdated()
        }

        switchLockAllowSpeedDragLock.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.lockAllowSpeedDragLock = isChecked
            onSettingsUpdated()
        }

        switchLockAllowTwoFingerTracks.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.lockAllowTwoFingerTracks = isChecked
            onSettingsUpdated()
        }

        switchLockAllowTwoFingerUnlock.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.lockAllowTwoFingerUnlock = isChecked
            onSettingsUpdated()
        }

        rgSeekDuration.setOnCheckedChangeListener { _, checkedId ->
            val seconds = when (checkedId) {
                R.id.rbSeek5 -> 5
                R.id.rbSeek15 -> 15
                R.id.rbSeek30 -> 30
                else -> 10
            }
            appPreferences.doubleTapSeekSeconds = seconds
            onSettingsUpdated()
        }

        dialog.show()
    }
}