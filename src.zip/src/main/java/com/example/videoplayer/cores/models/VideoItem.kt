package com.example.videoplayer.cores.models

import android.content.ContentUris
import android.net.Uri
import android.provider.MediaStore

/**
 * =========================================================================
 * DATA CLASS: VideoItem
 * PACKAGE: com.example.videoplayer.cores.models
 * DESCRIPTION: Unified core data model representing a video file across all
 *              pipeline layers: MediaStore scanning, disk chunking, K-Way
 *              heap sorting, Room watch status lookup, and UI rendering.
 * =========================================================================
 */
data class VideoItem(
    val id: Long,
    val title: String,
    val path: String,
    val durationMs: Long,
    val sizeBytes: Long = 0L,
    val dateModified: Long = 0L
) {
    /**
     * On-demand Content Uri builder.
     * Avoids holding heavy android.net.Uri objects in heap memory during
     * large batch processing of 100k+ media records.
     */
    val uri: Uri
        get() = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
}