package com.example.videoplayer.cores.locals

import com.example.videoplayer.cores.models.VideoItem
import com.example.videoplayer.utils.AppFunc
import com.example.videoplayer.utils.NaturalSortComparator
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.util.PriorityQueue

/**
 * =========================================================================
 * CLASS: KWayMergeStreamer
 * PACKAGE: com.example.videoplayer.cores.locals
 * DESCRIPTION: Executes an external K-Way merge sort over sorted disk chunks
 *              using an in-memory Min-Heap (PriorityQueue). Maintains open
 *              BufferedReader file descriptors and advances them on demand.
 * =========================================================================
 */
class KWayMergeStreamer {

    /**
     * Internal container linking an active chunk reader to its next queued item.
     */
    private data class HeapNode(
        val item: VideoItem,
        val readerIndex: Int
    )

    private val readers = ArrayList<BufferedReader>()
    private var minHeap: PriorityQueue<HeapNode>? = null

    /**
     * -------------------------------------------------------------------------
     * Function: initialize
     * Description: Opens BufferedReaders for all chunk partitions, primes the
     *              Min-Heap with the first item from each chunk, and configures
     *              the priority comparator.
     * Input: chunkFiles (List<File>) - List of sorted chunk files on disk.
     *        sortMode (Int) - Target sorting mode constant.
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun initialize(chunkFiles: List<File>, sortMode: Int) {
        closeAll()

        val comparator = NaturalSortComparator.getComparator(sortMode)
        val heap = PriorityQueue<HeapNode> { nodeA, nodeB ->
            comparator.compare(nodeA.item, nodeB.item)
        }
        minHeap = heap

        for (index in chunkFiles.indices) {
            val file = chunkFiles[index]
            if (!file.exists() || file.length() == 0L) continue

            // 16KB native buffer per active chunk reader
            val reader = BufferedReader(FileReader(file), 16 * 1024)
            readers.add(reader)

            // Prime the heap with the initial line from this chunk file
            val firstLine = reader.readLine()
            if (firstLine != null) {
                val item = AppFunc.parseChunkLine(firstLine)
                if (item != null) {
                    heap.add(HeapNode(item, readers.size - 1))
                }
            }
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: fetchNextPage
     * Description: Polls the lowest items from the Min-Heap. For every element
     *              polled, advances the corresponding chunk stream by one row.
     * Input: pageSize (Int) - Number of items to retrieve (default: 50).
     * Output: List<VideoItem> - Next sorted page of video items.
     * -------------------------------------------------------------------------
     */
    @Synchronized
    fun fetchNextPage(pageSize: Int = 50): List<VideoItem> {
        val heap = minHeap ?: return emptyList()
        val result = ArrayList<VideoItem>(pageSize)

        while (result.size < pageSize && heap.isNotEmpty()) {
            val top = heap.poll() ?: break
            result.add(top.item)

            // Refill the heap with the subsequent line from the polled reader
            val reader = readers[top.readerIndex]
            val nextLine = reader.readLine()

            if (nextLine != null) {
                val nextItem = AppFunc.parseChunkLine(nextLine)
                if (nextItem != null) {
                    heap.add(HeapNode(nextItem, top.readerIndex))
                }
            }
        }

        return result
    }

    /**
     * -------------------------------------------------------------------------
     * Function: hasMore
     * Description: Checks if there are remaining unmerged items inside the Min-Heap.
     * Input: None
     * Output: Boolean - True if unread items remain, false if all chunks exhausted.
     * -------------------------------------------------------------------------
     */
    fun hasMore(): Boolean = minHeap?.isNotEmpty() == true

    /**
     * -------------------------------------------------------------------------
     * Function: closeAll
     * Description: Closes all active BufferedReader file streams and releases
     *              Min-Heap memory allocations.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun closeAll() {
        minHeap?.clear()
        minHeap = null
        for (reader in readers) {
            try {
                reader.close()
            } catch (_: Exception) {}
        }
        readers.clear()
    }
}