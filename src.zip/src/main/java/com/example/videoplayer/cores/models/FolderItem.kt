package com.example.videoplayer.cores.models

/**
 * =========================================================================
 * DATA CLASS: FolderItem
 * PACKAGE: com.example.videoplayer.cores.models
 * DESCRIPTION: Represents a local directory containing supported video files.
 * =========================================================================
 */
data class FolderItem(
    val folderPath: String,
    val folderName: String,
    val videoCount: Int
)