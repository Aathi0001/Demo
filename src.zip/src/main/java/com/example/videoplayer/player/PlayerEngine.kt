package com.example.videoplayer.player

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.ui.PlayerView
import com.example.videoplayer.config.GeneralConfig

class PlayerEngine(
    private val context: Context,
    private val playerView: PlayerView,
    private val onPlaybackEnded: () -> Unit
) {
    var exoPlayer: ExoPlayer? = null
        private set

    init {
        initializePlayer()
    }

    private fun initializePlayer() {
        val renderersFactory = DefaultRenderersFactory(context)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            .setEnableDecoderFallback(true) // Enables fallback if hardware HEVC codec crashes
            .setMediaCodecSelector(MediaCodecSelector.DEFAULT)

        val loadControl = LowRamLoadControl.create()

        exoPlayer = ExoPlayer.Builder(context, renderersFactory)
            .setLoadControl(loadControl)
            .setSeekParameters(SeekParameters.CLOSEST_SYNC)
            .build()
            .apply {
                playerView.player = this
                addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_ENDED) {
                            onPlaybackEnded()
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        error.printStackTrace()
                    }
                })
            }
    }

    fun playMedia(uri: Uri, startPositionMs: Long = 0L) {
        exoPlayer?.let { player ->
            val mediaItem = MediaItem.fromUri(uri)
            player.setMediaItem(mediaItem)
            if (startPositionMs > 0L) {
                player.seekTo(startPositionMs)
            }
            player.prepare()
            player.playWhenReady = true
        }
    }

    fun togglePlayPause(): Boolean {
        exoPlayer?.let {
            if (it.isPlaying) {
                it.pause()
                return false
            } else {
                it.play()
                return true
            }
        }
        return false
    }

    fun seekRelative(deltaMs: Long): Long {
        exoPlayer?.let { player ->
            val target = (player.currentPosition + deltaMs).coerceIn(0L, player.duration.coerceAtLeast(0L))
            player.seekTo(target)
            return target
        }
        return 0L
    }

    fun setPlaybackSpeed(speed: Float) {
        val validSpeed = if (speed in GeneralConfig.PLAYBACK_SPEED_PRESETS) speed else GeneralConfig.DEFAULT_PLAYBACK_SPEED
        exoPlayer?.playbackParameters = PlaybackParameters(validSpeed)
    }

    fun release() {
        exoPlayer?.let {
            it.stop()
            it.clearMediaItems()
            it.release()
        }
        exoPlayer = null
        playerView.player = null
    }
}