package com.example.videoplayer.config

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

/**
 * =========================================================================
 * 1. RAW COLOR PALETTE (Hex values)
 * =========================================================================
 */
object RawColors {
    val PureBlack           = Color(0xFF000000)
    val PureWhite           = Color(0xFFFFFFFF)
    val Transparent         = Color(0x00000000)

    val DarkBackground      = Color(0xFF121212)
    val DarkSurface         = Color(0xFF1E1E1E)
    val DarkSurfaceVariant  = Color(0xFF2C2C2C)
    val DarkBorder          = Color(0xFF383838)
    val DarkTextPrimary     = Color(0xFFEDEDED)
    val DarkTextSecondary   = Color(0xFFA0A0A0)

    val LightBackground     = Color(0xFFF8F9FA)
    val LightSurface        = Color(0xFFFFFFFF)
    val LightSurfaceVariant = Color(0xFFE9ECEF)
    val LightBorder         = Color(0xFFDEE2E6)
    val LightTextPrimary    = Color(0xFF212529)
    val LightTextSecondary  = Color(0xFF6C757D)

    val OledBackground      = Color(0xFF000000)
    val OledSurface         = Color(0xFF0D0D0D)
    val OledSurfaceVariant  = Color(0xFF171717)
    val OledBorder          = Color(0xFF262626)

    val AccentRed           = Color(0xFFFF5252)
    val AccentBlue          = Color(0xFF448AFF)
    val SuccessGreen        = Color(0xFF4CAF50)
    val WarningYellow       = Color(0xFFFFC107)
    val ErrorRed            = Color(0xFFCF6679)

    val OverlayScrim        = Color(0x99000000)
    val OverlayScrimHeavy   = Color(0xCC000000)
    val OverlayGestureHud   = Color(0xB3000000)
}

/**
 * =========================================================================
 * 2. SEMANTIC COLOR CONTRACT
 * =========================================================================
 */
data class AppColorScheme(
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val border: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val accent: Color,
    val seekIndicator: Color,
    val overlayBackground: Color,
    val overlayDialog: Color,
    val gestureHudBackground: Color,
    val success: Color,
    val error: Color
)

/**
 * =========================================================================
 * 3. THEME DEFINITIONS
 * =========================================================================
 */
val DarkThemeColors = AppColorScheme(
    background = RawColors.DarkBackground,
    surface = RawColors.DarkSurface,
    surfaceVariant = RawColors.DarkSurfaceVariant,
    border = RawColors.DarkBorder,
    textPrimary = RawColors.DarkTextPrimary,
    textSecondary = RawColors.DarkTextSecondary,
    accent = RawColors.AccentRed,
    seekIndicator = RawColors.AccentBlue,
    overlayBackground = RawColors.OverlayScrim,
    overlayDialog = RawColors.OverlayScrimHeavy,
    gestureHudBackground = RawColors.OverlayGestureHud,
    success = RawColors.SuccessGreen,
    error = RawColors.ErrorRed
)

val LightThemeColors = AppColorScheme(
    background = RawColors.LightBackground,
    surface = RawColors.LightSurface,
    surfaceVariant = RawColors.LightSurfaceVariant,
    border = RawColors.LightBorder,
    textPrimary = RawColors.LightTextPrimary,
    textSecondary = RawColors.LightTextSecondary,
    accent = RawColors.AccentRed,
    seekIndicator = RawColors.AccentBlue,
    overlayBackground = RawColors.OverlayScrim,
    overlayDialog = RawColors.OverlayScrimHeavy,
    gestureHudBackground = RawColors.OverlayGestureHud,
    success = RawColors.SuccessGreen,
    error = RawColors.ErrorRed
)

val OledBlackThemeColors = AppColorScheme(
    background = RawColors.OledBackground,
    surface = RawColors.OledSurface,
    surfaceVariant = RawColors.OledSurfaceVariant,
    border = RawColors.OledBorder,
    textPrimary = RawColors.PureWhite,
    textSecondary = RawColors.DarkTextSecondary,
    accent = RawColors.AccentRed,
    seekIndicator = RawColors.AccentBlue,
    overlayBackground = RawColors.OverlayScrimHeavy,
    overlayDialog = RawColors.OverlayScrimHeavy,
    gestureHudBackground = RawColors.OverlayGestureHud,
    success = RawColors.SuccessGreen,
    error = RawColors.ErrorRed
)

/**
 * =========================================================================
 * 4. THEME CONTROLLER & REGISTRY
 * =========================================================================
 */
enum class ThemeMode {
    DARK,
    LIGHT,
    OLED_BLACK
}

object ThemeManager {
    val themeRegistry: Map<ThemeMode, AppColorScheme> = mapOf(
        ThemeMode.DARK to DarkThemeColors,
        ThemeMode.LIGHT to LightThemeColors,
        ThemeMode.OLED_BLACK to OledBlackThemeColors
    )

    var currentMode: ThemeMode = ThemeMode.DARK

    val colors: AppColorScheme
        get() = themeRegistry[currentMode] ?: DarkThemeColors
}

val AppColorScheme.backgroundArgb: Int get() = background.toArgb()
val AppColorScheme.surfaceArgb: Int get() = surface.toArgb()
val AppColorScheme.textPrimaryArgb: Int get() = textPrimary.toArgb()
val AppColorScheme.textSecondaryArgb: Int get() = textSecondary.toArgb()
val AppColorScheme.accentArgb: Int get() = accent.toArgb()