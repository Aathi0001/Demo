package com.example.videoplayer.configs

/**
 * =========================================================================
 * OBJECT: GeneralConfig
 * PACKAGE: com.example.videoplayer.configs
 * DESCRIPTION: Static thresholds, buffer limits, gesture sensitivity,
 *              playback speeds, zoom constraints, and chunking parameters.
 * =========================================================================
 */
object GeneralConfig {

    // =========================================================================
    // 1. MEMORY & LOW-RAM PLAYBACK BUFFER LIMITS (Media3 / ExoPlayer)
    // =========================================================================
    const val BUFFER_MIN_MS: Int = 2_500          // 2.5s minimum buffer
    const val BUFFER_MAX_MS: Int = 10_000         // 10s maximum buffer
    const val BUFFER_PLAY_START_MS: Int = 1_000   // Starts playback after 1s buffered
    const val BUFFER_REBUFFER_MS: Int = 2_000     // Buffer after rebuffer: 2s
    const val BUFFER_TARGET_SIZE_BYTES: Int = androidx.media3.common.C.LENGTH_UNSET

    // =========================================================================
    // 2. SEEKING & TIMING CONTROLS
    // =========================================================================
    const val DOUBLE_TAP_SEEK_MS: Long = 10_000L   // 10-second skip per double-tap
    const val DEBOUNCE_SEEK_DELAY_MS: Long = 200L  // Throttle time for rapid consecutive taps
    const val CONTROLS_HIDE_TIMEOUT_MS: Long = 3_500L // Auto-hide controls after 3.5s

    // =========================================================================
    // 3. GESTURE & TOUCH SENSITIVITIES
    // =========================================================================
    const val SWIPE_SENSITIVITY: Float = 0.005f    // Speed ratio for vertical drag
    const val GESTURE_BORDER_PADDING_PX: Float = 48f // Margin to avoid OS edge gesture conflicts
    const val MIN_PINCH_SCALE: Float = 1.0f        // Default 100% Fit scale
    const val MAX_PINCH_SCALE: Float = 3.0f        // 300% Maximum zoom-in scale

    // =========================================================================
    // 4. PLAYBACK SPEEDS
    // =========================================================================
    val PLAYBACK_SPEED_PRESETS: List<Float> = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
    const val DEFAULT_PLAYBACK_SPEED: Float = 1.0f

    // =========================================================================
    // 5. SCREENSHOT ENGINE CONFIGURATION
    // =========================================================================
    const val SCREENSHOT_QUEUE_CAPACITY: Int = 10
    const val SCREENSHOT_JPEG_QUALITY: Int = 95
    const val SCREENSHOT_FILE_EXTENSION: String = ".jpg"
    const val SCREENSHOT_MIME_TYPE: String = "image/jpeg"
    const val SCREENSHOT_FOLDER_NAME: String = "Captures"

    // =========================================================================
    // 6. DATABASE & WATCH PROGRESS POLICIES
    // =========================================================================
    const val DATABASE_NAME: String = "video_player.db"
    const val DATABASE_VERSION: Int = 1
    const val COMPLETION_PERCENTAGE: Float = 0.95f // 95% triggers watched tick (✓)

    // =========================================================================
    // 7. RAM & CHUNK CONSTRAINTS (100k+ Files Support)
    // =========================================================================
    const val CHUNK_MAX_BYTE_LIMIT: Long = 4 * 1024 * 1024L // 4 MB safety ceiling
    const val CHUNK_MAX_ITEM_LIMIT: Int = 15_000            // Max items per chunk file
    const val IN_MEMORY_SORT_THRESHOLD: Int = 10_000       // Under 10k: sort directly in RAM
    const val SORT_CACHE_DIR: String = "sort_cache"
    const val CHUNK_LINE_DELIMITER: String = "\t"          // Tab delimiter (safe from filenames)

    // =========================================================================
    // 8. COMPLETE SORT MODES
    // =========================================================================
    // 1. Natural Sort (Human readable: Ep 2 < Ep 10)
    const val SORT_NATURAL_ASC: Int = 0
    const val SORT_NATURAL_DESC: Int = 1

    // 2. Standard Alphabetical Sort (ASCII: Ep 10 < Ep 2)
    const val SORT_NAME_ASC: Int = 2
    const val SORT_NAME_DESC: Int = 3

    // 3. Date Modified
    const val SORT_DATE_DESC: Int = 4
    const val SORT_DATE_ASC: Int = 5

    // 4. File Size
    const val SORT_SIZE_DESC: Int = 6
    const val SORT_SIZE_ASC: Int = 7

    // 5. Video Duration
    const val SORT_DURATION_DESC: Int = 8
    const val SORT_DURATION_ASC: Int = 9
}