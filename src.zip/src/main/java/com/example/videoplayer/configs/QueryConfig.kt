package com.example.videoplayer.configs

import android.net.Uri
import android.os.Environment
import android.provider.MediaStore

/**
 * =========================================================================
 * OBJECT: QueryConfig
 * PACKAGE: com.example.videoplayer.configs
 * DESCRIPTION: MediaStore projections, file filters, scoped storage paths,
 *              table names, and compile-time Room SQL queries.
 * =========================================================================
 */
object QueryConfig {

    // =========================================================================
    // 1. MEDIASTORE VIDEO QUERY CONFIGURATION
    // =========================================================================
    val VIDEO_CONTENT_URI: Uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

    val VIDEO_PROJECTION: Array<String> = arrayOf(
        MediaStore.Video.Media._ID,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.Media.DURATION,
        MediaStore.Video.Media.SIZE,
        MediaStore.Video.Media.DATA,          // Absolute file path
        MediaStore.Video.Media.DATE_MODIFIED
    )

    const val VIDEO_SORT_ORDER: String = "${MediaStore.Video.Media.DATE_MODIFIED} DESC"
    const val VIDEO_SELECTION: String = "${MediaStore.Video.Media.DURATION} > 0"

    // =========================================================================
    // 2. SUPPORTED EXTENSIONS
    // =========================================================================
    val SUPPORTED_VIDEO_EXTENSIONS: Set<String> = setOf(
        "mp4", "mkv", "webm", "avi", "3gp", "ts", "m4v", "mov", "flv"
    )

    val SUPPORTED_SUBTITLE_EXTENSIONS: Set<String> = setOf(
        "srt", "ass", "ssa", "vtt"
    )

    // =========================================================================
    // 3. SCREENSHOT OUTPUT DIRECTORY (SCOPED STORAGE)
    // =========================================================================
    val RELATIVE_SCREENSHOT_PATH: String =
        "${Environment.DIRECTORY_PICTURES}/${GeneralConfig.SCREENSHOT_FOLDER_NAME}"

    val LEGACY_SCREENSHOT_PATH: String =
        "${Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)}/${GeneralConfig.SCREENSHOT_FOLDER_NAME}"

    // =========================================================================
    // 4. ROOM DATABASE TABLE NAMES
    // =========================================================================
    const val TABLE_WATCH_PROGRESS: String = "watch_progress"
    const val TABLE_FOLDER_SORT: String = "folder_sort"

    // =========================================================================
    // 5. ROOM COMPILE-TIME SQL QUERIES
    // =========================================================================
    const val GET_WATCH_PROGRESS_BY_PATH: String =
        "SELECT * FROM $TABLE_WATCH_PROGRESS WHERE video_path = :path LIMIT 1"

    const val GET_ALL_WATCH_PROGRESS: String =
        "SELECT * FROM $TABLE_WATCH_PROGRESS"

    const val DELETE_WATCH_PROGRESS_BY_PATH: String =
        "DELETE FROM $TABLE_WATCH_PROGRESS WHERE video_path = :path"

    const val PRUNE_WATCH_PROGRESS: String = """
        DELETE FROM $TABLE_WATCH_PROGRESS 
        WHERE video_path NOT IN (
            SELECT video_path FROM $TABLE_WATCH_PROGRESS 
            ORDER BY last_watched_at DESC 
            LIMIT 1000
        )
    """

    const val GET_FOLDER_SORT: String =
        "SELECT sort_mode FROM $TABLE_FOLDER_SORT WHERE folder_path = :folderPath LIMIT 1"

    const val DELETE_FOLDER_SORT: String =
        "DELETE FROM $TABLE_FOLDER_SORT WHERE folder_path = :folderPath"

    const val PRUNE_FOLDER_SORTS: String = """
        DELETE FROM $TABLE_FOLDER_SORT 
        WHERE folder_path NOT IN (
            SELECT folder_path FROM $TABLE_FOLDER_SORT 
            ORDER BY updated_at DESC 
            LIMIT 500
        )
    """
}