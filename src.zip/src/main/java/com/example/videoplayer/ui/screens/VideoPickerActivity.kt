package com.example.videoplayer.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.videoplayer.R
import com.example.videoplayer.configs.GeneralConfig
import com.example.videoplayer.configs.ThemeManager
import com.example.videoplayer.configs.ThemeMode
import com.example.videoplayer.cores.locals.AppPreferences
import com.example.videoplayer.cores.locals.DatabaseManager
import com.example.videoplayer.cores.locals.VideoRepository
import com.example.videoplayer.cores.models.FolderItem
import com.example.videoplayer.cores.player.SettingsHelper
import com.example.videoplayer.ui.adapters.VideoPickerAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * =========================================================================
 * CLASS: VideoPickerActivity
 * PACKAGE: com.example.videoplayer.ui.screens
 * DESCRIPTION: Primary media explorer activity coordinating folder navigation,
 *              theme switching, multi-modal sorting dialogs, and external
 *              chunk paging via FolderViewModel with auto-fill large screen support.
 * =========================================================================
 */
class VideoPickerActivity : AppCompatActivity() {

    private val folderViewModel: FolderViewModel by viewModels()
    private lateinit var repo: VideoRepository
    private lateinit var dbManager: DatabaseManager
    private lateinit var adapter: VideoPickerAdapter
    private lateinit var appPreferences: AppPreferences

    private lateinit var rootLayout: View
    private lateinit var tvHeaderTitle: TextView
    private lateinit var btnSort: ImageButton
    private lateinit var btnToggleTheme: ImageButton
    private lateinit var btnSettings: ImageButton
    private lateinit var tvEmptyState: TextView
    private lateinit var rvMediaList: RecyclerView

    private var currentFolder: FolderItem? = null
    private var activeSortMode: Int = GeneralConfig.SORT_NATURAL_ASC

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video_picker)

        appPreferences = AppPreferences(this)
        repo = VideoRepository(this)
        dbManager = DatabaseManager.getInstance(this)

        rootLayout = findViewById(R.id.rootPickerLayout)
        tvHeaderTitle = findViewById(R.id.tvHeaderTitle)
        btnSort = findViewById(R.id.btnSort)
        btnToggleTheme = findViewById(R.id.btnToggleTheme)
        btnSettings = findViewById(R.id.btnSettings)
        tvEmptyState = findViewById(R.id.tvEmptyState)
        rvMediaList = findViewById(R.id.rvMediaList)

        val layoutManager = LinearLayoutManager(this)
        rvMediaList.layoutManager = layoutManager

        adapter = VideoPickerAdapter(
            onFolderClick = { folder ->
                openFolder(folder)
            },
            onVideoClick = { video ->
                val intent = Intent(this, PlayerActivity::class.java).apply {
                    data = video.uri
                    putExtra("VIDEO_TITLE", video.title)
                    putExtra("VIDEO_PATH", video.path)
                    putExtra("FOLDER_PATH", video.path.substringBeforeLast('/', ""))
                }
                startActivity(intent)
            }
        )
        rvMediaList.adapter = adapter

        // Infinite scroll pagination listener for 10,000+ chunked folders
        rvMediaList.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                if (currentFolder != null && dy > 0) {
                    val visibleItemCount = layoutManager.childCount
                    val totalItemCount = layoutManager.itemCount
                    val firstVisibleItemPosition = layoutManager.findFirstVisibleItemPosition()

                    if ((visibleItemCount + firstVisibleItemPosition) >= totalItemCount - 10) {
                        folderViewModel.loadNextPage(pageSize = 50)
                    }
                }
            }
        })

        // Observe paged videos from FolderViewModel with Viewport Auto-Fill
        folderViewModel.videoList.observe(this) { videos ->
            if (currentFolder != null) {
                tvEmptyState.visibility = if (videos.isEmpty()) View.VISIBLE else View.GONE
                adapter.setVideos(videos)

                // Ensures large screens/tablets/foldables fill the viewport enough to enable scroll
                rvMediaList.post {
                    if (!rvMediaList.canScrollVertically(1) && 
                        videos.isNotEmpty() && 
                        folderViewModel.isLoading.value != true
                    ) {
                        folderViewModel.loadNextPage(pageSize = 50)
                    }
                }
            }
        }

        // Sort Dialog Trigger
        btnSort.setOnClickListener {
            showSortSelectionDialog()
        }

        // Theme toggle button action: DARK -> LIGHT -> OLED_BLACK -> DARK
        btnToggleTheme.setOnClickListener {
            ThemeManager.currentMode = when (ThemeManager.currentMode) {
                ThemeMode.DARK -> ThemeMode.LIGHT
                ThemeMode.LIGHT -> ThemeMode.OLED_BLACK
                ThemeMode.OLED_BLACK -> ThemeMode.DARK
            }
            applyThemeColors()
            adapter.notifyDataSetChanged()
        }

        // Settings button action
        btnSettings.setOnClickListener {
            SettingsHelper.showSettingsDialog(this, appPreferences) {
                // Refresh if needed
            }
        }

        // Back press handling
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (currentFolder != null) {
                    currentFolder = null
                    btnSort.visibility = View.GONE
                    loadFolders()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        applyThemeColors()
        checkPermissionsAndLoad()
    }

    /**
     * -------------------------------------------------------------------------
     * Function: openFolder
     * Description: Resolves folder sort mode and triggers chunking pipeline.
     * Input: folder (FolderItem)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun openFolder(folder: FolderItem) {
        currentFolder = folder
        tvHeaderTitle.text = folder.folderName
        btnSort.visibility = View.VISIBLE

        lifecycleScope.launch(Dispatchers.IO) {
            val savedSort = dbManager.getFolderSortMode(folder.folderPath)
            activeSortMode = savedSort ?: GeneralConfig.SORT_NATURAL_ASC

            withContext(Dispatchers.Main) {
                val bucketId = folder.folderPath.hashCode().toString()
                folderViewModel.loadFolderVideos(bucketId, activeSortMode)
            }
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: showSortSelectionDialog
     * Description: Presents modal dialog allowing user to choose sort dimension.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun showSortSelectionDialog() {
        val sortOptions = arrayOf(
            "Natural (Ep 1, Ep 2, Ep 10)",
            "Natural Descending",
            "Name (A to Z)",
            "Name (Z to A)",
            "Date Modified (Newest first)",
            "Date Modified (Oldest first)",
            "File Size (Largest first)",
            "File Size (Smallest first)",
            "Duration (Longest first)",
            "Duration (Shortest first)"
        )

        val sortConstants = intArrayOf(
            GeneralConfig.SORT_NATURAL_ASC,
            GeneralConfig.SORT_NATURAL_DESC,
            GeneralConfig.SORT_NAME_ASC,
            GeneralConfig.SORT_NAME_DESC,
            GeneralConfig.SORT_DATE_DESC,
            GeneralConfig.SORT_DATE_ASC,
            GeneralConfig.SORT_SIZE_DESC,
            GeneralConfig.SORT_SIZE_ASC,
            GeneralConfig.SORT_DURATION_DESC,
            GeneralConfig.SORT_DURATION_ASC
        )

        val currentIndex = sortConstants.indexOf(activeSortMode).coerceAtLeast(0)

        AlertDialog.Builder(this)
            .setTitle("Sort Videos By")
            .setSingleChoiceItems(sortOptions, currentIndex) { dialog, which ->
                val selectedMode = sortConstants[which]
                dialog.dismiss()

                if (selectedMode != activeSortMode) {
                    activeSortMode = selectedMode
                    currentFolder?.let { folder ->
                        lifecycleScope.launch(Dispatchers.IO) {
                            dbManager.saveFolderSortMode(folder.folderPath, selectedMode)
                        }
                        val bucketId = folder.folderPath.hashCode().toString()
                        folderViewModel.loadFolderVideos(bucketId, selectedMode)
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /**
     * -------------------------------------------------------------------------
     * Function: applyThemeColors
     * Description: Dynamically adjusts palette colors across header and icons.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun applyThemeColors() {
        val colors = ThemeManager.colors
        rootLayout.setBackgroundColor(colors.backgroundArgb)
        tvHeaderTitle.setTextColor(colors.textPrimaryArgb)
        btnSort.setColorFilter(colors.textPrimaryArgb)
        btnToggleTheme.setColorFilter(colors.textPrimaryArgb)
        btnSettings.setColorFilter(colors.textPrimaryArgb)
        tvEmptyState.setTextColor(colors.textSecondaryArgb)
    }

    private fun checkPermissionsAndLoad() {
        val permission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_VIDEO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            loadFolders()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(permission), 101)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            loadFolders()
        } else {
            Toast.makeText(this, "Permission required to load videos", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: loadFolders
     * Description: Populates adapter with folder list from repository.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun loadFolders() {
        lifecycleScope.launch {
            val folders = repo.getAllFoldersWithVideos()
            tvHeaderTitle.text = "Video Folders"
            tvEmptyState.visibility = if (folders.isEmpty()) View.VISIBLE else View.GONE
            adapter.setFolders(folders)
        }
    }
}