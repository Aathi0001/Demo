package com.example.videoplayer.ui.screens

import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.widget.Button
import android.widget.TextView
import com.example.videoplayer.R
import com.example.videoplayer.cores.player.PlayerEngine

/**
 * =========================================================================
 * OBJECT: SyncAdjustmentDialog
 * PACKAGE: com.example.videoplayer.ui.screens
 * DESCRIPTION: Interactive modal dialog allowing real-time millisecond
 *              adjustments for subtitle and audio stream synchronization.
 * =========================================================================
 */
object SyncAdjustmentDialog {

    /**
     * -------------------------------------------------------------------------
     * Function: show
     * Description: Inflates and renders subtitle/audio sync adjustment controls.
     * Input: context (Context), playerEngine (PlayerEngine), onDismiss (() -> Unit)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun show(context: Context, playerEngine: PlayerEngine, onDismiss: () -> Unit) {
        val view = LayoutInflater.from(context).inflate(R.layout.dialog_sync_adjustment, null)

        val tvSubDelay = view.findViewById<TextView>(R.id.tvSubtitleDelayValue)
        val tvAudioDelay = view.findViewById<TextView>(R.id.tvAudioDelayValue)

        var subDelay = playerEngine.subtitleDelayMs
        var audioDelay = playerEngine.audioDelayMs

        fun updateTexts() {
            tvSubDelay.text = "${subDelay} ms"
            tvAudioDelay.text = "${audioDelay} ms"
        }
        updateTexts()

        view.findViewById<Button>(R.id.btnSubMinus).setOnClickListener {
            subDelay -= 50
            playerEngine.setSubtitleDelay(subDelay)
            updateTexts()
        }
        view.findViewById<Button>(R.id.btnSubPlus).setOnClickListener {
            subDelay += 50
            playerEngine.setSubtitleDelay(subDelay)
            updateTexts()
        }

        view.findViewById<Button>(R.id.btnAudioMinus).setOnClickListener {
            audioDelay -= 50
            playerEngine.setAudioDelay(audioDelay)
            updateTexts()
        }
        view.findViewById<Button>(R.id.btnAudioPlus).setOnClickListener {
            audioDelay += 50
            playerEngine.setAudioDelay(audioDelay)
            updateTexts()
        }

        AlertDialog.Builder(context)
            .setTitle("Audio & Subtitle Sync")
            .setView(view)
            .setPositiveButton("Done") { d, _ ->
                d.dismiss()
                onDismiss()
            }
            .setNeutralButton("Reset") { _, _ ->
                playerEngine.setSubtitleDelay(0)
                playerEngine.setAudioDelay(0)
                onDismiss()
            }
            .show()
    }
}