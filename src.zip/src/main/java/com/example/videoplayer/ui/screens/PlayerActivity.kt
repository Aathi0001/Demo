package com.example.videoplayer.ui.screens

import android.Manifest
import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.OpenableColumns
import android.util.Rational
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.ui.PlayerView
import com.example.videoplayer.R
import com.example.videoplayer.configs.GeneralConfig
import com.example.videoplayer.cores.locals.AppPreferences
import com.example.videoplayer.cores.locals.DatabaseManager
import com.example.videoplayer.cores.locals.VideoRepository
import com.example.videoplayer.cores.models.VideoItem
import com.example.videoplayer.cores.player.ActiveEngine
import com.example.videoplayer.cores.player.AudioNoisyReceiver
import com.example.videoplayer.cores.player.BackgroundAudioService
import com.example.videoplayer.cores.player.PlayerEngine
import com.example.videoplayer.cores.player.PlayerGestureCallback
import com.example.videoplayer.cores.player.PlayerGestureListener
import com.example.videoplayer.cores.player.ScreenshotPipeline
import com.example.videoplayer.cores.player.TrackSelectionHelper
import com.example.videoplayer.utils.GeneralFunc
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.videolan.libvlc.util.VLCVideoLayout

/**
 * =========================================================================
 * CLASS: PlayerActivity
 * PACKAGE: com.example.videoplayer.ui.screens
 * DESCRIPTION: Fullscreen media player activity coordinating ExoPlayer and
 *              LibVLC playback engines, touch gesture listeners, background
 *              audio service, picture-in-picture, and Room watch progress.
 * =========================================================================
 */
class PlayerActivity : AppCompatActivity(), PlayerGestureCallback {

    private lateinit var rootPlayerContainer: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var vlcVideoLayout: VLCVideoLayout
    private lateinit var playerEngine: PlayerEngine
    private lateinit var screenshotPipeline: ScreenshotPipeline
    private lateinit var dbManager: DatabaseManager
    private lateinit var audioNoisyReceiver: AudioNoisyReceiver
    private lateinit var appPreferences: AppPreferences
    private lateinit var videoRepository: VideoRepository

    // Background Audio Service State
    private var backgroundAudioService: BackgroundAudioService? = null
    private var isServiceBound = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as BackgroundAudioService.LocalBinder
            backgroundAudioService = binder.getService().apply {
                onPlayPauseAction = { runOnUiThread { togglePlayPauseState() } }
                onNextAction = { runOnUiThread { playNextVideo(false) } }
                onPrevAction = { runOnUiThread { playPreviousVideo() } }
                updateNotification(videoTitle, playerEngine.isPlaying)
            }
            isServiceBound = true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            backgroundAudioService = null
            isServiceBound = false
        }
    }

    // UI Overlays & Controls
    private lateinit var controlsOverlay: RelativeLayout
    private lateinit var touchLockOverlay: FrameLayout
    private lateinit var seekBar: SeekBar
    private lateinit var tvTimeCurrent: TextView
    private lateinit var tvTimeTotal: TextView
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnPrev: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var btnSpeed: Button
    private lateinit var btnScreenshot: ImageButton
    private lateinit var btnAspectRatio: ImageButton
    private lateinit var btnOrientation: ImageButton
    private lateinit var btnPip: ImageButton
    private lateinit var btnDecoderToggle: TextView
    private lateinit var btnBackgroundAudio: ImageButton
    private lateinit var btnTracks: ImageButton
    private lateinit var btnLock: ImageButton
    private lateinit var btnUnlock: ImageButton
    private lateinit var tvVideoTitle: TextView

    // Bottom Toast Replacement Pill
    private lateinit var tvBottomFeedback: TextView

    // Double-Tap Skip Overlays
    private lateinit var layoutRewindOverlay: LinearLayout
    private lateinit var tvRewindSeconds: TextView
    private lateinit var layoutForwardOverlay: LinearLayout
    private lateinit var tvForwardSeconds: TextView

    // Center Gesture HUD
    private lateinit var layoutGestureHud: View
    private lateinit var ivHudIcon: ImageView
    private lateinit var pbHudProgress: ProgressBar
    private lateinit var tvHudText: TextView

    // Playlist State
    private var playlist: List<VideoItem> = emptyList()
    private var currentPlaylistIndex: Int = -1
    private var currentFolder: String? = null
    private var videoUri: Uri? = null
    private var videoFilePath: String = ""
    private var videoTitle: String = "Video"
    private var isLocked: Boolean = false
    private var currentSpeedIndex = 2
    private var currentAspectIndex = 0
    private var currentOrientationMode = 0

    private var accumulatedForwardMs = 0L
    private var accumulatedRewindMs = 0L

    private var rapidScreenshotCount = 0
    private val resetScreenshotCounterRunnable = Runnable { rapidScreenshotCount = 0 }

    private var speedBeforeLongPress = 1.0f
    private var isSpeedLockedAt2x = false
    private val hideHandler = Handler(Looper.getMainLooper())
    private val hideControlsRunnable = Runnable { setControlsVisibility(false) }
    private val hideHudRunnable = Runnable { layoutGestureHud.visibility = View.GONE }
    private val hideBottomFeedbackRunnable = Runnable { tvBottomFeedback.visibility = View.GONE }
    private val hideForwardRunnable = Runnable {
        layoutForwardOverlay.visibility = View.GONE
        accumulatedForwardMs = 0L
    }
    private val hideRewindRunnable = Runnable {
        layoutRewindOverlay.visibility = View.GONE
        accumulatedRewindMs = 0L
    }

    private val progressHandler = Handler(Looper.getMainLooper())
    private val progressRunnable = object : Runnable {
        override fun run() {
            if (controlsOverlay.visibility == View.VISIBLE && playerEngine.isPlaying) {
                updateProgressNow()
                progressHandler.postDelayed(this, 1000)
            }
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: updateProgressNow
     * Description: Synchronizes seek bar position and formatted timestamps.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun updateProgressNow() {
        val current = playerEngine.currentPosition
        val total = playerEngine.duration.coerceAtLeast(0L)
        seekBar.max = total.toInt()
        seekBar.progress = current.toInt()
        tvTimeCurrent.text = GeneralFunc.formatDurationToTime(current)
        tvTimeTotal.text = GeneralFunc.formatDurationToTime(total)
    }

    private fun startProgressUpdates() {
        progressHandler.removeCallbacks(progressRunnable)
        updateProgressNow()
        progressHandler.postDelayed(progressRunnable, 1000)
    }

    private fun stopProgressUpdates() {
        progressHandler.removeCallbacks(progressRunnable)
    }

    private val subtitlePickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            try {
                contentResolver.takePersistableUriPermission(
                    it,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
            playerEngine.addSubtitleSource(it)
            showBottomFeedback("Subtitle attached: ${it.lastPathSegment ?: "External Subtitle"}", 800L)
        }
    }

    private val requestNotificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            startBackgroundAudioService()
        } else {
            showBottomFeedback("Notification permission required for background playback")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)

        appPreferences = AppPreferences(this)
        videoRepository = VideoRepository(this)
        dbManager = DatabaseManager.getInstance(this)

        hideSystemBars()

        videoUri = intent.data ?: (intent.getStringExtra("VIDEO_URI")?.let { Uri.parse(it) })
        videoFilePath = intent.getStringExtra("VIDEO_PATH") ?: (videoUri?.path ?: "")
        videoTitle = intent.getStringExtra("VIDEO_TITLE") ?: getFileNameFromUri(videoUri)
        currentFolder = intent.getStringExtra("FOLDER_PATH")

        initViews()
        applyUiPreferences()
        initPlayerAndPipelines()
        setupListeners()
        loadFolderPlaylist()
    }

    /**
     * -------------------------------------------------------------------------
     * Function: getFileNameFromUri
     * Description: Resolves display name from content resolver or fallback URI.
     * Input: uri (Uri?)
     * Output: String
     * -------------------------------------------------------------------------
     */
    private fun getFileNameFromUri(uri: Uri?): String {
        if (uri == null) return "Video"
        var name = "Video"
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1 && cursor.moveToFirst()) {
                        name = cursor.getString(nameIndex) ?: "Video"
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        if (name == "Video") {
            name = uri.lastPathSegment ?: "Video"
        }
        return name
    }

    /**
     * -------------------------------------------------------------------------
     * Function: hideSystemBars
     * Description: Hides status and navigation bars into immersive sticky mode.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun initViews() {
        rootPlayerContainer = findViewById(R.id.rootPlayerContainer)
        playerView = findViewById(R.id.playerView)
        vlcVideoLayout = findViewById(R.id.vlcVideoLayout)
        controlsOverlay = findViewById(R.id.controlsOverlay)
        touchLockOverlay = findViewById(R.id.touchLockOverlay)
        seekBar = findViewById(R.id.seekBarProgress)
        tvTimeCurrent = findViewById(R.id.tvTimeCurrent)
        tvTimeTotal = findViewById(R.id.tvTimeTotal)

        btnPlayPause = findViewById(R.id.btnPlayPause)
        btnPrev = findViewById(R.id.btnPrev)
        btnNext = findViewById(R.id.btnNext)
        btnSpeed = findViewById(R.id.btnSpeed)
        btnScreenshot = findViewById(R.id.btnScreenshot)
        btnAspectRatio = findViewById(R.id.btnAspectRatio)
        btnOrientation = findViewById(R.id.btnOrientation)
        btnPip = findViewById(R.id.btnPip)
        btnDecoderToggle = findViewById(R.id.btnDecoderToggle)
        btnBackgroundAudio = findViewById(R.id.btnBackgroundAudio)
        btnTracks = findViewById(R.id.btnTracks)
        btnLock = findViewById(R.id.btnLock)
        btnUnlock = findViewById(R.id.btnUnlock)

        tvVideoTitle = findViewById(R.id.tvVideoTitle)
        tvVideoTitle.text = videoTitle

        tvBottomFeedback = findViewById(R.id.tvBottomFeedback)

        layoutRewindOverlay = findViewById(R.id.layoutRewindOverlay)
        tvRewindSeconds = findViewById(R.id.tvRewindSeconds)
        layoutForwardOverlay = findViewById(R.id.layoutForwardOverlay)
        tvForwardSeconds = findViewById(R.id.tvForwardSeconds)

        layoutGestureHud = findViewById(R.id.layoutGestureHud)
        ivHudIcon = findViewById(R.id.ivHudIcon)
        pbHudProgress = findViewById(R.id.pbHudProgress)
        tvHudText = findViewById(R.id.tvHudText)
    }

    private fun applyUiPreferences() {
        val nextPrevVis = if (appPreferences.showNextPrevButtons) View.VISIBLE else View.GONE
        btnPrev.visibility = nextPrevVis
        btnNext.visibility = nextPrevVis

        btnScreenshot.visibility = if (appPreferences.showScreenshotButton) View.VISIBLE else View.GONE
        btnAspectRatio.visibility = if (appPreferences.showAspectRatioButton) View.VISIBLE else View.GONE
        btnOrientation.visibility = if (appPreferences.showOrientationButton) View.VISIBLE else View.GONE
        btnPip.visibility = if (appPreferences.showPipButton) View.VISIBLE else View.GONE
        btnSpeed.visibility = if (appPreferences.showSpeedButton) View.VISIBLE else View.GONE
        btnDecoderToggle.visibility = if (appPreferences.showDecoderToggleButton) View.VISIBLE else View.GONE
        btnBackgroundAudio.visibility = if (appPreferences.showBackgroundAudioButton) View.VISIBLE else View.GONE
        btnTracks.visibility = if (appPreferences.showTracksButton) View.VISIBLE else View.GONE
        btnLock.visibility = if (appPreferences.showLockButton) View.VISIBLE else View.GONE

        updateBackgroundAudioIcon()
    }

    private fun updateBackgroundAudioIcon() {
        if (appPreferences.isBackgroundAudioEnabled) {
            btnBackgroundAudio.setColorFilter(Color.parseColor("#FF5252"))
        } else {
            btnBackgroundAudio.setColorFilter(Color.parseColor("#EDEDED"))
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: initPlayerAndPipelines
     * Description: Prepares engine, audio receiver, and queries Room watch position.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun initPlayerAndPipelines() {
        playerEngine = PlayerEngine(
            this,
            playerView,
            vlcVideoLayout,
            onEngineChanged = { engine ->
                runOnUiThread {
                    btnDecoderToggle.text = if (engine == ActiveEngine.EXO_PLAYER) "HW" else "SW"
                    if (engine == ActiveEngine.LIB_VLC) {
                        showBottomFeedback("Switched to Software Decoder Engine", 800L)
                    } else {
                        showBottomFeedback("Switched to Hardware Decoder Engine", 800L)
                    }
                }
            },
            onPlaybackEnded = {
                handleVideoPlaybackFinished()
            }
        )

        screenshotPipeline = ScreenshotPipeline(this) { _, _ -> }

        audioNoisyReceiver = AudioNoisyReceiver {
            playerEngine.togglePlayPause()
            btnPlayPause.setImageResource(R.drawable.ic_play)
            backgroundAudioService?.updateNotification(videoTitle, false)
        }
        audioNoisyReceiver.register(this)

        lifecycleScope.launch(Dispatchers.IO) {
            val progressEntity = dbManager.getWatchProgress(videoFilePath)
            val savedPosition = if (progressEntity != null && !progressEntity.isCompleted) {
                progressEntity.lastPositionMs
            } else {
                0L
            }

            withContext(Dispatchers.Main) {
                videoUri?.let { playerEngine.playMedia(it, savedPosition) }
                startProgressUpdates()
            }
        }
    }

    private fun loadFolderPlaylist() {
        currentFolder?.let { path ->
            lifecycleScope.launch(Dispatchers.IO) {
                val videos = videoRepository.getVideosInFolder(path)
                val initialIndex = videos.indexOfFirst { it.uri == videoUri || it.path == videoFilePath }
                withContext(Dispatchers.Main) {
                    playlist = videos
                    currentPlaylistIndex = if (initialIndex != -1) initialIndex else 0
                }
            }
        }
    }

    private fun setupListeners() {
        val gestureListener = PlayerGestureListener(this, rootPlayerContainer, playerEngine, this, appPreferences)
        rootPlayerContainer.setOnTouchListener(gestureListener)

        btnPlayPause.setOnClickListener {
            togglePlayPauseState()
            resetHideControlsTimer()
        }

        btnNext.setOnClickListener {
            playNextVideo(isAutoPlay = false)
            resetHideControlsTimer()
        }

        btnPrev.setOnClickListener {
            playPreviousVideo()
            resetHideControlsTimer()
        }

        btnScreenshot.setOnClickListener {
            triggerScreenshot()
            resetHideControlsTimer()
        }

        btnAspectRatio.setOnClickListener {
            cycleAspectRatio()
            resetHideControlsTimer()
        }

        btnOrientation.setOnClickListener {
            cycleOrientation()
            resetHideControlsTimer()
        }

        btnPip.setOnClickListener {
            enterPipMode()
        }

        btnDecoderToggle.setOnClickListener {
            if (playerEngine.activeEngine == ActiveEngine.EXO_PLAYER) {
                playerEngine.switchToVlc(force = true)
            } else {
                playerEngine.switchToExoPlayer()
            }
            resetHideControlsTimer()
        }

        btnBackgroundAudio.setOnClickListener {
            val newState = !appPreferences.isBackgroundAudioEnabled
            appPreferences.isBackgroundAudioEnabled = newState
            updateBackgroundAudioIcon()

            if (newState) {
                checkAndStartBackgroundAudioService()
                showBottomFeedback("Background Audio: ON")
            } else {
                stopBackgroundAudioService()
                showBottomFeedback("Background Audio: OFF")
            }
            resetHideControlsTimer()
        }

        btnTracks.setOnClickListener {
            TrackSelectionHelper.showUnifiedTrackSelector(this, playerEngine) {
                subtitlePickerLauncher.launch(arrayOf("*/*"))
            }
            resetHideControlsTimer()
        }
        btnSpeed.setOnClickListener {
            currentSpeedIndex = (currentSpeedIndex + 1) % GeneralConfig.PLAYBACK_SPEED_PRESETS.size
            val speed = GeneralConfig.PLAYBACK_SPEED_PRESETS[currentSpeedIndex]
            isSpeedLockedAt2x = (speed == 2.0f) 
            playerEngine.setPlaybackSpeed(speed)
            btnSpeed.text = "${speed}x"
            showBottomFeedback("${speed}x")
            resetHideControlsTimer()
        }

        btnLock.setOnClickListener { setLockState(true) }
        btnUnlock.setOnClickListener { setLockState(false) }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    playerEngine.seekTo(progress.toLong())
                    tvTimeCurrent.text = GeneralFunc.formatDurationToTime(progress.toLong())
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { resetHideControlsTimer() }
            override fun onStopTrackingTouch(sb: SeekBar?) { resetHideControlsTimer() }
        })
    }

    private fun setControlsVisibility(visible: Boolean) {
        controlsOverlay.visibility = if (visible) View.VISIBLE else View.GONE
        if (visible) {
            startProgressUpdates()
            resetHideControlsTimer()
        } else {
            stopProgressUpdates()
            hideSystemBars()
        }
    }

    private fun checkAndStartBackgroundAudioService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                startBackgroundAudioService()
            } else {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            startBackgroundAudioService()
        }
    }

    private fun startBackgroundAudioService() {
        if (!isServiceBound) {
            val intent = Intent(this, BackgroundAudioService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        }
    }

    private fun stopBackgroundAudioService() {
        if (isServiceBound) {
            unbindService(serviceConnection)
            isServiceBound = false
        }
        val intent = Intent(this, BackgroundAudioService::class.java)
        stopService(intent)
        backgroundAudioService = null
    }

    private fun showBottomFeedback(message: String, durationMs: Long = 300L) {
        hideHandler.removeCallbacks(hideBottomFeedbackRunnable)
        tvBottomFeedback.text = message
        tvBottomFeedback.visibility = View.VISIBLE
        hideHandler.postDelayed(hideBottomFeedbackRunnable, durationMs)
    }

    private fun playNextVideo(isAutoPlay: Boolean = false) {
        if (playlist.isEmpty()) {
            currentFolder?.let { path ->
                lifecycleScope.launch(Dispatchers.IO) {
                    val videos = videoRepository.getVideosInFolder(path)
                    val idx = videos.indexOfFirst { it.uri == videoUri || it.path == videoFilePath }
                    withContext(Dispatchers.Main) {
                        playlist = videos
                        currentPlaylistIndex = if (idx != -1) idx else 0
                        executeNextVideo(isAutoPlay)
                    }
                }
                return
            }
        }
        executeNextVideo(isAutoPlay)
    }

    private fun executeNextVideo(isAutoPlay: Boolean) {
        if (isAutoPlay && !appPreferences.isAutoPlayNextEnabled) {
            if (!appPreferences.isBackgroundAudioEnabled) finish()
            return
        }

        if (playlist.isNotEmpty() && currentPlaylistIndex in 0 until (playlist.size - 1)) {
            currentPlaylistIndex++
            loadAndPlayTrack(playlist[currentPlaylistIndex])
        } else {
            if (isAutoPlay && !appPreferences.isBackgroundAudioEnabled) {
                finish()
            } else {
                showBottomFeedback("Last video in folder")
                backgroundAudioService?.updateNotification(videoTitle, playerEngine.isPlaying)
            }
        }
    }

    private fun playPreviousVideo() {
        if (playlist.isEmpty()) {
            currentFolder?.let { path ->
                lifecycleScope.launch(Dispatchers.IO) {
                    val videos = videoRepository.getVideosInFolder(path)
                    val idx = videos.indexOfFirst { it.uri == videoUri || it.path == videoFilePath }
                    withContext(Dispatchers.Main) {
                        playlist = videos
                        currentPlaylistIndex = if (idx != -1) idx else 0
                        executePrevVideo()
                    }
                }
                return
            }
        }
        executePrevVideo()
    }

    private fun executePrevVideo() {
        if (playlist.isNotEmpty() && currentPlaylistIndex > 0) {
            currentPlaylistIndex--
            loadAndPlayTrack(playlist[currentPlaylistIndex])
        } else {
            showBottomFeedback("First video in folder")
            backgroundAudioService?.updateNotification(videoTitle, playerEngine.isPlaying)
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: loadAndPlayTrack
     * Description: Commits watch progress for the current track and loads the next item.
     * Input: video (VideoItem)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun loadAndPlayTrack(video: VideoItem) {
        saveCurrentPosition()
        videoUri = video.uri
        videoFilePath = video.path
        videoTitle = video.title

        val currentEngine = playerEngine.activeEngine

        runOnUiThread {
            tvVideoTitle.text = videoTitle
            btnPlayPause.setImageResource(R.drawable.ic_pause)
            playerEngine.playMedia(video.uri, 0L, currentEngine)
            backgroundAudioService?.updateNotification(videoTitle, true)
            showBottomFeedback("Playing: $videoTitle", 500L)
            updateProgressNow()
        }
    }

    private fun handleVideoPlaybackFinished() {
        playNextVideo(isAutoPlay = true)
    }

    private fun cycleAspectRatio() {
        currentAspectIndex = (currentAspectIndex + 1) % 4
        val aspectModeName = when (currentAspectIndex) {
            0 -> "Fit"
            1 -> "Stretch"
            2 -> "Crop"
            else -> "100%"
        }
        playerEngine.setAspectRatio(currentAspectIndex)
        showBottomFeedback("Aspect: $aspectModeName")
    }

    private fun cycleOrientation() {
        currentOrientationMode = (currentOrientationMode + 1) % 3
        val modeName = when (currentOrientationMode) {
            0 -> {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
                "Auto-Rotate"
            }
            1 -> {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                "Landscape"
            }
            else -> {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                "Portrait"
            }
        }
        showBottomFeedback("Rotation: $modeName")
    }

    private fun enterPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val width = if (playerEngine.activeEngine == ActiveEngine.EXO_PLAYER) playerView.width else vlcVideoLayout.width
            val height = if (playerEngine.activeEngine == ActiveEngine.EXO_PLAYER) playerView.height else vlcVideoLayout.height
            val rational = Rational(width.coerceAtLeast(1), height.coerceAtLeast(1))
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(rational)
                .build()
            enterPictureInPictureMode(params)
        } else {
            showBottomFeedback("PiP not supported")
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && playerEngine.isPlaying && !appPreferences.isBackgroundAudioEnabled) {
            enterPipMode()
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            controlsOverlay.visibility = View.GONE
            touchLockOverlay.visibility = View.GONE
            tvBottomFeedback.visibility = View.GONE
            stopProgressUpdates()
        } else {
            controlsOverlay.visibility = View.VISIBLE
            startProgressUpdates()
            hideSystemBars()
            playerEngine.onActivityResume()
        }
    }

    private fun togglePlayPauseState() {
        val isPlaying = playerEngine.togglePlayPause()
        btnPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        backgroundAudioService?.updateNotification(videoTitle, isPlaying)
        showBottomFeedback(if (isPlaying) "Play" else "Pause")
        if (isPlaying && controlsOverlay.visibility == View.VISIBLE) {
            startProgressUpdates()
        }
    }

    private fun triggerScreenshot() {
        val currentPos = playerEngine.currentPosition
        val queued = if (playerEngine.activeEngine == ActiveEngine.EXO_PLAYER) {
            val format = playerEngine.exoPlayer?.videoFormat
            screenshotPipeline.captureFrameExo(
                playerView = playerView,
                videoTitle = videoTitle,
                currentPositionMs = currentPos,
                videoWidth = format?.width ?: 0,
                videoHeight = format?.height ?: 0
            )
        } else {
            screenshotPipeline.captureFrameVlc(
                vlcVideoLayout = vlcVideoLayout,
                videoTitle = videoTitle,
                currentPositionMs = currentPos,
                mediaPlayer = playerEngine.vlcMediaPlayer
            )
        }

        if (queued) {
            rapidScreenshotCount++
            hideHandler.removeCallbacks(resetScreenshotCounterRunnable)
            hideHandler.postDelayed(resetScreenshotCounterRunnable, 1000)

            val msg = if (rapidScreenshotCount > 1) "Screenshot ($rapidScreenshotCount)" else "Screenshot Saved"
            showBottomFeedback(msg, 300L)
        }
    }
    
    private fun setLockState(locked: Boolean) {
        isLocked = locked
        touchLockOverlay.visibility = if (locked) View.VISIBLE else View.GONE
        controlsOverlay.visibility = View.GONE
        stopProgressUpdates()
        hideSystemBars()
        if (locked) showBottomFeedback("Screen Locked")
    }

    private fun resetHideControlsTimer() {
        hideHandler.removeCallbacks(hideControlsRunnable)
        hideHandler.postDelayed(hideControlsRunnable, GeneralConfig.CONTROLS_HIDE_TIMEOUT_MS)
    }

    override fun onSingleTap() {
        if (isLocked) return
        val willBeVisible = controlsOverlay.visibility != View.VISIBLE
        setControlsVisibility(willBeVisible)
    }

    override fun onDoubleTapSeek(isForward: Boolean, targetPositionMs: Long) {
        if (isLocked) return
        val step = appPreferences.doubleTapSeekSeconds * 1000L

        val delta = if (isForward) step else -step
        playerEngine.seekRelative(delta)

        updateProgressNow()

        if (isForward) {
            accumulatedForwardMs += step
            showForwardOverlay(accumulatedForwardMs / 1000)
        } else {
            accumulatedRewindMs += step
            showRewindOverlay(accumulatedRewindMs / 1000)
        }
    }

    override fun onDoubleTapPlayPause() {
        if (isLocked) return
        togglePlayPauseState()
    }

    override fun onScreenshotGestureTriggered() {
        if (isLocked) return
        triggerScreenshot()
    }

    override fun onHorizontalScrub(seekPositionMs: Long, deltaMs: Long, isFinalCommit: Boolean) {
        if (isLocked) return
        if (isFinalCommit) {
            playerEngine.seekTo(seekPositionMs)
            updateProgressNow()

            hideHandler.removeCallbacks(hideHudRunnable)
            hideHandler.postDelayed(hideHudRunnable, 500)
        } else {
            hideHandler.removeCallbacks(hideHudRunnable)
            val sign = if (deltaMs >= 0) "+" else ""
            val deltaStr = "${sign}${deltaMs / 1000}s"
            val currentStr = GeneralFunc.formatDurationToTime(seekPositionMs)
            tvHudText.text = "$currentStr ($deltaStr)"
            ivHudIcon.visibility = View.GONE
            pbHudProgress.visibility = View.GONE
            layoutGestureHud.visibility = View.VISIBLE
        }
    }

    private fun showForwardOverlay(seconds: Long) {
        hideHandler.removeCallbacks(hideForwardRunnable)
        tvForwardSeconds.text = "${seconds}s ▶▶"
        layoutForwardOverlay.visibility = View.VISIBLE
        hideHandler.postDelayed(hideForwardRunnable, 750)
    }

    private fun showRewindOverlay(seconds: Long) {
        hideHandler.removeCallbacks(hideRewindRunnable)
        tvRewindSeconds.text = "◀◀ ${seconds}s"
        layoutRewindOverlay.visibility = View.VISIBLE
        hideHandler.postDelayed(hideRewindRunnable, 750)
    }

    override fun onVolumeChanged(currentVolumeRatio: Float) {
        if (isLocked) return
        val percent = (currentVolumeRatio * 100).toInt()
        ivHudIcon.setImageResource(R.drawable.ic_volume)
        ivHudIcon.visibility = View.VISIBLE
        pbHudProgress.visibility = View.VISIBLE
        pbHudProgress.progress = percent
        tvHudText.text = "$percent%"
        displayGestureHud()
    }

    override fun onBrightnessChanged(currentBrightnessRatio: Float) {
        if (isLocked) return
        val percent = (currentBrightnessRatio * 100).toInt()
        ivHudIcon.setImageResource(R.drawable.ic_brightness)
        ivHudIcon.visibility = View.VISIBLE
        pbHudProgress.visibility = View.VISIBLE
        pbHudProgress.progress = percent
        tvHudText.text = "$percent%"
        displayGestureHud()
    }

    override fun onScaleChanged(scaleFactor: Float) {
        if (isLocked) return
        playerView.scaleX = scaleFactor
        playerView.scaleY = scaleFactor
        vlcVideoLayout.scaleX = scaleFactor
        vlcVideoLayout.scaleY = scaleFactor
    }

    private fun displayGestureHud() {
        layoutGestureHud.visibility = View.VISIBLE
        hideHandler.removeCallbacks(hideHudRunnable)
        hideHandler.postDelayed(hideHudRunnable, 1000)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onStart() {
        super.onStart()
        if (appPreferences.isBackgroundAudioEnabled) {
            checkAndStartBackgroundAudioService()
        }
    }

    override fun onResume() {
        super.onResume()
        playerEngine.onActivityResume()
        hideSystemBars()
    }

    /**
     * -------------------------------------------------------------------------
     * Function: saveCurrentPosition
     * Description: Persists playback position to Room SQLite via DatabaseManager.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    private fun saveCurrentPosition() {
        val currentPos = playerEngine.currentPosition
        val duration = playerEngine.duration
        if (videoFilePath.isNotBlank() && duration > 0L) {
            lifecycleScope.launch(Dispatchers.IO) {
                dbManager.saveWatchProgress(videoFilePath, currentPos, duration)
            }
        }
    }

    private fun pauseAndSavePosition() {
        saveCurrentPosition()
        if (playerEngine.isPlaying && !appPreferences.isBackgroundAudioEnabled) {
            playerEngine.togglePlayPause()
        }
        btnPlayPause.setImageResource(R.drawable.ic_play)
        backgroundAudioService?.updateNotification(videoTitle, false)
    }

    override fun onPause() {
        super.onPause()
        if (!appPreferences.isBackgroundAudioEnabled) {
            if (isFinishing || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && !isInPictureInPictureMode)) {
                pauseAndSavePosition()
            }
        }
    }

    override fun onLongPressStart() {
        // Filter lock state according to preferences
        if (isLocked && !appPreferences.lockAllowLongPress2x) return

        speedBeforeLongPress = GeneralConfig.PLAYBACK_SPEED_PRESETS[currentSpeedIndex]
        playerEngine.setPlaybackSpeed(2.0f)
        showBottomFeedback("2.0x ▶▶", durationMs = 2000L)
    }

    override fun onLongPressEnd() {
        if (isLocked && !appPreferences.lockAllowLongPress2x) return

        playerEngine.setPlaybackSpeed(speedBeforeLongPress)
        showBottomFeedback("${speedBeforeLongPress}x", durationMs = 300L)
    }

    // -------------------------------------------------------------------------
    // Gestures 1 & 2: Two-Finger Horizontal Swipe (Audio / Subtitle Cycle)
    // -------------------------------------------------------------------------
    override fun onTwoFingerSwipeTracks(isAudioTrack: Boolean) {
        if (isLocked && !appPreferences.lockAllowTwoFingerTracks) return
        val message = playerEngine.cycleNextTrack(isAudioTrack)
        showBottomFeedback(message, durationMs = 1000L)
    }

    // -------------------------------------------------------------------------
    // Gesture 3: Two-Finger Double-Tap (Toggle Screen Lock / Unlock)
    // -------------------------------------------------------------------------
    override fun onTwoFingerDoubleTapLockToggle() {
        if (isLocked && !appPreferences.lockAllowTwoFingerUnlock) return
        setLockState(!isLocked)
    }

    // -------------------------------------------------------------------------
    // Gestures 4 & 5: Long-Press Drag Down (Lock 2x) & Up (Unlock 2x)
    // -------------------------------------------------------------------------
    override fun onHold2xSpeedStart() {
        if (isLocked && !appPreferences.lockAllowLongPress2x) return
        if (isSpeedLockedAt2x) return

        speedBeforeLongPress = GeneralConfig.PLAYBACK_SPEED_PRESETS[currentSpeedIndex]
        playerEngine.setPlaybackSpeed(2.0f)
        showBottomFeedback("2.0x ▶▶ (Drag Down to Lock, Up to Reset)", durationMs = 1500L)
    }

    override fun onHold2xSpeedEnd() {
        if (isLocked && !appPreferences.lockAllowLongPress2x) return
        if (isSpeedLockedAt2x) return

        playerEngine.setPlaybackSpeed(speedBeforeLongPress)
        showBottomFeedback("${speedBeforeLongPress}x", durationMs = 300L)
    }

    override fun onLock2xSpeedCommitted() {
        if (isLocked && !appPreferences.lockAllowSpeedDragLock) return

        isSpeedLockedAt2x = true
        playerEngine.setPlaybackSpeed(2.0f)
        btnSpeed.text = "2.0x"
        currentSpeedIndex = GeneralConfig.PLAYBACK_SPEED_PRESETS.indexOf(2.0f).coerceAtLeast(0)
        showBottomFeedback("2.0x Speed Locked", durationMs = 1200L)
    }

    override fun onUnlock2xSpeedCommitted() {
        if (isLocked && !appPreferences.lockAllowSpeedDragLock) return

        isSpeedLockedAt2x = false
        val normalSpeed = 1.0f
        playerEngine.setPlaybackSpeed(normalSpeed)
        btnSpeed.text = "1.0x"
        currentSpeedIndex = GeneralConfig.  .indexOf(1.0f).coerceAtLeast(2)
        showBottomFeedback("2.0x Speed Reset (1.0x)", durationMs = 1200L)
    }

    override fun onStop() {
        super.onStop()
        stopProgressUpdates()
        saveCurrentPosition()
        if (appPreferences.isBackgroundAudioEnabled && playerEngine.isPlaying) {
            playerEngine.enableBackgroundAudioMode()
            backgroundAudioService?.updateNotification(videoTitle, true)
        } else if (!appPreferences.isBackgroundAudioEnabled && playerEngine.isPlaying) {
            pauseAndSavePosition()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        saveCurrentPosition()
        stopProgressUpdates()
        stopBackgroundAudioService()
        audioNoisyReceiver.unregister(this)
        screenshotPipeline.release()
        playerEngine.release()
    }
}