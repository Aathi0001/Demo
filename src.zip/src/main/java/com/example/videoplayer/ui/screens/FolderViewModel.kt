package com.example.videoplayer.ui.screens

import android.app.Application
import android.content.ContentUris
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.videoplayer.configs.GeneralConfig
import com.example.videoplayer.cores.locals.ChunkWriter
import com.example.videoplayer.cores.locals.DatabaseManager
import com.example.videoplayer.cores.locals.KWayMergeStreamer
import com.example.videoplayer.cores.models.VideoItem
import com.example.videoplayer.utils.NaturalSortComparator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * =========================================================================
 * CLASS: FolderViewModel
 * PACKAGE: com.example.videoplayer.ui.screens
 * DESCRIPTION: Coordinates folder media scanning, disk chunking, K-Way
 *              heap merge sort, pagination streaming, and disk cache cleanup.
 * =========================================================================
 */
class FolderViewModel(application: Application) : AndroidViewModel(application) {

    private val chunkWriter = ChunkWriter(application)
    private val mergeStreamer = KWayMergeStreamer()
    private val dbManager = DatabaseManager.getInstance(application)

    private val _videoList = MutableLiveData<List<VideoItem>>()
    val videoList: LiveData<List<VideoItem>> = _videoList

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val currentAccumulatedList = ArrayList<VideoItem>()
    private var activeBucketId: String? = null
    private var activeSortMode: Int = GeneralConfig.SORT_NATURAL_ASC
    private var isUsingChunking = false

    // Fast-path in-memory items (used only when folder has < 10,000 files)
    private var inMemoryFastPathItems = ArrayList<VideoItem>()
    private var fastPathOffset = 0

    /**
     * -------------------------------------------------------------------------
     * Function: loadFolderVideos
     * Description: Entry point when opening a folder. Determines whether to route
     *              through external disk chunking or fast in-memory sorting.
     * Input: bucketId (String), sortMode (Int)
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun loadFolderVideos(bucketId: String, sortMode: Int = GeneralConfig.SORT_NATURAL_ASC) {
        activeBucketId = bucketId
        activeSortMode = sortMode
        currentAccumulatedList.clear()
        fastPathOffset = 0
        _videoList.value = emptyList()

        viewModelScope.launch(Dispatchers.IO) {
            _isLoading.postValue(true)

            dbManager.preloadWatchCache()

            val context = getApplication<Application>()
            val uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.DATA,
                MediaStore.Video.Media.DURATION,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.DATE_MODIFIED
            )
            val selection = "${MediaStore.Video.Media.BUCKET_ID} = ?"
            val selectionArgs = arrayOf(bucketId)

            val cursor = context.contentResolver.query(
                uri,
                projection,
                selection,
                selectionArgs,
                null
            )

            if (cursor == null) {
                _isLoading.postValue(false)
                return@launch
            }

            val totalCount = cursor.count

            if (totalCount >= GeneralConfig.IN_MEMORY_SORT_THRESHOLD) {
                // Large folder path: External K-Way Merge Sort via disk chunks
                isUsingChunking = true
                val chunkFiles = chunkWriter.createChunksFromCursor(cursor, bucketId, sortMode)
                cursor.close()

                mergeStreamer.initialize(chunkFiles, sortMode)
            } else {
                // Fast path: Less than 10,000 files, sort directly in RAM
                isUsingChunking = false
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val pathCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)

                val tempList = ArrayList<VideoItem>(totalCount)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val path = cursor.getString(pathCol) ?: ""
                    tempList.add(
                        VideoItem(
                            id = id,
                            title = cursor.getString(nameCol) ?: "Unknown",
                            path = path,
                            durationMs = cursor.getLong(durCol),
                            sizeBytes = cursor.getLong(sizeCol),
                            dateModified = cursor.getLong(dateCol)
                        )
                    )
                }
                cursor.close()

                // Sort in memory using the requested comparator
                val comparator = NaturalSortComparator.getComparator(sortMode)
                tempList.sortWith(comparator)
                inMemoryFastPathItems = tempList
            }

            loadNextPage(pageSize = 50)
            _isLoading.postValue(false)
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: loadNextPage
     * Description: Fetches the next 50 items from either the Min-Heap or in-memory
     *              sublist and updates the LiveData stream for the UI.
     * Input: pageSize (Int) - Number of items to retrieve (default: 50).
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    fun loadNextPage(pageSize: Int = 50) {
        if (_isLoading.value == true && currentAccumulatedList.isNotEmpty()) return

        viewModelScope.launch(Dispatchers.IO) {
            val nextBatch = ArrayList<VideoItem>()

            if (isUsingChunking) {
                if (!mergeStreamer.hasMore()) return@launch
                val items = mergeStreamer.fetchNextPage(pageSize)
                nextBatch.addAll(items)
            } else {
                val totalAvailable = inMemoryFastPathItems.size
                if (fastPathOffset >= totalAvailable) return@launch

                val end = (fastPathOffset + pageSize).coerceAtMost(totalAvailable)
                nextBatch.addAll(inMemoryFastPathItems.subList(fastPathOffset, end))
                fastPathOffset = end
            }

            withContext(Dispatchers.Main) {
                currentAccumulatedList.addAll(nextBatch)
                _videoList.value = ArrayList(currentAccumulatedList)
            }
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: onCleared
     * Description: Lifecycle cleanup when exiting the folder. Closes open file
     *              readers and deletes all temporary disk chunks.
     * Input: None
     * Output: Unit
     * -------------------------------------------------------------------------
     */
    override fun onCleared() {
        super.onCleared()
        mergeStreamer.closeAll()
        activeBucketId?.let { bucketId ->
            chunkWriter.clearBucketDirectory(bucketId)
        }
    }
}