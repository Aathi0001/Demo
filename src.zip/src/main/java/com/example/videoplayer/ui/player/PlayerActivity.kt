package com.example.videoplayer.ui.player

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.ui.PlayerView
import com.example.videoplayer.R
import com.example.videoplayer.config.GeneralConfig
import com.example.videoplayer.data.local.ResumeStore
import com.example.videoplayer.player.AudioNoisyReceiver
import com.example.videoplayer.player.PlayerEngine
import com.example.videoplayer.player.PlayerGestureCallback
import com.example.videoplayer.player.PlayerGestureListener
import com.example.videoplayer.player.ScreenshotPipeline
import com.example.videoplayer.player.TrackSelectionHelper
import com.example.videoplayer.utils.GeneralFunc

class PlayerActivity : AppCompatActivity(), PlayerGestureCallback {

    private lateinit var rootPlayerContainer: FrameLayout
    private lateinit var playerView: PlayerView
    private lateinit var playerEngine: PlayerEngine
    private lateinit var screenshotPipeline: ScreenshotPipeline
    private lateinit var resumeStore: ResumeStore
    private lateinit var audioNoisyReceiver: AudioNoisyReceiver

    // UI Overlays & Controls
    private lateinit var controlsOverlay: RelativeLayout
    private lateinit var touchLockOverlay: FrameLayout
    private lateinit var seekBar: SeekBar
    private lateinit var tvTimeCurrent: TextView
    private lateinit var tvTimeTotal: TextView
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnSpeed: Button

    // Double-Tap Skip Overlays
    private lateinit var layoutRewindOverlay: LinearLayout
    private lateinit var tvRewindSeconds: TextView
    private lateinit var layoutForwardOverlay: LinearLayout
    private lateinit var tvForwardSeconds: TextView

    // Center Gesture HUD (Volume & Brightness)
    private lateinit var layoutGestureHud: View
    private lateinit var ivHudIcon: ImageView
    private lateinit var pbHudProgress: ProgressBar
    private lateinit var tvHudText: TextView

    private var videoUri: Uri? = null
    private var videoTitle: String = "Video"
    private var isLocked: Boolean = false
    private var currentSpeedIndex = 2 // 1.0x

    // Cumulative second accumulators for double-tap seek
    private var accumulatedForwardMs = 0L
    private var accumulatedRewindMs = 0L

    private val hideHandler = Handler(Looper.getMainLooper())
    private val hideControlsRunnable = Runnable { controlsOverlay.visibility = View.GONE }
    private val hideHudRunnable = Runnable { layoutGestureHud.visibility = View.GONE }
    private val hideForwardRunnable = Runnable {
        layoutForwardOverlay.visibility = View.GONE
        accumulatedForwardMs = 0L
    }
    private val hideRewindRunnable = Runnable {
        layoutRewindOverlay.visibility = View.GONE
        accumulatedRewindMs = 0L
    }

    private val progressHandler = Handler(Looper.getMainLooper())
    private val progressRunnable = object : Runnable {
        override fun run() {
            playerEngine.exoPlayer?.let { player ->
                if (player.isPlaying) {
                    val current = player.currentPosition
                    val total = player.duration.coerceAtLeast(0L)
                    seekBar.max = total.toInt()
                    seekBar.progress = current.toInt()
                    tvTimeCurrent.text = GeneralFunc.formatDurationToTime(current)
                    tvTimeTotal.text = GeneralFunc.formatDurationToTime(total)
                }
            }
            progressHandler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Set window flags and view FIRST
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)

        // 2. Hide system bars AFTER layout attachment
        hideSystemBars()

        videoUri = intent.data ?: (intent.getStringExtra("VIDEO_URI")?.let { Uri.parse(it) })
        videoTitle = intent.getStringExtra("VIDEO_TITLE") ?: "Video"

        initViews()
        initPlayerAndPipelines()
        setupListeners()
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun initViews() {
        rootPlayerContainer = findViewById(R.id.rootPlayerContainer)
        playerView = findViewById(R.id.playerView)
        controlsOverlay = findViewById(R.id.controlsOverlay)
        touchLockOverlay = findViewById(R.id.touchLockOverlay)
        seekBar = findViewById(R.id.seekBarProgress)
        tvTimeCurrent = findViewById(R.id.tvTimeCurrent)
        tvTimeTotal = findViewById(R.id.tvTimeTotal)
        btnPlayPause = findViewById(R.id.btnPlayPause)
        btnSpeed = findViewById(R.id.btnSpeed)
        findViewById<TextView>(R.id.tvVideoTitle).text = videoTitle

        // Side Skip Overlays
        layoutRewindOverlay = findViewById(R.id.layoutRewindOverlay)
        tvRewindSeconds = findViewById(R.id.tvRewindSeconds)
        layoutForwardOverlay = findViewById(R.id.layoutForwardOverlay)
        tvForwardSeconds = findViewById(R.id.tvForwardSeconds)

        // Center HUD views
        layoutGestureHud = findViewById(R.id.layoutGestureHud)
        ivHudIcon = findViewById(R.id.ivHudIcon)
        pbHudProgress = findViewById(R.id.pbHudProgress)
        tvHudText = findViewById(R.id.tvHudText)
    }

    private fun initPlayerAndPipelines() {
        resumeStore = ResumeStore(this)

        playerEngine = PlayerEngine(this, playerView) {
            videoUri?.let { resumeStore.deletePosition(it.toString()) }
            finish()
        }

        screenshotPipeline = ScreenshotPipeline(this) { savedUri, filename ->
            if (savedUri != null) {
                Toast.makeText(this, "Saved: $filename", Toast.LENGTH_SHORT).show()
            }
        }

        audioNoisyReceiver = AudioNoisyReceiver {
            playerEngine.exoPlayer?.pause()
            btnPlayPause.setImageResource(R.drawable.ic_play)
        }
        audioNoisyReceiver.register(this)

        val savedPosition = videoUri?.let { resumeStore.getSavedPosition(it.toString()) } ?: 0L
        videoUri?.let { playerEngine.playMedia(it, savedPosition) }

        progressHandler.post(progressRunnable)
    }

    private fun setupListeners() {
        val gestureListener = PlayerGestureListener(this, playerView, playerEngine, this)
        playerView.setOnTouchListener(gestureListener)

        btnPlayPause.setOnClickListener {
            togglePlayPauseState()
            resetHideControlsTimer()
        }

        findViewById<ImageButton>(R.id.btnScreenshot).setOnClickListener {
            val currentPos = playerEngine.exoPlayer?.currentPosition ?: 0L
            screenshotPipeline.captureFrame(playerView, videoTitle, currentPos)
            resetHideControlsTimer()
        }

        // Single Unified Track Selector (Audio, Subtitles, Video)
        findViewById<ImageButton>(R.id.btnTracks).setOnClickListener {
            playerEngine.exoPlayer?.let { player ->
                TrackSelectionHelper.showUnifiedTrackSelector(this, player)
            }
            resetHideControlsTimer()
        }

        btnSpeed.setOnClickListener {
            currentSpeedIndex = (currentSpeedIndex + 1) % GeneralConfig.PLAYBACK_SPEED_PRESETS.size
            val speed = GeneralConfig.PLAYBACK_SPEED_PRESETS[currentSpeedIndex]
            playerEngine.setPlaybackSpeed(speed)
            btnSpeed.text = "${speed}x"
            resetHideControlsTimer()
        }

        findViewById<ImageButton>(R.id.btnLock).setOnClickListener {
            setLockState(true)
        }

        findViewById<ImageButton>(R.id.btnUnlock).setOnClickListener {
            setLockState(false)
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    playerEngine.exoPlayer?.seekTo(progress.toLong())
                    tvTimeCurrent.text = GeneralFunc.formatDurationToTime(progress.toLong())
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar?) { resetHideControlsTimer() }
            override fun onStopTrackingTouch(sb: SeekBar?) { resetHideControlsTimer() }
        })
    }

    private fun togglePlayPauseState() {
        val isPlaying = playerEngine.togglePlayPause()
        btnPlayPause.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun setLockState(locked: Boolean) {
        isLocked = locked
        touchLockOverlay.visibility = if (locked) View.VISIBLE else View.GONE
        controlsOverlay.visibility = View.GONE
        hideSystemBars()
    }

    private fun resetHideControlsTimer() {
        hideHandler.removeCallbacks(hideControlsRunnable)
        hideHandler.postDelayed(hideControlsRunnable, GeneralConfig.CONTROLS_HIDE_TIMEOUT_MS)
    }

    // --- PlayerGestureCallback Implementations ---

    override fun onSingleTap() {
        if (isLocked) return
        controlsOverlay.visibility = if (controlsOverlay.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        if (controlsOverlay.visibility == View.VISIBLE) {
            resetHideControlsTimer()
        } else {
            hideSystemBars()
        }
    }

    override fun onDoubleTapSeek(isForward: Boolean, targetPositionMs: Long) {
        if (isLocked) return
        if (isForward) {
            accumulatedForwardMs += 10000L
            playerEngine.seekRelative(10000L)
            showForwardOverlay(accumulatedForwardMs / 1000)
        } else {
            accumulatedRewindMs += 10000L
            playerEngine.seekRelative(-10000L)
            showRewindOverlay(accumulatedRewindMs / 1000)
        }
    }

    private fun showForwardOverlay(seconds: Long) {
        hideHandler.removeCallbacks(hideForwardRunnable)
        tvForwardSeconds.text = "${seconds}s ▶▶"
        layoutForwardOverlay.visibility = View.VISIBLE
        hideHandler.postDelayed(hideForwardRunnable, 750)
    }

    private fun showRewindOverlay(seconds: Long) {
        hideHandler.removeCallbacks(hideRewindRunnable)
        tvRewindSeconds.text = "◀◀ ${seconds}s"
        layoutRewindOverlay.visibility = View.VISIBLE
        hideHandler.postDelayed(hideRewindRunnable, 750)
    }

    override fun onVolumeChanged(currentVolumeRatio: Float) {
        if (isLocked) return
        val percent = (currentVolumeRatio * 100).toInt()
        ivHudIcon.setImageResource(R.drawable.ic_volume)
        pbHudProgress.visibility = View.VISIBLE
        pbHudProgress.progress = percent
        tvHudText.text = "$percent%"
        displayGestureHud()
    }

    override fun onBrightnessChanged(currentBrightnessRatio: Float) {
        if (isLocked) return
        val percent = (currentBrightnessRatio * 100).toInt()
        ivHudIcon.setImageResource(R.drawable.ic_brightness)
        pbHudProgress.visibility = View.VISIBLE
        pbHudProgress.progress = percent
        tvHudText.text = "$percent%"
        displayGestureHud()
    }

    override fun onScaleChanged(scaleFactor: Float) {
        if (isLocked) return
        playerView.scaleX = scaleFactor
        playerView.scaleY = scaleFactor
    }

    private fun displayGestureHud() {
        layoutGestureHud.visibility = View.VISIBLE
        hideHandler.removeCallbacks(hideHudRunnable)
        hideHandler.postDelayed(hideHudRunnable, 1000)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            hideSystemBars()
        }
    }

    override fun onPause() {
        super.onPause()
        playerEngine.exoPlayer?.let { player ->
            videoUri?.let { uri ->
                resumeStore.savePosition(uri.toString(), player.currentPosition, player.duration)
            }
            player.pause()
            btnPlayPause.setImageResource(R.drawable.ic_play)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        progressHandler.removeCallbacks(progressRunnable)
        audioNoisyReceiver.unregister(this)
        screenshotPipeline.release()
        playerEngine.release()
    }
}