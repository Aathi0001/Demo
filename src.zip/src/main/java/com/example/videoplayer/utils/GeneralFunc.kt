package com.example.videoplayer.utils

import java.io.File
import java.security.MessageDigest

/**
 * =========================================================================
 * OBJECT: GeneralFunc
 * PACKAGE: com.example.videoplayer.utils
 * DESCRIPTION: Universal, non-domain utility functions reusable in any app.
 * =========================================================================
 */
object GeneralFunc {

    // Pre-compiled regex to prevent allocations on every method call
    private val ILLEGAL_CHARS_REGEX = Regex("[\\\\/:*?\"<>|]")

    /**
     * -------------------------------------------------------------------------
     * Function: sanitizeFilename
     * Description: Removes illegal filesystem characters (\ / : * ? " < > |)
     *              from a string to ensure safe file creation across all OS storage.
     * Input: rawName (String) - Original filename or title.
     * Output: String - Sanitized string safe for filesystem use.
     * -------------------------------------------------------------------------
     */
    fun sanitizeFilename(rawName: String): String {
        return rawName.replace(ILLEGAL_CHARS_REGEX, "_").trim()
    }

    /**
     * -------------------------------------------------------------------------
     * Function: stripFileExtension
     * Description: Strips the file extension from a filename or path.
     * Input: filename (String) - File name (e.g., "One_Piece_E1071.mkv").
     * Output: String - Base name without extension (e.g., "One_Piece_E1071").
     * -------------------------------------------------------------------------
     */
    fun stripFileExtension(filename: String): String {
        val dotIndex = filename.lastIndexOf('.')
        return if (dotIndex > 0) filename.substring(0, dotIndex) else filename
    }

    /**
     * -------------------------------------------------------------------------
     * Function: clampValue
     * Description: Restricts a given float value strictly between a defined
     *              minimum and maximum range (used for volume/brightness levels).
     * Input: value (Float) - Current dynamic value.
     *        min (Float) - Lower bound limit.
     *        max (Float) - Upper bound limit.
     * Output: Float - Value restricted within [min, max].
     * -------------------------------------------------------------------------
     */
    fun clampValue(value: Float, min: Float, max: Float): Float {
        return when {
            value < min -> min
            value > max -> max
            else -> value
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: calculateProgressRatio
     * Description: Calculates playback completion ratio without zero-division crashes.
     * Input: currentPositionMs (Long) - Current playback position in milliseconds.
     *        totalDurationMs (Long) - Total duration of media in milliseconds.
     * Output: Float - Ratio from 0.0f to 1.0f.
     * -------------------------------------------------------------------------
     */
    fun calculateProgressRatio(currentPositionMs: Long, totalDurationMs: Long): Float {
        if (totalDurationMs <= 0L) return 0.0f
        val ratio = currentPositionMs.toFloat() / totalDurationMs.toFloat()
        return clampValue(ratio, 0.0f, 1.0f)
    }

    /**
     * -------------------------------------------------------------------------
     * Function: generateMd5Hash
     * Description: Generates an MD5 hash of an input string (used for unique,
     *              fixed-length keys in the resume state store).
     * Input: input (String) - Raw input string (e.g., video URI or path).
     * Output: String - 32-character hexadecimal MD5 hash.
     * -------------------------------------------------------------------------
     */
    fun generateMd5Hash(input: String): String {
        val bytes = MessageDigest.getInstance("MD5").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: formatDurationToTime
     * Description: Converts a raw millisecond value into human-readable HH:MM:SS
     *              or MM:SS format for UI time displays without heavy reflection.
     * Input: timeMs (Long) - Duration in milliseconds.
     * Output: String - Formatted time string (e.g., "23:41" or "01:15:30").
     * -------------------------------------------------------------------------
     */
    fun formatDurationToTime(timeMs: Long): String {
        if (timeMs <= 0L) return "00:00"
        val totalSeconds = timeMs / 1000
        val seconds = totalSeconds % 60
        val minutes = (totalSeconds / 60) % 60
        val hours = totalSeconds / 3600

        val secStr = if (seconds < 10) "0$seconds" else "$seconds"
        val minStr = if (minutes < 10) "0$minutes" else "$minutes"

        return if (hours > 0) {
            val hrStr = if (hours < 10) "0$hours" else "$hours"
            "$hrStr:$minStr:$secStr"
        } else {
            "$minStr:$secStr"
        }
    }

    /**
     * -------------------------------------------------------------------------
     * Function: estimateStringMemoryBytes
     * Description: Estimates JVM memory footprint of a string (UTF-16 char array
     *              overhead + object header).
     * Input: text (String?)
     * Output: Long - Estimated memory consumption in bytes.
     * -------------------------------------------------------------------------
     */
    fun estimateStringMemoryBytes(text: String?): Long {
        if (text == null) return 0L
        return 40L + (text.length * 2L)
    }

    /**
     * -------------------------------------------------------------------------
     * Function: sanitizeDelimiter
     * Description: Removes delimiter characters from text to prevent parsing errors.
     * Input: text (String), delimiter (String)
     * Output: String - Sanitized string safe for delimited serialization.
     * -------------------------------------------------------------------------
     */
    fun sanitizeDelimiter(text: String, delimiter: String): String {
        return if (text.contains(delimiter)) text.replace(delimiter, " ") else text
    }
}