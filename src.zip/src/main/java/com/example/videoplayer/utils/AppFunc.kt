package com.example.videoplayer.utils

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream

import com.example.videoplayer.configs.GeneralConfig
import com.example.videoplayer.configs.QueryConfig
import com.example.videoplayer.cores.models.VideoItem

/**
 * =========================================================================
 * OBJECT: AppFunc
 * PACKAGE: com.example.videoplayer.utils
 * DESCRIPTION: Project-specific utility and serialization functions tailored
 *              for media captures, playback state validation, and chunk serialization.
 * =========================================================================
 */
object AppFunc {

    /**
     * -------------------------------------------------------------------------
     * Function: generateScreenshotFilename
     * Description: Builds an ordered screenshot filename using the base title
     *              and the exact playback position in milliseconds.
     *              Pattern: [SanitizedTitle]_[PlaybackPositionMs].jpg
     * Input: videoTitle (String) - Raw video display name or file name.
     *        positionMs (Long) - Current playback timestamp in milliseconds.
     * Output: String - Formatted filename (e.g., "OnePiece_E1071_1421852.jpg").
     * -------------------------------------------------------------------------
     */
    fun generateScreenshotFilename(videoTitle: String, positionMs: Long): String {
        val baseTitle = GeneralFunc.stripFileExtension(videoTitle)
        val cleanTitle = GeneralFunc.sanitizeFilename(baseTitle)
        return "${cleanTitle}_${positionMs}${GeneralConfig.SCREENSHOT_FILE_EXTENSION}"
    }

    /**
     * -------------------------------------------------------------------------
     * Function: resolveConflictFilename
     * Description: Checks if a file exists on the legacy filesystem (Android 9 and below).
     *              If a conflict exists, it sequentially appends (1), (2), (3)
     *              before the extension to prevent overwriting.
     * Input: directory (File) - Target storage directory.
     *        filename (String) - Desired original filename.
     * Output: File - Conflict-free File reference ready for writing.
     * -------------------------------------------------------------------------
     */
    fun resolveConflictFilename(directory: File, filename: String): File {
        var targetFile = File(directory, filename)
        if (!targetFile.exists()) return targetFile

        val baseName = GeneralFunc.stripFileExtension(filename)
        val extension = GeneralConfig.SCREENSHOT_FILE_EXTENSION
        var count = 1

        while (targetFile.exists()) {
            targetFile = File(directory, "$baseName ($count)$extension")
            count++
        }
        return targetFile
    }

    /**
     * -------------------------------------------------------------------------
     * Function: saveBitmapToStorage
     * Description: Writes a Bitmap buffer to the gallery under Pictures/Captures/.
     *              - Android 10+: Utilizes Scoped Storage via MediaStore insert.
     *              - Android 9-: Utilizes direct FileOutputStream with conflict checks.
     *              Recycles the native bitmap buffer immediately to conserve RAM.
     * Input: context (Context) - Application or Activity context.
     *        bitmap (Bitmap) - Raw frame buffer extracted from video playback.
     *        filename (String) - Target filename from generateScreenshotFilename.
     * Output: Uri? - Uri of the persisted image if successful, null on error.
     * -------------------------------------------------------------------------
     */
    fun saveBitmapToStorage(context: Context, bitmap: Bitmap, filename: String): Uri? {
        var outputUri: Uri? = null
        val resolver = context.contentResolver

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                    put(MediaStore.Images.Media.MIME_TYPE, GeneralConfig.SCREENSHOT_MIME_TYPE)
                    put(MediaStore.Images.Media.RELATIVE_PATH, QueryConfig.RELATIVE_SCREENSHOT_PATH)
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }

                outputUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                outputUri?.let { uri ->
                    resolver.openOutputStream(uri)?.use { outStream ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, GeneralConfig.SCREENSHOT_JPEG_QUALITY, outStream)
                    }
                    contentValues.clear()
                    contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                    resolver.update(uri, contentValues, null, null)
                }
            } else {
                val targetDir = File(QueryConfig.LEGACY_SCREENSHOT_PATH)
                if (!targetDir.exists()) {
                    targetDir.mkdirs()
                }

                val finalFile = resolveConflictFilename(targetDir, filename)
                FileOutputStream(finalFile).use { outStream ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, GeneralConfig.SCREENSHOT_JPEG_QUALITY, outStream)
                }
                outputUri = Uri.fromFile(finalFile)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            outputUri = null
        } finally {
            // Immediately free unmanaged native graphics memory
            if (!bitmap.isRecycled) {
                bitmap.recycle()
            }
        }

        return outputUri
    }

    /**
     * -------------------------------------------------------------------------
     * Function: isResumeEligible
     * Description: Validates whether a playback position qualifies for resuming
     *              midway. Returns false if unwatched (< 3s) or completed (>= 95%).
     * Input: currentPositionMs (Long) - Playback timestamp in milliseconds.
     *        durationMs (Long) - Total duration of media in milliseconds.
     * Output: Boolean - True if position should resume, false if restarted to 0.
     * -------------------------------------------------------------------------
     */
    fun isResumeEligible(currentPositionMs: Long, durationMs: Long): Boolean {
        if (durationMs <= 0L || currentPositionMs < 3000L) return false
        val progress = GeneralFunc.calculateProgressRatio(currentPositionMs, durationMs)
        return progress < GeneralConfig.COMPLETION_PERCENTAGE
    }

    /**
     * -------------------------------------------------------------------------
     * Function: serializeChunkLine
     * Description: Serializes all 6 sortable fields of a VideoItem into a tab-
     *              delimited string line ending with a newline character.
     * Input: item (VideoItem) - Populated video entity.
     * Output: String - Tab-delimited serialized line.
     * -------------------------------------------------------------------------
     */
    fun serializeChunkLine(item: VideoItem): String {
        val d = GeneralConfig.CHUNK_LINE_DELIMITER
        val safeName = GeneralFunc.sanitizeDelimiter(item.title, d)
        val safePath = GeneralFunc.sanitizeDelimiter(item.path, d)
        return "${item.id}$d$safeName$d$safePath$d${item.durationMs}$d${item.sizeBytes}$d${item.dateModified}\n"
    }

    /**
     * -------------------------------------------------------------------------
     * Function: parseChunkLine
     * Description: Parses a single tab-delimited chunk line into a VideoItem instance.
     * Input: rawLine (String) - Raw text line read from a temporary chunk file.
     * Output: VideoItem? - Deserialized video item or null if malformed.
     * -------------------------------------------------------------------------
     */
    fun parseChunkLine(rawLine: String): VideoItem? {
        if (rawLine.isBlank()) return null
        val parts = rawLine.trim().split(GeneralConfig.CHUNK_LINE_DELIMITER)
        if (parts.size < 4) return null

        return try {
            VideoItem(
                id = parts[0].toLong(),
                title = parts[1],
                path = parts[2],
                durationMs = parts[3].toLong(),
                sizeBytes = if (parts.size > 4) parts[4].toLong() else 0L,
                dateModified = if (parts.size > 5) parts[5].toLong() else 0L
            )
        } catch (_: NumberFormatException) {
            null
        }
    }
}