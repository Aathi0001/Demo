package com.example.videoplayer.utils

import com.example.videoplayer.configs.GeneralConfig
import com.example.videoplayer.cores.models.VideoItem

/**
 * =========================================================================
 * CLASS: NaturalSortComparator
 * PACKAGE: com.example.videoplayer.utils
 * DESCRIPTION: Zero-regex, character-pointer natural comparator that compares
 *              text alphabetically and numbers numerically. Includes a companion
 *              factory that produces Comparators for all supported sort dimensions.
 * =========================================================================
 */
class NaturalSortComparator : Comparator<VideoItem> {

    /**
     * -------------------------------------------------------------------------
     * Function: compare
     * Description: Performs character-by-character natural comparison between
     *              two VideoItem titles using dual pointer index tracking.
     * Input: o1 (VideoItem?), o2 (VideoItem?) - Instances to compare.
     * Output: Int - Negative if o1 < o2, positive if o1 > o2, zero if equal.
     * -------------------------------------------------------------------------
     */
    override fun compare(o1: VideoItem?, o2: VideoItem?): Int {
        if (o1 === o2) return 0
        if (o1 == null) return -1
        if (o2 == null) return 1

        val s1 = o1.title
        val s2 = o2.title

        var i = 0
        var j = 0
        val len1 = s1.length
        val len2 = s2.length

        while (i < len1 && j < len2) {
            val c1 = s1[i]
            val c2 = s2[j]

            if (c1.isDigit() && c2.isDigit()) {
                // Count and skip leading zeroes to align numeric values
                var numStart1 = i
                while (numStart1 < len1 && s1[numStart1] == '0') numStart1++
                var numEnd1 = numStart1
                while (numEnd1 < len1 && s1[numEnd1].isDigit()) numEnd1++

                var numStart2 = j
                while (numStart2 < len2 && s2[numStart2] == '0') numStart2++
                var numEnd2 = numStart2
                while (numEnd2 < len2 && s2[numEnd2].isDigit()) numEnd2++

                val numLen1 = numEnd1 - numStart1
                val numLen2 = numEnd2 - numStart2

                // The longer numeric sequence without leading zeroes is mathematically larger
                if (numLen1 != numLen2) {
                    return numLen1 - numLen2
                }

                // If identical length, compare digit by digit
                var p1 = numStart1
                var p2 = numStart2
                while (p1 < numEnd1 && p2 < numEnd2) {
                    val diff = s1[p1] - s2[p2]
                    if (diff != 0) return diff
                    p1++
                    p2++
                }

                // Tie-breaker: If numerical values match, fewer leading zeroes comes first
                val leadingZeroDiff = (numStart1 - i) - (numStart2 - j)
                if (leadingZeroDiff != 0) return leadingZeroDiff

                i = numEnd1
                j = numEnd2
            } else {
                val diff = c1.compareTo(c2, ignoreCase = true)
                if (diff != 0) return diff
                i++
                j++
            }
        }

        return len1 - len2
    }

    companion object {
        /**
         * -------------------------------------------------------------------------
         * Function: getComparator
         * Description: Resolves the active Comparator<VideoItem> instance corresponding
         *              to any configured sort dimension (Natural, Name, Date, Size, Duration).
         * Input: sortMode (Int) - Mode identifier constant defined in GeneralConfig.
         * Output: Comparator<VideoItem> - Instantiated sorting comparator.
         * -------------------------------------------------------------------------
         */
        fun getComparator(sortMode: Int): Comparator<VideoItem> {
            val naturalComp = NaturalSortComparator()

            return when (sortMode) {
                GeneralConfig.SORT_NATURAL_ASC -> naturalComp
                GeneralConfig.SORT_NATURAL_DESC -> naturalComp.reversed()

                GeneralConfig.SORT_NAME_ASC -> Comparator { a, b ->
                    a.title.compareTo(b.title, ignoreCase = true)
                }
                GeneralConfig.SORT_NAME_DESC -> Comparator { a, b ->
                    b.title.compareTo(a.title, ignoreCase = true)
                }

                GeneralConfig.SORT_DATE_DESC -> Comparator { a, b -> b.dateModified.compareTo(a.dateModified) }
                GeneralConfig.SORT_DATE_ASC -> Comparator { a, b -> a.dateModified.compareTo(b.dateModified) }

                GeneralConfig.SORT_SIZE_DESC -> Comparator { a, b -> b.sizeBytes.compareTo(a.sizeBytes) }
                GeneralConfig.SORT_SIZE_ASC -> Comparator { a, b -> a.sizeBytes.compareTo(b.sizeBytes) }

                GeneralConfig.SORT_DURATION_DESC -> Comparator { a, b -> b.durationMs.compareTo(a.durationMs) }
                GeneralConfig.SORT_DURATION_ASC -> Comparator { a, b -> a.durationMs.compareTo(b.durationMs) }

                else -> naturalComp
            }
        }
    }
}