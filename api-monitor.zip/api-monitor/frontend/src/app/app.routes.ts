import {
    Routes
} from '@angular/router';

import {
    ServiceListComponent
} from './features/services/pages/service-list/service-list.component';


export const routes: Routes = [

    {
        path: '',
        component: ServiceListComponent
    },

    {
        path: '**',
        redirectTo: ''
    }

];
