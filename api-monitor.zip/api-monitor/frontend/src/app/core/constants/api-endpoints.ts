export const ApiEndpoints = {

    SERVICES: 'http://127.0.0.1:8000/api/services',

    SERVICE_CHECK: (id: number) =>
        `http://127.0.0.1:8000/api/services/${id}/check`

};
