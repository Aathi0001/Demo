import {
    AbstractControl,
    FormGroup
} from '@angular/forms';

import {
    ValidationMessages
} from '../constants/validation-messages';

export class ValidationUtils {

    static isInvalid(
        form: FormGroup,
        controlName: string
    ): boolean {

        const control = form.get(controlName);

        return !!(
            control &&
            control.invalid &&
            (control.dirty || control.touched)
        );

    }

    static getErrorMessage(
        form: FormGroup,
        controlName: string
    ): string {

        const control = form.get(controlName);

        if (!control?.errors) {
            return '';
        }

        if (control.hasError('required')) {
            return ValidationMessages.REQUIRED;
        }

        if (control.hasError('email')) {
            return ValidationMessages.EMAIL;
        }

        if (control.hasError('minlength')) {

            const requiredLength =
                control.getError('minlength').requiredLength;

            return `Minimum ${requiredLength} characters required.`;

        }

        if (control.hasError('maxlength')) {

            const requiredLength =
                control.getError('maxlength').requiredLength;

            return `Maximum ${requiredLength} characters allowed.`;

        }

        if (control.hasError('min')) {

            const min =
                control.getError('min').min;

            return `Minimum value is ${min}.`;

        }

        if (control.hasError('max')) {

            const max =
                control.getError('max').max;

            return `Maximum value is ${max}.`;

        }

        if (control.hasError('pattern')) {
            return ValidationMessages.PASSWORD_PATTERN;
        }

        if (control.hasError('whitespace')) {
            return ValidationMessages.WHITESPACE;
        }

        if (control.hasError('passwordMismatch')) {
            return ValidationMessages.PASSWORD_MATCH;
        }

        if (control.hasError('server')) {
            return control.getError('server');
        }

        return '';

    }

    static setServerErrors(
        form: FormGroup,
        errors: Record<string, string[]>
    ): void {

        Object.keys(errors).forEach(field => {

            const control = form.get(field);

            if (!control) {
                return;
            }

            control.setErrors({

                ...control.errors,

                server: errors[field][0]

            });

            control.markAsTouched();

        });

    }

}
