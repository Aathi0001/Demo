export class ApiConstants {

  //static readonly BASE_URL = 'http://127.0.0.1:8000/api';
  static readonly BASE_URL = 'http://192.168.12.163:8000/api';

}
