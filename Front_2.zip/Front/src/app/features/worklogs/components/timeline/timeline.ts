import {
    Component,
    EventEmitter,
    Input,
    OnInit,
    Output,
    inject
} from '@angular/core';

import {
    CommonModule
} from '@angular/common';

import {
    WorkLogService
} from '../../services/worklog';

import {
    TimelineYearModel
} from '../../models/timeline-year';

import {
    TimelineMonthModel
} from '../../models/timeline-month';

import {
    ChangeDetectorRef
} from '@angular/core';

@Component({

    selector:'app-timeline',

    standalone:true,

    imports:[

        CommonModule

    ],

    templateUrl:'./timeline.html',

    styleUrl:'./timeline.scss'

})
export class Timeline
implements OnInit{

    private workLogService =
        inject(WorkLogService);

        private cdr=
    inject(ChangeDetectorRef);

    @Input()

    visible = false;

    @Output()

    close =
    new EventEmitter<void>();

    @Output()

    weekSelected =
    new EventEmitter<number>();

    years:TimelineYearModel[]=[];

    selectedYear:number|null=null;

    months:TimelineMonthModel[]=[];

    expandedMonths = new Set<number>();


    ngOnInit():void{

        this.loadYears();

    }

    loadYears():void{

        this.workLogService
        .getTimelineYears()
        .subscribe({

            next:response=>{

                this.years =
                    response.data.years;

                    this.cdr.detectChanges();

            }

        });

    }
loadTimeline(
    year:number
):void{

    this.selectedYear = year;

    this.expandedMonths.clear();

    this.workLogService
        .getTimeline(year)
        .subscribe({

            next:response=>{

                this.months =
                    response.data.months;

                this.months.forEach(

                    month=>{

                        this.expandedMonths.add(
                            month.month
                        );

                    }

                );

                this.cdr.detectChanges();

            }

        });

}

    toggleMonth(
    month:number
):void{

    if(
        this.expandedMonths.has(month)
    ){

        this.expandedMonths.delete(
            month
        );

    }
    else{

        this.expandedMonths.add(
            month
        );

    }

}
toggleYear(year: number): void {

    // Collapse if already open
    if (this.selectedYear === year) {

        this.selectedYear = null;
        this.months = [];
        return;

    }

    // Expand
    this.selectedYear = year;

    this.loadTimeline(year);

}
isExpanded(
    month:number
):boolean{

    return this.expandedMonths.has(
        month
    );

}


    selectWeek(
        weekOffset:number
    ):void{

        this.weekSelected.emit(
            weekOffset
        );

    }

    closeDialog():void{

        this.close.emit();

    }

}
