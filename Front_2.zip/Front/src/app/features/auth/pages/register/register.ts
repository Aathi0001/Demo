import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  ReactiveFormsModule,
  Validators,
  AbstractControl
} from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

import { AuthService } from '../../services/auth';

import { RegisterRequest } from '../../models/register-request';

import { HttpErrorResponse } from '@angular/common/http';

import { CustomValidators } from '../../../../core/validators/custom-validators';
import { ValidationMessages } from '../../../../core/constants/validation-messages';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink
  ],
  templateUrl: './register.html',
  styleUrl: './register.scss'
})
export class Register {

  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private router = inject(Router);

  validation = ValidationMessages;

  registerForm = this.fb.group({

    username: [
      '',
      [
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(150),
        CustomValidators.noWhitespace()
      ]
    ],

    email: [
      '',
      [
        Validators.required,
        Validators.email,
        Validators.maxLength(254)
      ]
    ],

    password: [
      '',
      [
        Validators.required,
        Validators.minLength(8),
        Validators.maxLength(128),
        Validators.pattern(
          /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).+$/
        )
      ]
    ],

    confirm_password: [
      '',
      [
        Validators.required
      ]
    ]

  },
  {
    validators: CustomValidators.passwordMatch(
      'password',
      'confirm_password'
    )
  });

  get f() {
    return this.registerForm.controls;
  }

  isInvalid(control: string): boolean {

    const field = this.registerForm.get(control);

    return !!(
      field &&
      field.invalid &&
      (field.dirty || field.touched)
    );

  }

  getError(control: string): string {

    const field = this.registerForm.get(control);

    if (!field?.errors) {
      return '';
    }

    if (field.hasError('required'))
      return this.validation.REQUIRED;

    if (field.hasError('email'))
      return this.validation.EMAIL;

    if (field.hasError('minlength'))
      return this.validation.MIN_LENGTH;

    if (field.hasError('maxlength'))
      return this.validation.MAX_LENGTH;

    if (field.hasError('pattern'))
      return this.validation.PASSWORD_PATTERN;

    if (field.hasError('whitespace'))
      return this.validation.WHITESPACE;

    if (field.hasError('passwordMismatch'))
      return this.validation.PASSWORD_MATCH;

    if (field.hasError('server')) 
      return field.getError('server');

    return '';

  }

  private setServerErrors(errors: Record<string, string[]>): void {

      Object.keys(errors).forEach(field => {

          const control = this.registerForm.get(field);

          if (!control) {
              return;
          }

          control.setErrors({

              ...control.errors,

              server: errors[field][0]

          });

          control.markAsTouched();

      });

  }

  register(): void {

      this.registerForm.markAllAsTouched();

      if (this.registerForm.invalid) {
          return;
      }

      const request: RegisterRequest = {

          username: this.f.username.value!,

          email: this.f.email.value!,

          password: this.f.password.value!,

          confirm_password: this.f.confirm_password.value!

      };

      this.authService.register(request).subscribe({

          next: (response) => {

              console.log(response.message);

              this.router.navigate([
                  '/login'
              ]);

          },

          error: (error: HttpErrorResponse) => {

              if (error.status === 400 && error.error?.errors) {

                  this.setServerErrors(error.error.errors);

                  return;

              }

              console.error(error);

          }

      });

  }

}
