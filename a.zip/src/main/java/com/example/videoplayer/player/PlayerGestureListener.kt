package com.example.videoplayer.player

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import com.example.videoplayer.data.local.AppPreferences
import com.example.videoplayer.utils.GeneralFunc
import kotlin.math.abs

interface PlayerGestureCallback {
    fun onSingleTap()
    fun onDoubleTapSeek(isForward: Boolean, targetPositionMs: Long)
    fun onDoubleTapPlayPause()
    fun onVolumeChanged(currentVolumeRatio: Float)
    fun onBrightnessChanged(currentBrightnessRatio: Float)
    fun onScaleChanged(scaleFactor: Float)
    fun onHorizontalScrub(seekPositionMs: Long, deltaMs: Long, isFinalCommit: Boolean)
    fun onScreenshotGestureTriggered()
}

class PlayerGestureListener(
    private val context: Context,
    private val targetView: View,
    private val playerEngine: PlayerEngine,
    private val callback: PlayerGestureCallback,
    private val appPreferences: AppPreferences
) : View.OnTouchListener {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat().coerceAtLeast(1f)

    private var volumeAccumulator: Float = 0f
    private var brightnessAccumulator: Float = 0.5f

    private enum class GestureMode { NONE, VERTICAL_BRIGHTNESS, VERTICAL_VOLUME, HORIZONTAL_SCRUB, SCREENSHOT_TRIGGERED }
    private var activeMode = GestureMode.NONE

    private var initialSeekPositionMs = 0L
    private var scrubDeltaMs = 0L
    private var currentScale = 1.0f

    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {

        override fun onDown(e: MotionEvent): Boolean {
            volumeAccumulator = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()

            val activity = context as? Activity
            val lp = activity?.window?.attributes
            val currentBrightness = lp?.screenBrightness ?: -1f
            brightnessAccumulator = if (currentBrightness < 0f) 0.5f else currentBrightness

            initialSeekPositionMs = playerEngine.currentPosition
            scrubDeltaMs = 0L
            activeMode = GestureMode.NONE
            return true
        }

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            callback.onSingleTap()
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            val width = targetView.width
            val height = targetView.height
            val x = e.x
            val y = e.y

            // Ignore double tap if initiated within 5% edge boundaries
            if (x < width * 0.05f || x > width * 0.95f || y < height * 0.05f || y > height * 0.95f) {
                return false
            }

            val seekDurationMs = appPreferences.doubleTapSeekSeconds * 1000L

            when {
                // Left 35%: Rewind
                x < width * 0.35f -> {
                    if (appPreferences.isDoubleTapSeekEnabled) {
                        val newPos = playerEngine.seekRelative(-seekDurationMs)
                        callback.onDoubleTapSeek(false, newPos)
                    }
                }
                // Right 35%: Fast Forward
                x > width * 0.65f -> {
                    if (appPreferences.isDoubleTapSeekEnabled) {
                        val newPos = playerEngine.seekRelative(seekDurationMs)
                        callback.onDoubleTapSeek(true, newPos)
                    }
                }
                // Center 30%: Play / Pause
                else -> {
                    callback.onDoubleTapPlayPause()
                }
            }
            return true
        }

        override fun onScroll(
            e1: MotionEvent?,
            e2: MotionEvent,
            distanceX: Float,
            distanceY: Float
        ): Boolean {
            if (e1 == null || e2.pointerCount > 1) return false
            val width = targetView.width.coerceAtLeast(1)
            val height = targetView.height.coerceAtLeast(1)

            // 5% Deadzone boundaries on all four screen edges (Left, Right, Top, Bottom)
            val isInsideHorizontalDeadzone = e1.x < (width * 0.05f) || e1.x > (width * 0.95f)
            val isInsideVerticalDeadzone = e1.y < (height * 0.05f) || e1.y > (height * 0.95f)

            if (isInsideHorizontalDeadzone || isInsideVerticalDeadzone) {
                return false
            }

            // Detect dominant gesture direction on initial movement
            if (activeMode == GestureMode.NONE) {
                if (abs(distanceX) > abs(distanceY)) {
                    if (appPreferences.isHorizontalScrubEnabled) {
                        activeMode = GestureMode.HORIZONTAL_SCRUB
                    }
                } else {
                    val startX = e1.x
                    activeMode = when {
                        startX < width * 0.35f && appPreferences.isBrightnessGestureEnabled -> GestureMode.VERTICAL_BRIGHTNESS
                        startX > width * 0.65f && appPreferences.isVolumeGestureEnabled -> GestureMode.VERTICAL_VOLUME
                        else -> GestureMode.NONE
                    }
                }
            }

            when (activeMode) {
                GestureMode.VERTICAL_BRIGHTNESS -> {
                    val deltaRatio = distanceY / height
                    adjustBrightness(deltaRatio)
                }
                GestureMode.VERTICAL_VOLUME -> {
                    val deltaRatio = distanceY / height
                    adjustVolume(deltaRatio)
                }
                GestureMode.HORIZONTAL_SCRUB -> {
                    val totalDeltaX = e2.x - e1.x
                    val totalDuration = playerEngine.duration.coerceAtLeast(1L)

                    // VLC-style progressive scrubbing:
                    // Small drags stay very fine; larger drags accelerate smoothly
                    val distanceRatio = abs(totalDeltaX) / width.toFloat()
                    val accelerationMultiplier = 1.0f + (distanceRatio * 3.0f)
                    scrubDeltaMs = (totalDeltaX * 50f * accelerationMultiplier).toLong()

                    val targetSeek = (initialSeekPositionMs + scrubDeltaMs).coerceIn(0L, totalDuration)
                    callback.onHorizontalScrub(targetSeek, scrubDeltaMs, false)
                }
                GestureMode.NONE -> {
                    if (appPreferences.isSwipeScreenshotEnabled) {
                        val verticalDisplacement = abs(e2.y - e1.y)
                        if (verticalDisplacement > 90 * context.resources.displayMetrics.density) {
                            callback.onScreenshotGestureTriggered()
                            activeMode = GestureMode.SCREENSHOT_TRIGGERED
                        }
                    }
                }
                GestureMode.SCREENSHOT_TRIGGERED -> {
                    // Consumed
                }
            }
            return true
        }
    })

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            currentScale *= detector.scaleFactor
            currentScale = GeneralFunc.clampValue(
                currentScale,
                0.5f,
                3.0f
            )
            callback.onScaleChanged(currentScale)
            return true
        }
    })

    override fun onTouch(v: View, event: MotionEvent): Boolean {
        if (event.pointerCount > 1) {
            scaleDetector.onTouchEvent(event)
        } else {
            gestureDetector.onTouchEvent(event)
        }

        if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_CANCEL) {
            if (activeMode == GestureMode.HORIZONTAL_SCRUB) {
                val totalDuration = playerEngine.duration.coerceAtLeast(1L)
                val targetSeek = (initialSeekPositionMs + scrubDeltaMs).coerceIn(0L, totalDuration)

                playerEngine.seekTo(targetSeek)
                callback.onHorizontalScrub(targetSeek, scrubDeltaMs, true)
            }
            activeMode = GestureMode.NONE
        }
        return true
    }

    private fun adjustBrightness(deltaRatio: Float) {
        val activity = context as? Activity ?: return
        val layoutParams = activity.window.attributes

        brightnessAccumulator = GeneralFunc.clampValue(brightnessAccumulator + (deltaRatio * 1.2f), 0.01f, 1.0f)
        layoutParams.screenBrightness = brightnessAccumulator
        activity.window.attributes = layoutParams

        callback.onBrightnessChanged(brightnessAccumulator)
    }

    private fun adjustVolume(deltaRatio: Float) {
        val delta = deltaRatio * maxVolume * 1.5f
        volumeAccumulator = GeneralFunc.clampValue(volumeAccumulator + delta, 0f, maxVolume)

        val targetStep = volumeAccumulator.toInt()
        audioManager.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            targetStep,
            AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE
        )

        val normalizedRatio = volumeAccumulator / maxVolume
        callback.onVolumeChanged(normalizedRatio)
    }
}