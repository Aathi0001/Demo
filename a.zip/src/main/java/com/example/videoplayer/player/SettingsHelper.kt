package com.example.videoplayer.player

import android.content.Context
import android.view.LayoutInflater
import android.widget.RadioButton
import android.widget.RadioGroup
import com.example.videoplayer.R
import com.example.videoplayer.data.local.AppPreferences
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.switchmaterial.SwitchMaterial

object SettingsHelper {

    fun showSettingsDialog(
        context: Context,
        appPreferences: AppPreferences,
        onSettingsUpdated: () -> Unit
    ) {
        val dialog = BottomSheetDialog(context)
        val view = LayoutInflater.from(context).inflate(R.layout.bottom_sheet_settings, null)
        dialog.setContentView(view)

        // Playback Switches
        val switchAutoPlayNext = view.findViewById<SwitchMaterial>(R.id.switchAutoPlayNext)
        val switchBackgroundAudio = view.findViewById<SwitchMaterial>(R.id.switchBackgroundAudio)

        // Gesture Switches
        val switchSwipeScreenshot = view.findViewById<SwitchMaterial>(R.id.switchSwipeScreenshot)
        val switchBrightness = view.findViewById<SwitchMaterial>(R.id.switchBrightness)
        val switchVolume = view.findViewById<SwitchMaterial>(R.id.switchVolume)
        val switchScrubbing = view.findViewById<SwitchMaterial>(R.id.switchScrubbing)
        val switchDoubleTapSeek = view.findViewById<SwitchMaterial>(R.id.switchDoubleTapSeek)

        // UI Buttons Visibility Switches
        val switchShowNextPrev = view.findViewById<SwitchMaterial>(R.id.switchShowNextPrev)
        val switchShowScreenshotBtn = view.findViewById<SwitchMaterial>(R.id.switchShowScreenshotBtn)
        val switchShowAspectRatioBtn = view.findViewById<SwitchMaterial>(R.id.switchShowAspectRatioBtn)
        val switchShowOrientationBtn = view.findViewById<SwitchMaterial>(R.id.switchShowOrientationBtn)
        val switchShowPipBtn = view.findViewById<SwitchMaterial>(R.id.switchShowPipBtn)
        val switchShowSpeedBtn = view.findViewById<SwitchMaterial>(R.id.switchShowSpeedBtn)
        val switchShowDecoderBtn = view.findViewById<SwitchMaterial>(R.id.switchShowDecoderBtn)
        val switchShowBackgroundAudioBtn = view.findViewById<SwitchMaterial>(R.id.switchShowBackgroundAudioBtn)
        val switchShowTracksBtn = view.findViewById<SwitchMaterial>(R.id.switchShowTracksBtn)
        val switchShowLockBtn = view.findViewById<SwitchMaterial>(R.id.switchShowLockBtn)

        // RadioGroup for Seek Duration
        val rgSeekDuration = view.findViewById<RadioGroup>(R.id.rgSeekDuration)

        // Initialize state from AppPreferences
        switchAutoPlayNext.isChecked = appPreferences.isAutoPlayNextEnabled
        switchBackgroundAudio.isChecked = appPreferences.isBackgroundAudioEnabled

        switchSwipeScreenshot.isChecked = appPreferences.isSwipeScreenshotEnabled
        switchBrightness.isChecked = appPreferences.isBrightnessGestureEnabled
        switchVolume.isChecked = appPreferences.isVolumeGestureEnabled
        switchScrubbing.isChecked = appPreferences.isHorizontalScrubEnabled
        switchDoubleTapSeek.isChecked = appPreferences.isDoubleTapSeekEnabled

        switchShowNextPrev.isChecked = appPreferences.showNextPrevButtons
        switchShowScreenshotBtn.isChecked = appPreferences.showScreenshotButton
        switchShowAspectRatioBtn.isChecked = appPreferences.showAspectRatioButton
        switchShowOrientationBtn.isChecked = appPreferences.showOrientationButton
        switchShowPipBtn.isChecked = appPreferences.showPipButton
        switchShowSpeedBtn.isChecked = appPreferences.showSpeedButton
        switchShowDecoderBtn.isChecked = appPreferences.showDecoderToggleButton
        switchShowBackgroundAudioBtn.isChecked = appPreferences.showBackgroundAudioButton
        switchShowTracksBtn.isChecked = appPreferences.showTracksButton
        switchShowLockBtn.isChecked = appPreferences.showLockButton

        when (appPreferences.doubleTapSeekSeconds) {
            5 -> view.findViewById<RadioButton>(R.id.rbSeek5).isChecked = true
            15 -> view.findViewById<RadioButton>(R.id.rbSeek15).isChecked = true
            30 -> view.findViewById<RadioButton>(R.id.rbSeek30).isChecked = true
            else -> view.findViewById<RadioButton>(R.id.rbSeek10).isChecked = true
        }

        // --- Switch Listeners ---
        switchAutoPlayNext.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isAutoPlayNextEnabled = isChecked
            onSettingsUpdated()
        }

        switchBackgroundAudio.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isBackgroundAudioEnabled = isChecked
            onSettingsUpdated()
        }

        switchSwipeScreenshot.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isSwipeScreenshotEnabled = isChecked
            onSettingsUpdated()
        }

        switchBrightness.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isBrightnessGestureEnabled = isChecked
            onSettingsUpdated()
        }

        switchVolume.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isVolumeGestureEnabled = isChecked
            onSettingsUpdated()
        }

        switchScrubbing.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isHorizontalScrubEnabled = isChecked
            onSettingsUpdated()
        }

        switchDoubleTapSeek.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.isDoubleTapSeekEnabled = isChecked
            onSettingsUpdated()
        }

        switchShowNextPrev.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showNextPrevButtons = isChecked
            onSettingsUpdated()
        }

        switchShowScreenshotBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showScreenshotButton = isChecked
            onSettingsUpdated()
        }

        switchShowAspectRatioBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showAspectRatioButton = isChecked
            onSettingsUpdated()
        }

        switchShowOrientationBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showOrientationButton = isChecked
            onSettingsUpdated()
        }

        switchShowPipBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showPipButton = isChecked
            onSettingsUpdated()
        }

        switchShowSpeedBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showSpeedButton = isChecked
            onSettingsUpdated()
        }

        switchShowDecoderBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showDecoderToggleButton = isChecked
            onSettingsUpdated()
        }

        switchShowBackgroundAudioBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showBackgroundAudioButton = isChecked
            onSettingsUpdated()
        }

        switchShowTracksBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showTracksButton = isChecked
            onSettingsUpdated()
        }

        switchShowLockBtn.setOnCheckedChangeListener { _, isChecked ->
            appPreferences.showLockButton = isChecked
            onSettingsUpdated()
        }

        // Listener for Seek Duration
        rgSeekDuration.setOnCheckedChangeListener { _, checkedId ->
            val seconds = when (checkedId) {
                R.id.rbSeek5 -> 5
                R.id.rbSeek15 -> 15
                R.id.rbSeek30 -> 30
                else -> 10
            }
            appPreferences.doubleTapSeekSeconds = seconds
            onSettingsUpdated()
        }

        dialog.show()
    }
}