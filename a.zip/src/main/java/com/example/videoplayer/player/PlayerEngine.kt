package com.example.videoplayer.player

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.view.View
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import com.example.videoplayer.config.GeneralConfig
import java.io.File
import java.io.FileOutputStream

enum class ActiveEngine {
    EXO_PLAYER,
    LIB_VLC
}

class PlayerEngine(
    private val context: Context,
    private val playerView: PlayerView,
    private val vlcVideoLayout: VLCVideoLayout,
    private val onEngineChanged: (ActiveEngine) -> Unit,
    private val onPlaybackEnded: () -> Unit
) {
    var activeEngine: ActiveEngine = ActiveEngine.EXO_PLAYER
        private set

    var exoPlayer: ExoPlayer? = null
        private set

    private var libVLC: LibVLC? = null
    var vlcMediaPlayer: MediaPlayer? = null
        private set
    private var pfd: ParcelFileDescriptor? = null

    private var currentUri: Uri? = null
    private var lastKnownPositionMs: Long = 0L
    private var pendingVlcSeekPos: Long = 0L
    private var isVlcViewsAttached: Boolean = false

    var subtitleDelayMs: Long = 0L
        private set
    var audioDelayMs: Long = 0L
        private set

    val isPlaying: Boolean
        get() = when (activeEngine) {
            ActiveEngine.EXO_PLAYER -> exoPlayer?.isPlaying == true
            ActiveEngine.LIB_VLC -> vlcMediaPlayer?.isPlaying == true
        }

    val currentPosition: Long
        get() = when (activeEngine) {
            ActiveEngine.EXO_PLAYER -> exoPlayer?.currentPosition ?: lastKnownPositionMs
            ActiveEngine.LIB_VLC -> vlcMediaPlayer?.time ?: lastKnownPositionMs
        }

    val duration: Long
        get() = when (activeEngine) {
            ActiveEngine.EXO_PLAYER -> exoPlayer?.duration?.coerceAtLeast(0L) ?: 0L
            ActiveEngine.LIB_VLC -> vlcMediaPlayer?.length?.coerceAtLeast(0L) ?: 0L
        }

    init {
        initExoPlayer()
    }

    private fun initExoPlayer() {
        if (exoPlayer != null) return

        val renderersFactory = DefaultRenderersFactory(context).apply {
            setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            setEnableDecoderFallback(true)
        }

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val loadControl = LowRamLoadControl.create()

        exoPlayer = ExoPlayer.Builder(context, renderersFactory)
            .setAudioAttributes(audioAttributes, true)
            .setLoadControl(loadControl)
            .setSeekParameters(SeekParameters.CLOSEST_SYNC)
            .build()
            .apply {
                playerView.player = this
                videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT
                addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_ENDED) {
                            onPlaybackEnded()
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        switchToVlc(force = false)
                    }
                })
            }
    }

    fun playMedia(uri: Uri, startPositionMs: Long = 0L, preferredEngine: ActiveEngine? = null) {
        cleanupSubtitleCache()
        currentUri = uri
        lastKnownPositionMs = startPositionMs

        if (preferredEngine == ActiveEngine.LIB_VLC || (preferredEngine == null && activeEngine == ActiveEngine.LIB_VLC)) {
            startVlcPlayback(uri, startPositionMs, force = true)
            return
        }

        if (activeEngine == ActiveEngine.LIB_VLC) {
            stopVlc()
        }

        activeEngine = ActiveEngine.EXO_PLAYER
        vlcVideoLayout.visibility = View.GONE
        playerView.visibility = View.VISIBLE
        onEngineChanged(ActiveEngine.EXO_PLAYER)

        if (exoPlayer == null) {
            initExoPlayer()
        }

        exoPlayer?.let { player ->
            playerView.player = player
            val mediaItem = MediaItem.fromUri(uri)
            player.setMediaItem(mediaItem)
            if (startPositionMs > 0L) {
                player.seekTo(startPositionMs)
            }
            player.prepare()
            player.playWhenReady = true
        }
    }

    fun switchToVlc(force: Boolean = true) {
        val resumePos = if (activeEngine == ActiveEngine.EXO_PLAYER) {
            exoPlayer?.currentPosition ?: lastKnownPositionMs
        } else {
            vlcMediaPlayer?.time ?: lastKnownPositionMs
        }
        currentUri?.let { startVlcPlayback(it, resumePos, force) }
    }

    private fun startVlcPlayback(uri: Uri, resumePos: Long, force: Boolean) {
        lastKnownPositionMs = resumePos
        pendingVlcSeekPos = resumePos

        exoPlayer?.stop()
        exoPlayer?.clearMediaItems()
        playerView.player = null
        playerView.visibility = View.GONE

        vlcVideoLayout.visibility = View.VISIBLE
        activeEngine = ActiveEngine.LIB_VLC
        onEngineChanged(ActiveEngine.LIB_VLC)

        if (libVLC == null) {
            val options = ArrayList<String>().apply {
                add("--no-drop-late-frames")
                add("--no-skip-frames")
                add("--aout=opensles")
                add("--audio-time-stretch")
                add("--file-caching=1500")
                add("--network-caching=1500")
                add("--codec=mediacodec_ndk,all")
            }
            libVLC = LibVLC(context, options)
        }

        if (vlcMediaPlayer == null) {
            vlcMediaPlayer = MediaPlayer(libVLC)
        }

        // Apply resume position once LibVLC starts playing and stream headers are parsed
        vlcMediaPlayer?.setEventListener { event ->
            when (event.type) {
                MediaPlayer.Event.Playing -> {
                    if (pendingVlcSeekPos > 0L) {
                        vlcMediaPlayer?.time = pendingVlcSeekPos
                        pendingVlcSeekPos = 0L
                    }
                }
                MediaPlayer.Event.EndReached -> {
                    onPlaybackEnded()
                }
            }
        }

        safeAttachVlcViews()

        try {
            val media = if (uri.scheme == "content") {
                pfd?.close()
                pfd = context.contentResolver.openFileDescriptor(uri, "r")
                if (pfd != null) {
                    Media(libVLC, pfd!!.fileDescriptor)
                } else {
                    Media(libVLC, uri)
                }
            } else {
                Media(libVLC, uri)
            }

            media.apply {
                setHWDecoderEnabled(!force, false)
            }

            vlcMediaPlayer?.apply {
                this.media = media
                play()
            }
            media.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun switchToExoPlayer() {
        if (activeEngine == ActiveEngine.EXO_PLAYER) return
        val currentPos = vlcMediaPlayer?.time ?: lastKnownPositionMs

        // Explicitly halt and release VLC audio before booting ExoPlayer (Fixes dual/ghost audio bug)
        stopVlc()

        currentUri?.let { uri ->
            activeEngine = ActiveEngine.EXO_PLAYER
            playMedia(uri, currentPos, ActiveEngine.EXO_PLAYER)
        }
    }

    private fun safeAttachVlcViews() {
        vlcVideoLayout.post {
            try {
                if (isVlcViewsAttached) {
                    vlcMediaPlayer?.detachViews()
                    isVlcViewsAttached = false
                }
                vlcMediaPlayer?.attachViews(vlcVideoLayout, null, false, false)
                isVlcViewsAttached = true
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun enableBackgroundAudioMode() {
        if (activeEngine == ActiveEngine.LIB_VLC) {
            try {
                if (isVlcViewsAttached) {
                    vlcMediaPlayer?.detachViews()
                    isVlcViewsAttached = false
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
            exoPlayer?.clearVideoSurface()
        }
    }

    fun exitBackgroundAudioMode() {
        if (activeEngine == ActiveEngine.LIB_VLC && vlcMediaPlayer != null) {
            safeAttachVlcViews()
        } else if (activeEngine == ActiveEngine.EXO_PLAYER) {
            exoPlayer?.let { player ->
                playerView.player = player
            }
        }
    }

    fun onActivityResume() {
        exitBackgroundAudioMode()
    }

    fun addSubtitleSource(uri: Uri) {
        when (activeEngine) {
            ActiveEngine.EXO_PLAYER -> {
                exoPlayer?.let { player ->
                    val subtitleConfig = MediaItem.SubtitleConfiguration.Builder(uri)
                        .setMimeType(
                            when {
                                uri.toString().endsWith(".vtt", ignoreCase = true) -> MimeTypes.TEXT_VTT
                                uri.toString().endsWith(".ass", ignoreCase = true) || uri.toString().endsWith(".ssa", ignoreCase = true) -> MimeTypes.TEXT_SSA
                                else -> MimeTypes.APPLICATION_SUBRIP
                            }
                        )
                        .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                        .build()

                    currentUri?.let { videoUri ->
                        val currentPos = player.currentPosition
                        val mediaItem = MediaItem.Builder()
                            .setUri(videoUri)
                            .setSubtitleConfigurations(listOf(subtitleConfig))
                            .build()
                        player.setMediaItem(mediaItem, currentPos)
                        player.prepare()
                        player.play()
                    }
                }
            }
            ActiveEngine.LIB_VLC -> {
                try {
                    val fileUri = if (uri.scheme == "content") {
                        val tempFile = File(context.cacheDir, "temp_sub_${System.currentTimeMillis()}.srt")
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            FileOutputStream(tempFile).use { output ->
                                input.copyTo(output)
                            }
                        }
                        Uri.fromFile(tempFile)
                    } else {
                        uri
                    }
                    vlcMediaPlayer?.addSlave(0, fileUri, true)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    fun cleanupSubtitleCache() {
        try {
            context.cacheDir.listFiles()?.forEach { file ->
                if (file.name.startsWith("temp_sub_")) {
                    file.delete()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setSubtitleDelay(delayMs: Long) {
        subtitleDelayMs = delayMs
        if (activeEngine == ActiveEngine.LIB_VLC) {
            vlcMediaPlayer?.setSpuDelay(delayMs * 1000L)
        }
    }

    fun setAudioDelay(delayMs: Long) {
        audioDelayMs = delayMs
        if (activeEngine == ActiveEngine.LIB_VLC) {
            vlcMediaPlayer?.setAudioDelay(delayMs * 1000L)
        }
    }

    fun togglePlayPause(): Boolean {
        return when (activeEngine) {
            ActiveEngine.EXO_PLAYER -> {
                exoPlayer?.let {
                    if (it.isPlaying) {
                        it.pause()
                        false
                    } else {
                        it.play()
                        true
                    }
                } ?: false
            }
            ActiveEngine.LIB_VLC -> {
                vlcMediaPlayer?.let {
                    if (it.isPlaying) {
                        it.pause()
                        false
                    } else {
                        it.play()
                        true
                    }
                } ?: false
            }
        }
    }

    fun seekTo(positionMs: Long) {
        lastKnownPositionMs = positionMs
        when (activeEngine) {
            ActiveEngine.EXO_PLAYER -> exoPlayer?.seekTo(positionMs)
            ActiveEngine.LIB_VLC -> vlcMediaPlayer?.time = positionMs
        }
    }

    fun seekRelative(deltaMs: Long): Long {
        val current = currentPosition
        val total = duration
        val target = (current + deltaMs).coerceIn(0L, total.coerceAtLeast(0L))
        seekTo(target)
        return target
    }

    fun setPlaybackSpeed(speed: Float) {
        val validSpeed = if (speed in GeneralConfig.PLAYBACK_SPEED_PRESETS) speed else GeneralConfig.DEFAULT_PLAYBACK_SPEED
        when (activeEngine) {
            ActiveEngine.EXO_PLAYER -> exoPlayer?.playbackParameters = PlaybackParameters(validSpeed)
            ActiveEngine.LIB_VLC -> vlcMediaPlayer?.rate = validSpeed
        }
    }

    fun setAspectRatio(modeIndex: Int) {
        when (activeEngine) {
            ActiveEngine.EXO_PLAYER -> {
                when (modeIndex) {
                    0 -> playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    1 -> playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
                    2 -> playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    else -> playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
                }
            }
            ActiveEngine.LIB_VLC -> {
                when (modeIndex) {
                    0 -> vlcMediaPlayer?.aspectRatio = null
                    1 -> vlcMediaPlayer?.aspectRatio = "16:9"
                    2 -> vlcMediaPlayer?.aspectRatio = "4:3"
                    else -> vlcMediaPlayer?.aspectRatio = "fill"
                }
            }
        }
    }

    private fun stopVlc() {
        try {
            if (isVlcViewsAttached) {
                vlcMediaPlayer?.detachViews()
                isVlcViewsAttached = false
            }
            vlcMediaPlayer?.apply {
                stop()
                release()
            }
            vlcMediaPlayer = null
            pfd?.close()
            pfd = null
            libVLC?.release()
            libVLC = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun release() {
        cleanupSubtitleCache()
        exoPlayer?.apply {
            stop()
            clearMediaItems()
            release()
        }
        exoPlayer = null
        playerView.player = null

        stopVlc()
    }
}