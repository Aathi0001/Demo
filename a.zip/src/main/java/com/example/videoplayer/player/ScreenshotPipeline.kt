package com.example.videoplayer.player

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.PixelCopy
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.media3.ui.PlayerView
import com.example.videoplayer.utils.CommonFunc
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

data class ScreenshotTask(
    val bitmap: Bitmap,
    val filename: String
)

class ScreenshotPipeline(
    private val context: Context,
    private val onScreenshotSaved: (Uri?, String) -> Unit
) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val queue = Channel<ScreenshotTask>(capacity = 100)

    init {
        startWorker()
    }

    /**
     * Captures frame from ExoPlayer.
     * Passing videoWidth and videoHeight removes black pillarbox/letterbox bars in SW fallback mode.
     */
    fun captureFrameExo(
        playerView: PlayerView,
        videoTitle: String,
        currentPositionMs: Long,
        videoWidth: Int = 0,
        videoHeight: Int = 0
    ): Boolean {
        val surfaceView = playerView.videoSurfaceView ?: return false
        val filename = CommonFunc.generateScreenshotFilename(videoTitle, currentPositionMs)

        return captureSurfaceOrTexture(surfaceView, filename, videoWidth, videoHeight)
    }

    /**
     * Captures frame from LibVLC.
     * Extracts track dimensions to crop out SW decoder pillarbox bars cleanly.
     */
    fun captureFrameVlc(
        vlcVideoLayout: VLCVideoLayout,
        videoTitle: String,
        currentPositionMs: Long,
        mediaPlayer: MediaPlayer? = null
    ): Boolean {
        val surfaceView = findSurfaceOrTextureView(vlcVideoLayout) ?: return false
        val filename = CommonFunc.generateScreenshotFilename(videoTitle, currentPositionMs)

        val videoTrack = mediaPlayer?.currentVideoTrack
        val width = videoTrack?.width ?: 0
        val height = videoTrack?.height ?: 0

        return captureSurfaceOrTexture(surfaceView, filename, width, height)
    }

    private fun captureSurfaceOrTexture(
        view: View,
        filename: String,
        videoWidth: Int = 0,
        videoHeight: Int = 0
    ): Boolean {
        if (view is SurfaceView) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val surface = view.holder.surface
                if (!surface.isValid) return false

                val fullBitmap = Bitmap.createBitmap(
                    view.width.coerceAtLeast(1),
                    view.height.coerceAtLeast(1),
                    Bitmap.Config.ARGB_8888
                )

                PixelCopy.request(
                    view,
                    fullBitmap,
                    { copyResult ->
                        if (copyResult == PixelCopy.SUCCESS) {
                            val finalBitmap = if (videoWidth > 0 && videoHeight > 0) {
                                cropLetterbox(fullBitmap, videoWidth, videoHeight)
                            } else {
                                fullBitmap
                            }
                            enqueueTask(ScreenshotTask(finalBitmap, filename))
                        } else {
                            if (!fullBitmap.isRecycled) fullBitmap.recycle()
                        }
                    },
                    Handler(Looper.getMainLooper())
                )
                return true
            } else {
                Toast.makeText(context, "Screenshot requires Android 8.0+", Toast.LENGTH_SHORT).show()
                return false
            }
        } else if (view is TextureView) {
            val rawBitmap = view.bitmap ?: return false
            val finalBitmap = if (videoWidth > 0 && videoHeight > 0) {
                cropLetterbox(rawBitmap, videoWidth, videoHeight)
            } else {
                rawBitmap
            }
            return enqueueTask(ScreenshotTask(finalBitmap, filename))
        }
        return false
    }

    /**
     * Removes black padding (pillarbox/letterbox) added during SW decoding
     */
    private fun cropLetterbox(source: Bitmap, videoWidth: Int, videoHeight: Int): Bitmap {
        val srcWidth = source.width
        val srcHeight = source.height

        val videoAspect = videoWidth.toFloat() / videoHeight.toFloat()
        val screenAspect = srcWidth.toFloat() / srcHeight.toFloat()

        val cropWidth: Int
        val cropHeight: Int
        val cropLeft: Int
        val cropTop: Int

        if (screenAspect > videoAspect) {
            // SW Mode: Black bars on Left & Right
            cropHeight = srcHeight
            cropWidth = (srcHeight * videoAspect).toInt().coerceAtMost(srcWidth)
            cropLeft = (srcWidth - cropWidth) / 2
            cropTop = 0
        } else if (screenAspect < videoAspect) {
            // Black bars on Top & Bottom
            cropWidth = srcWidth
            cropHeight = (srcWidth / videoAspect).toInt().coerceAtMost(srcHeight)
            cropLeft = 0
            cropTop = (srcHeight - cropHeight) / 2
        } else {
            return source
        }

        return try {
            val cropped = Bitmap.createBitmap(source, cropLeft, cropTop, cropWidth, cropHeight)
            if (cropped != source && !source.isRecycled) {
                source.recycle()
            }
            cropped
        } catch (e: Exception) {
            source
        }
    }

    private fun findSurfaceOrTextureView(viewGroup: ViewGroup): View? {
        for (i in 0 until viewGroup.childCount) {
            val child = viewGroup.getChildAt(i)
            if (child is SurfaceView || child is TextureView) {
                return child
            } else if (child is ViewGroup) {
                val result = findSurfaceOrTextureView(child)
                if (result != null) return result
            }
        }
        return null
    }

    private fun enqueueTask(task: ScreenshotTask): Boolean {
        val offerResult = queue.trySend(task)
        if (!offerResult.isSuccess) {
            if (!task.bitmap.isRecycled) {
                task.bitmap.recycle()
            }
            return false
        }
        return true
    }

    private fun startWorker() {
        scope.launch {
            for (task in queue) {
                val savedUri = CommonFunc.saveBitmapToStorage(context, task.bitmap, task.filename)
                onScreenshotSaved(savedUri, task.filename)
            }
        }
    }

    fun release() {
        queue.close()
    }
}