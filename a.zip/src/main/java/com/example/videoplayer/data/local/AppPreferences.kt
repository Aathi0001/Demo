package com.example.videoplayer.data.local

import android.content.Context
import android.content.SharedPreferences

class AppPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("video_player_user_prefs", Context.MODE_PRIVATE)

    companion object {
        // Gesture Toggles
        private const val KEY_SWIPE_SCREENSHOT_ENABLED = "key_swipe_screenshot_enabled"
        private const val KEY_VOLUME_GESTURE_ENABLED = "key_volume_gesture_enabled"
        private const val KEY_BRIGHTNESS_GESTURE_ENABLED = "key_brightness_gesture_enabled"
        private const val KEY_DOUBLE_TAP_SEEK_ENABLED = "key_double_tap_seek_enabled"
        private const val KEY_HORIZONTAL_SCRUB_ENABLED = "key_horizontal_scrub_enabled"
        private const val KEY_SEEK_SECONDS = "key_seek_seconds"

        // Playback Behavior
        private const val KEY_AUTO_PLAY_NEXT = "key_auto_play_next"
        private const val KEY_BACKGROUND_AUDIO_ENABLED = "key_background_audio_enabled"

        // UI Button Visibility Toggles
        private const val KEY_SHOW_NEXT_PREV_BUTTONS = "key_show_next_prev_buttons"
        private const val KEY_SHOW_SCREENSHOT_BUTTON = "key_show_screenshot_button"
        private const val KEY_SHOW_ASPECT_RATIO_BUTTON = "key_show_aspect_ratio_button"
        private const val KEY_SHOW_SPEED_BUTTON = "key_show_speed_button"
        private const val KEY_SHOW_ORIENTATION_BUTTON = "key_show_orientation_button"
        private const val KEY_SHOW_PIP_BUTTON = "key_show_pip_button"
        private const val KEY_SHOW_DECODER_TOGGLE_BUTTON = "key_show_decoder_toggle_button"
        private const val KEY_SHOW_BACKGROUND_AUDIO_BUTTON = "key_show_background_audio_button"
        private const val KEY_SHOW_TRACKS_BUTTON = "key_show_tracks_button"
        private const val KEY_SHOW_LOCK_BUTTON = "key_show_lock_button"
    }

    // --- Gesture Flags ---

    var isSwipeScreenshotEnabled: Boolean
        get() = prefs.getBoolean(KEY_SWIPE_SCREENSHOT_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_SWIPE_SCREENSHOT_ENABLED, value).apply()

    var isVolumeGestureEnabled: Boolean
        get() = prefs.getBoolean(KEY_VOLUME_GESTURE_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_VOLUME_GESTURE_ENABLED, value).apply()

    var isBrightnessGestureEnabled: Boolean
        get() = prefs.getBoolean(KEY_BRIGHTNESS_GESTURE_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_BRIGHTNESS_GESTURE_ENABLED, value).apply()

    var isDoubleTapSeekEnabled: Boolean
        get() = prefs.getBoolean(KEY_DOUBLE_TAP_SEEK_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_DOUBLE_TAP_SEEK_ENABLED, value).apply()

    var isHorizontalScrubEnabled: Boolean
        get() = prefs.getBoolean(KEY_HORIZONTAL_SCRUB_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_HORIZONTAL_SCRUB_ENABLED, value).apply()

    // Seek Interval in seconds (5, 10, 15, 30)
    var doubleTapSeekSeconds: Int
        get() = prefs.getInt(KEY_SEEK_SECONDS, 10)
        set(value) = prefs.edit().putInt(KEY_SEEK_SECONDS, value).apply()

    // --- Playback Behavior ---

    var isAutoPlayNextEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTO_PLAY_NEXT, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_PLAY_NEXT, value).apply()

    var isBackgroundAudioEnabled: Boolean
        get() = prefs.getBoolean(KEY_BACKGROUND_AUDIO_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_BACKGROUND_AUDIO_ENABLED, value).apply()

    // --- UI Control Visibility ---

    var showNextPrevButtons: Boolean
        get() = prefs.getBoolean(KEY_SHOW_NEXT_PREV_BUTTONS, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_NEXT_PREV_BUTTONS, value).apply()

    var showScreenshotButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_SCREENSHOT_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_SCREENSHOT_BUTTON, value).apply()

    var showAspectRatioButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_ASPECT_RATIO_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_ASPECT_RATIO_BUTTON, value).apply()

    var showSpeedButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_SPEED_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_SPEED_BUTTON, value).apply()

    var showOrientationButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_ORIENTATION_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_ORIENTATION_BUTTON, value).apply()

    var showPipButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_PIP_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_PIP_BUTTON, value).apply()

    var showDecoderToggleButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_DECODER_TOGGLE_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_DECODER_TOGGLE_BUTTON, value).apply()

    var showBackgroundAudioButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_BACKGROUND_AUDIO_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_BACKGROUND_AUDIO_BUTTON, value).apply()

    var showTracksButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_TRACKS_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_TRACKS_BUTTON, value).apply()

    var showLockButton: Boolean
        get() = prefs.getBoolean(KEY_SHOW_LOCK_BUTTON, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_LOCK_BUTTON, value).apply()
}